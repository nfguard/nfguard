#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════╗"
echo "║        NFGuard Installation Script        ║"
echo "║          Firewall Management Tool         ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}"
   exit 1
fi

detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        ID=$ID
    elif type lsb_release >/dev/null 2>&1; then
        OS=$(lsb_release -si)
        VER=$(lsb_release -sr)
    elif [ -f /etc/lsb-release ]; then
        . /etc/lsb-release
        OS=$DISTRIB_ID
        VER=$DISTRIB_RELEASE
    else
        OS=$(uname -s)
        VER=$(uname -r)
    fi

    echo -e "${GREEN}Detected: $OS $VER${NC}"
}

get_installation_preferences() {
    echo -e "${BLUE}╔═══════════════════════════════════════════╗"
    echo "║           Installation Options            ║"
    echo "╚═══════════════════════════════════════════╝${NC}"

    # Firewall choice
    echo -e "${YELLOW}Choose firewall backend:${NC}"
    echo "1) IPTables (recommended, more compatible)"
    echo "2) UFW (Ubuntu Firewall, easier to manage)"
    while true; do
        read -p "Enter your choice (1-2): " fw_choice
        case $fw_choice in
            1)
                FIREWALL_BACKEND="iptables"
                echo -e "${GREEN}Selected: IPTables${NC}"
                break
                ;;
            2)
                FIREWALL_BACKEND="ufw"
                echo -e "${GREEN}Selected: UFW${NC}"
                break
                ;;
            *)
                echo -e "${RED}Invalid choice. Please enter 1 or 2.${NC}"
                ;;
        esac
    done

    # Domain configuration
    echo ""
    echo -e "${YELLOW}Do you want to configure a custom domain for the WebGUI? (y/n)${NC}"
    read -r domain_choice
    if [[ "$domain_choice" =~ ^[Yy]$ ]]; then
        while true; do
            echo -e "${YELLOW}Enter your domain name (e.g., nfguard.example.com):${NC}"
            read -r CUSTOM_DOMAIN
            if [[ $CUSTOM_DOMAIN =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
                echo -e "${GREEN}Domain: $CUSTOM_DOMAIN${NC}"

                echo -e "${YELLOW}Do you want to automatically obtain a Let's Encrypt SSL certificate? (y/n)${NC}"
                read -r ssl_choice
                if [[ "$ssl_choice" =~ ^[Yy]$ ]]; then
                    USE_LETSENCRYPT="yes"
                    echo -e "${YELLOW}Enter your email for Let's Encrypt notifications:${NC}"
                    read -r LETSENCRYPT_EMAIL
                    echo -e "${GREEN}Let's Encrypt will be configured for $CUSTOM_DOMAIN${NC}"
                else
                    USE_LETSENCRYPT="no"
                    echo -e "${YELLOW}Self-signed certificates will be used${NC}"
                fi
                break
            else
                echo -e "${RED}Invalid domain name. Please enter a valid domain.${NC}"
            fi
        done
    else
        CUSTOM_DOMAIN=""
        USE_LETSENCRYPT="no"
        echo -e "${YELLOW}WebGUI will be accessible via IP address only${NC}"
    fi

    # Save preferences
    cat > /tmp/nfguard_prefs << EOF
FIREWALL_BACKEND="$FIREWALL_BACKEND"
CUSTOM_DOMAIN="$CUSTOM_DOMAIN"
USE_LETSENCRYPT="$USE_LETSENCRYPT"
LETSENCRYPT_EMAIL="$LETSENCRYPT_EMAIL"
EOF
}

check_dependencies() {
    echo -e "${YELLOW}Checking dependencies...${NC}"

    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    MISSING_DEPS=()

    # Check firewall backend
    if [ "$FIREWALL_BACKEND" = "ufw" ]; then
        if ! command -v ufw &> /dev/null; then
            MISSING_DEPS+=("ufw")
        fi
    else
        if ! command -v iptables &> /dev/null; then
            MISSING_DEPS+=("iptables")
        fi
    fi

    # Check certbot if Let's Encrypt is enabled
    if [ "$USE_LETSENCRYPT" = "yes" ]; then
        if ! command -v certbot &> /dev/null; then
            MISSING_DEPS+=("certbot")
        fi
    fi

    if ! command -v node &> /dev/null; then
        MISSING_DEPS+=("nodejs")
    else
        # Check Node.js version (require 22.19.0+)
        NODE_VERSION=$(node --version | cut -d'v' -f2)
        NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1)
        NODE_MINOR=$(echo $NODE_VERSION | cut -d'.' -f2)
        NODE_PATCH=$(echo $NODE_VERSION | cut -d'.' -f3)

        if [ "$NODE_MAJOR" -lt 22 ] || \
           [ "$NODE_MAJOR" -eq 22 -a "$NODE_MINOR" -lt 19 ]; then
            echo -e "${YELLOW}Node.js version $NODE_VERSION detected. Upgrading to v22.19.0 LTS...${NC}"
            MISSING_DEPS+=("nodejs")
        fi
    fi

    if ! command -v npm &> /dev/null; then
        MISSING_DEPS+=("npm")
    fi

    if ! command -v openssl &> /dev/null; then
        MISSING_DEPS+=("openssl")
    fi

    if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
        echo -e "${YELLOW}Missing dependencies: ${MISSING_DEPS[*]}${NC}"
        return 1
    fi

    return 0
}

install_dependencies() {
    echo -e "${YELLOW}Installing dependencies...${NC}"

    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    # Determine firewall package
    FIREWALL_PKG="iptables"
    if [ "$FIREWALL_BACKEND" = "ufw" ]; then
        FIREWALL_PKG="ufw"
    fi

    # Determine if certbot is needed
    CERTBOT_PKG=""
    if [ "$USE_LETSENCRYPT" = "yes" ]; then
        CERTBOT_PKG="certbot"
    fi

    case $ID in
        ubuntu|debian)
            apt-get update
            # Install Node.js 22 from NodeSource
            curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
            apt-get install -y $FIREWALL_PKG nodejs openssl curl wget $CERTBOT_PKG
            if [ "$USE_LETSENCRYPT" = "yes" ]; then
                apt-get install -y python3-certbot-nginx
            fi
            ;;
        fedora|rhel|centos)
            # Install Node.js 22 from NodeSource
            curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
            dnf install -y $FIREWALL_PKG nodejs openssl curl wget $CERTBOT_PKG
            if [ "$USE_LETSENCRYPT" = "yes" ]; then
                dnf install -y python3-certbot-nginx
            fi
            ;;
        arch|manjaro)
            pacman -Sy --noconfirm $FIREWALL_PKG nodejs npm openssl curl wget $CERTBOT_PKG
            if [ "$USE_LETSENCRYPT" = "yes" ]; then
                pacman -Sy --noconfirm certbot-nginx
            fi
            ;;
        opensuse*)
            # Install Node.js 22 from NodeSource
            curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
            zypper install -y $FIREWALL_PKG nodejs openssl curl wget $CERTBOT_PKG
            ;;
        alpine)
            apk add --no-cache $FIREWALL_PKG nodejs npm openssl curl wget $CERTBOT_PKG
            ;;
        *)
            echo -e "${RED}Unsupported distribution. Please install dependencies manually:${NC}"
            echo "- $FIREWALL_PKG"
            echo "- nodejs 22.19.0 LTS"
            echo "- npm"
            echo "- openssl"
            if [ "$USE_LETSENCRYPT" = "yes" ]; then
                echo "- certbot"
            fi
            exit 1
            ;;
    esac
}

install_nfguard() {
    echo -e "${YELLOW}Installing NFGuard...${NC}"

    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    INSTALL_DIR="/opt/nfguard"
    CONFIG_DIR="/etc/nfguard"
    LOG_DIR="/var/log/nfguard"

    mkdir -p $INSTALL_DIR
    mkdir -p $CONFIG_DIR
    mkdir -p $LOG_DIR

    if [ -d "./src" ] && [ -f "./package.json" ]; then
        cp -r ./* $INSTALL_DIR/
    else
        echo -e "${RED}Source files not found. Please run this script from the NFGuard directory.${NC}"
        exit 1
    fi

    cd $INSTALL_DIR

    echo -e "${YELLOW}Installing Node.js dependencies...${NC}"
    npm install --production

    # Create configuration file with user preferences
    cat > $CONFIG_DIR/config.json << EOF
{
    "firewall": {
        "backend": "$FIREWALL_BACKEND"
    },
    "webgui": {
        "port": 8443,
        "domain": "$CUSTOM_DOMAIN",
        "ssl": {
            "useLetsEncrypt": $([ "$USE_LETSENCRYPT" = "yes" ] && echo "true" || echo "false"),
            "email": "$LETSENCRYPT_EMAIL"
        }
    },
    "security": {
        "jwtSecret": "$(openssl rand -hex 32)",
        "sessionTimeout": 3600
    }
}
EOF

    # Copy preferences to install directory for runtime access
    if [ -f /tmp/nfguard_prefs ]; then
        cp /tmp/nfguard_prefs $CONFIG_DIR/install_prefs
    fi

    ln -sf $INSTALL_DIR/src/cli/index.js /usr/local/bin/nfguard
    chmod +x /usr/local/bin/nfguard

    echo -e "${GREEN}NFGuard installed successfully!${NC}"
}

create_systemd_service() {
    echo -e "${YELLOW}Creating systemd service...${NC}"

    cat > /etc/systemd/system/nfguard.service << EOF
[Unit]
Description=NFGuard Firewall Management Service
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/nfguard
ExecStart=/usr/bin/node /opt/nfguard/src/index.js
Restart=always
RestartSec=10
StandardOutput=append:/var/log/nfguard/service.log
StandardError=append:/var/log/nfguard/error.log
Environment="NODE_ENV=production"
Environment="PORT=8443"

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable nfguard.service

    echo -e "${GREEN}Systemd service created successfully!${NC}"
}

create_openrc_service() {
    echo -e "${YELLOW}Creating OpenRC service...${NC}"

    cat > /etc/init.d/nfguard << 'EOF'
#!/sbin/openrc-run

name="NFGuard"
description="NFGuard Firewall Management Service"
command="/usr/bin/node"
command_args="/opt/nfguard/src/index.js"
command_background="yes"
pidfile="/run/${RC_SVCNAME}.pid"
start_stop_daemon_args="--stdout /var/log/nfguard/service.log --stderr /var/log/nfguard/error.log"

depend() {
    need net
    after iptables
}

start_pre() {
    checkpath --directory --mode 0755 /var/log/nfguard
}
EOF

    chmod +x /etc/init.d/nfguard
    rc-update add nfguard default

    echo -e "${GREEN}OpenRC service created successfully!${NC}"
}

setup_firewall_rules() {
    echo -e "${YELLOW}Setting up initial firewall rules...${NC}"

    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    # Detect SSH port
    SSH_PORT=$(ss -tlnp | grep :22 | head -1 | sed 's/.*:\([0-9]*\).*/\1/' || echo "22")

    if [ "$FIREWALL_BACKEND" = "ufw" ]; then
        echo -e "${YELLOW}Configuring UFW firewall...${NC}"

        # Reset UFW
        ufw --force reset

        # Set default policies
        ufw default deny incoming
        ufw default allow outgoing

        # Allow essential services
        ufw allow $SSH_PORT/tcp comment "SSH access"
        ufw allow 8443/tcp comment "NFGuard WebGUI"

        # Enable UFW
        ufw --force enable

        echo -e "${GREEN}UFW firewall configured!${NC}"
    else
        echo -e "${YELLOW}Configuring IPTables firewall...${NC}"

        # Create NFGuard chains
        iptables -t filter -N NFGUARD-INPUT 2>/dev/null || true
        iptables -t filter -F NFGUARD-INPUT

        # Remove existing jump rules and re-add at the beginning
        iptables -D INPUT -j NFGUARD-INPUT 2>/dev/null || true
        iptables -I INPUT 1 -j NFGUARD-INPUT

        # Essential rules in correct order
        iptables -A NFGUARD-INPUT -i lo -j ACCEPT
        iptables -A NFGUARD-INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
        iptables -A NFGUARD-INPUT -p tcp --dport $SSH_PORT -j ACCEPT
        iptables -A NFGUARD-INPUT -p tcp --dport 8443 -j ACCEPT
        iptables -A NFGUARD-INPUT -j RETURN

        # Set default policies
        iptables -P INPUT DROP
        iptables -P FORWARD DROP
        iptables -P OUTPUT ACCEPT

        echo -e "${GREEN}IPTables firewall configured!${NC}"
    fi
}

generate_ssl_certificates() {
    echo -e "${YELLOW}Generating SSL certificates...${NC}"

    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    SSL_DIR="/etc/nfguard/ssl"
    mkdir -p $SSL_DIR

    if [ "$USE_LETSENCRYPT" = "yes" ] && [ -n "$CUSTOM_DOMAIN" ]; then
        echo -e "${YELLOW}Obtaining Let's Encrypt certificate for $CUSTOM_DOMAIN...${NC}"

        # Temporarily allow HTTP for certificate verification
        if [ "$FIREWALL_BACKEND" = "ufw" ]; then
            ufw allow 80/tcp comment "HTTP for Let's Encrypt"
            ufw allow 443/tcp comment "HTTPS"
        else
            iptables -I NFGUARD-INPUT -p tcp --dport 80 -j ACCEPT
            iptables -I NFGUARD-INPUT -p tcp --dport 443 -j ACCEPT
        fi

        # Obtain certificate
        certbot certonly --standalone \
            --non-interactive \
            --agree-tos \
            --email "$LETSENCRYPT_EMAIL" \
            -d "$CUSTOM_DOMAIN"

        if [ $? -eq 0 ]; then
            # Link Let's Encrypt certificates
            ln -sf "/etc/letsencrypt/live/$CUSTOM_DOMAIN/fullchain.pem" "$SSL_DIR/cert.pem"
            ln -sf "/etc/letsencrypt/live/$CUSTOM_DOMAIN/privkey.pem" "$SSL_DIR/key.pem"

            echo -e "${GREEN}Let's Encrypt certificate obtained successfully!${NC}"

            # Setup auto-renewal
            (crontab -l 2>/dev/null; echo "0 2 * * * certbot renew --quiet --post-hook 'systemctl restart nfguard'") | crontab -
        else
            echo -e "${YELLOW}Let's Encrypt certificate failed. Falling back to self-signed...${NC}"
            USE_LETSENCRYPT="no"
        fi

        # Remove temporary HTTP rule
        if [ "$FIREWALL_BACKEND" = "ufw" ]; then
            ufw delete allow 80/tcp
        else
            iptables -D NFGUARD-INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
        fi
    fi

    # Generate self-signed certificate if Let's Encrypt failed or not requested
    if [ "$USE_LETSENCRYPT" != "yes" ] || [ ! -f "$SSL_DIR/cert.pem" ]; then
        echo -e "${YELLOW}Generating self-signed certificate...${NC}"

        CERT_CN="localhost"
        if [ -n "$CUSTOM_DOMAIN" ]; then
            CERT_CN="$CUSTOM_DOMAIN"
        fi

        openssl req -x509 -newkey rsa:2048 -nodes \
            -keyout $SSL_DIR/key.pem \
            -out $SSL_DIR/cert.pem \
            -days 365 \
            -subj "/C=US/ST=State/L=City/O=NFGuard/CN=$CERT_CN"

        chmod 600 $SSL_DIR/key.pem
        chmod 644 $SSL_DIR/cert.pem

        echo -e "${GREEN}Self-signed SSL certificate generated!${NC}"
    fi
}

start_service() {
    echo -e "${YELLOW}Starting NFGuard service...${NC}"

    if command -v systemctl &> /dev/null; then
        systemctl start nfguard
        systemctl status nfguard --no-pager
    elif command -v rc-service &> /dev/null; then
        rc-service nfguard start
    else
        echo -e "${YELLOW}Please start the service manually:${NC}"
        echo "node /opt/nfguard/src/index.js"
    fi
}

print_success_message() {
    # Load preferences
    if [ -f /tmp/nfguard_prefs ]; then
        source /tmp/nfguard_prefs
    fi

    SERVER_IP=$(hostname -I | awk '{print $1}')
    WEBGUI_URL="https://$SERVER_IP:8443"

    if [ -n "$CUSTOM_DOMAIN" ]; then
        WEBGUI_URL="https://$CUSTOM_DOMAIN:8443"
    fi

    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════╗"
    echo "║         NFGuard Installation Complete!           ║"
    echo "╠═══════════════════════════════════════════════════╣"
    echo "║                                                   ║"
    echo "║  WebGUI: $WEBGUI_URL"
    [ ${#WEBGUI_URL} -lt 43 ] && printf "%*s║\n" $((43-${#WEBGUI_URL})) ""
    echo "║  Default Login: nfguard / nfguard                ║"
    echo "║                                                   ║"
    echo "║  Firewall Backend: $FIREWALL_BACKEND"
    [ ${#FIREWALL_BACKEND} -lt 33 ] && printf "%*s║\n" $((33-${#FIREWALL_BACKEND})) ""
    if [ "$USE_LETSENCRYPT" = "yes" ]; then
        echo "║  SSL Certificate: Let's Encrypt                  ║"
    else
        echo "║  SSL Certificate: Self-Signed                    ║"
    fi
    echo "║                                                   ║"
    echo "║  CLI Commands:                                   ║"
    echo "║  - nfguard --help                               ║"
    echo "║  - nfguard allow -p 80                          ║"
    echo "║  - nfguard block -s 192.168.1.0/24             ║"
    echo "║  - nfguard geo-block CN                         ║"
    echo "║  - nfguard list                                 ║"
    echo "║  - nfguard firewall enable/disable/restart      ║"
    echo "║  - nfguard reload-defaults                      ║"
    echo "║                                                   ║"
    echo "║  Service Management:                            ║"
    echo "║  - systemctl start nfguard                      ║"
    echo "║  - systemctl stop nfguard                       ║"
    echo "║  - systemctl restart nfguard                    ║"
    echo "║  - systemctl status nfguard                     ║"
    echo "║                                                   ║"
    echo "║  IMPORTANT: Change the default password!        ║"
    echo "╚═══════════════════════════════════════════════════╝"
    echo -e "${NC}"

    # Cleanup temporary files
    rm -f /tmp/nfguard_prefs
}

main() {
    detect_distro
    get_installation_preferences

    if ! check_dependencies; then
        echo -e "${YELLOW}Installing missing dependencies...${NC}"
        install_dependencies
    fi

    install_nfguard

    if command -v systemctl &> /dev/null; then
        create_systemd_service
    elif command -v rc-service &> /dev/null; then
        create_openrc_service
    fi

    setup_firewall_rules
    generate_ssl_certificates

    echo -e "${YELLOW}Do you want to start NFGuard now? (y/n)${NC}"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        start_service
    fi

    print_success_message
}

main "$@"