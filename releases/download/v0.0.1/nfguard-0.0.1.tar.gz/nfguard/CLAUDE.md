# NFGuard - Claude Development Memory Bank

## Project Overview

**NFGuard** is an advanced firewall management tool providing both CLI and WebGUI interfaces for managing IPTables rules on Linux systems. This document serves as a comprehensive memory bank for continued development and maintenance.

**Version**: v0.0.1
**Developer**: Lucas Catão de Moraes <lucas@dolutech.com>
**Repository**: https://github.com/nfguard/nfguard
**Website**: https://nfguard.org
**Company**: https://dolutech.com

## Project Architecture

### Core Design Principles

1. **Dual Interface Philosophy**: Both CLI and WebGUI must maintain feature parity
2. **Real-time Synchronization**: Changes in one interface immediately reflect in the other
3. **Direct IPTables Integration**: No abstraction layers, direct kernel communication
4. **Security First**: All operations are authenticated and logged
5. **Zero External Dependencies**: Self-contained package with all dependencies included

### Technology Stack

- **Backend**: Node.js 22.19.0 LTS + Express.js
- **Frontend**: Vanilla HTML5/CSS3/JavaScript (no frameworks)
- **Authentication**: JWT + bcryptjs
- **Firewall**: Direct IPTables integration (switched from NFTables for better compatibility)
- **Geo-blocking**: MaxMind GeoLite2 database
- **Logging**: Winston with structured logging
- **CLI**: Commander.js with chalk for colors

## Project Structure

```
nfguard/
├── src/                          # Main source code
│   ├── core/                     # Core functionality modules
│   │   ├── iptables-manager.js   # IPTables operations and rule management
│   │   ├── geo-blocker.js        # Geo-blocking with MaxMind integration
│   │   └── logger.js             # Centralized logging system
│   ├── auth/                     # Authentication system
│   │   └── auth-manager.js       # JWT authentication and user management
│   ├── cli/                      # Command line interface
│   │   └── index.js              # CLI entry point with Commander.js
│   ├── GeoLite/                  # MaxMind GeoLite2 database
│   │   ├── GeoLite2-Country.mmdb # IP geolocation database (9.8MB)
│   │   ├── COPYRIGHT.txt         # MaxMind copyright
│   │   └── LICENSE.txt           # MaxMind license
│   └── index.js                  # Main server entry point
├── web/                          # WebGUI files
│   ├── index.html                # Single-page application
│   ├── app.js                    # Frontend JavaScript logic
│   └── styles.css                # Complete CSS styling
├── Documentation.md              # Complete technical documentation
├── install.sh                    # Universal Linux installer
├── build.sh                      # Package build script
├── package.json                  # Node.js dependencies and metadata
├── README.md                     # Quick start guide
└── CLAUDE.md                     # This development memory bank
```

## Core Modules Deep Dive

### 1. IPTables Manager (`src/core/iptables-manager.js`)

**Purpose**: Direct interface with Linux IPTables kernel module

**Key Functions**:
- `initializeIPTables()`: Sets up basic firewall ruleset
- `addRule(rule, user)`: Adds firewall rules with audit logging
- `deleteRule(ruleId, user)`: Removes rules by ID
- `listRules()`: Returns both saved and active rules
- `exportRules()` / `importRules()`: Configuration backup/restore
- `flushRules()`: Complete ruleset reset (dangerous operation)

**Technical Implementation**:
- Uses `child_process.exec()` for IPTables commands
- Maintains rule metadata in `/etc/nfguard/rules.json`
- Creates custom chains (NFGUARD-INPUT, NFGUARD-OUTPUT, NFGUARD-FORWARD)
- Audit logging for all operations with user tracking

**Critical Patterns**:
```javascript
// Rule addition with audit trail
const command = `iptables -A NFGUARD-INPUT -p tcp --dport ${port} -j ACCEPT`;
await this.executeCommand(command);
logger.audit('ADD_RULE', user, { rule, timestamp: new Date().toISOString() });
```

### 2. Geo-Blocker (`src/core/geo-blocker.js`)

**Purpose**: Country-based IP blocking using MaxMind GeoLite2 database

**Key Functions**:
- `blockCountry(countryCode, user)`: Blocks entire countries
- `unblockCountry(countryCode)`: Removes country blocks
- `getCountryIPRanges(countryCode)`: Generates/caches IP ranges
- `checkIP(ip)`: Real-time IP geolocation lookup
- `initializeGeoDatabase()`: Loads MaxMind database

**Technical Implementation**:
- MaxMind reader using `maxmind` npm package
- Intelligent IP range generation with caching (24h TTL)
- Fallback static ranges for reliability
- IPTables rule generation per IP range

**Critical Patterns**:
```javascript
// Geo-blocking with MaxMind + fallback
if (this.mmdbReader) {
    const result = this.mmdbReader.get(ip);
    countryCode = result.country.iso_code;
} else {
    // Use fallback static ranges
    return this.getFallbackRanges(countryCode);
}
```

### 3. Authentication Manager (`src/auth/auth-manager.js`)

**Purpose**: Complete user authentication and session management

**Key Functions**:
- `authenticate(username, password)`: Login with JWT generation
- `verifyToken(token)`: JWT validation middleware
- `changePassword()` / `changeUsername()`: User management
- `createUser()` / `deleteUser()`: Admin user operations
- `initializeDefaultUser()`: Creates default nfguard/nfguard user

**Security Features**:
- bcryptjs password hashing (10 rounds)
- JWT with 24-hour expiration
- Secure secret generation (`crypto.randomBytes(64)`)
- Role-based access control (admin/viewer)
- File permissions 0600 for sensitive data

### 4. Logger (`src/core/logger.js`)

**Purpose**: Centralized logging with audit trails

**Features**:
- Application logs (`/var/log/nfguard/app.log`)
- Audit logs (`/var/log/nfguard/audit.log`)
- Structured JSON logging with Winston
- Automatic log rotation
- API endpoints for log retrieval

## WebGUI Architecture

### Single Page Application Design

**File**: `web/index.html` (415 lines)
- Complete SPA in single HTML file
- Tab-based navigation system
- Modal dialogs for user interactions
- Responsive design with CSS Grid/Flexbox
- Fixed footer layout

**JavaScript**: `web/app.js` (650+ lines)
- Pure vanilla JavaScript (no frameworks)
- API communication with fetch()
- Real-time updates and synchronization
- Client-side authentication handling

**Styling**: `web/styles.css` (750+ lines)
- CSS custom properties (variables)
- Dark theme implementation
- Responsive design breakpoints
- Professional UI components
- Fixed footer positioning

### Key Frontend Patterns

```javascript
// API communication pattern
async function apiCall(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    const response = await fetch(`/api${endpoint}`, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        ...options
    });
    return response.json();
}

// Real-time data refresh
setInterval(async () => {
    await Promise.all([
        loadRules(),
        loadStats(),
        loadLogs()
    ]);
}, 5000);
```

## CLI Architecture

### Commander.js Implementation

**File**: `src/cli/index.js`
- Complete CLI interface with subcommands
- Colored output using chalk
- Table formatting with cli-table3
- Error handling and user feedback

### CLI Command Structure

```bash
nfguard init                      # Initialize IPTables
nfguard allow -p 80 -P tcp       # Allow port
nfguard block -s 192.168.1.100   # Block IP
nfguard geo-block CN             # Block country
nfguard list                     # List all rules
nfguard export /path/file.conf   # Export configuration
nfguard stats                    # Show statistics
```

## Installation System

### Universal Installer (`install.sh`)

**Capabilities**:
- Automatic distribution detection
- Node.js 22.19.0 LTS installation via NodeSource
- IPTables setup and configuration
- Service creation (systemd/OpenRC)
- SSL certificate generation
- Directory structure creation

**Supported Distributions**:
- Ubuntu 22.04 LTS+
- Debian 12+
- CentOS/RHEL 8+
- Fedora 38+
- Arch Linux
- OpenSUSE 18+
- Alpine Linux 3.18+

### Build System (`build.sh`)

**Process**:
1. Creates clean build directory
2. Copies all source files
3. Installs production dependencies
4. Generates clean package.json
5. Creates comprehensive README
6. Packages as tar.gz (6.3MB)

## Database and Storage

### File Locations

```
/opt/nfguard/              # Application installation
/etc/nfguard/              # Configuration files
├── users.json             # User accounts (0600)
├── rules.json             # Rule backup/metadata
├── geo-blocks.json        # Geo-blocking rules
├── .secret                # JWT secret (0600)
└── ssl/                   # SSL certificates
    ├── cert.pem
    └── key.pem
/var/log/nfguard/          # Log files
├── app.log                # Application logs
├── audit.log              # Audit trail
├── service.log            # Service output
└── error.log              # Error logs
```

### Data Flow Architecture

```
CLI/WebGUI → Authentication → IPTables Manager → Linux Kernel
    ↓              ↓              ↓                    ↓
Audit Logs ← Logger ← Rule Metadata ← IPTables Rules
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User authentication
- `POST /api/auth/refresh` - Token refresh
- `GET /api/auth/profile` - User profile
- `POST /api/auth/change-password` - Password change

### Rule Management
- `GET /api/rules` - List all rules
- `POST /api/rules` - Add new rule
- `DELETE /api/rules/:id` - Delete rule
- `POST /api/rules/flush` - Clear all rules (admin)
- `GET /api/rules/export` - Export configuration
- `POST /api/rules/import` - Import configuration (admin)

### Geo-blocking
- `POST /api/geo/block` - Block country
- `DELETE /api/geo/block/:country` - Unblock country
- `GET /api/geo/blocked` - List blocked countries
- `GET /api/geo/check/:ip` - Check IP location

### Monitoring
- `GET /api/stats` - System statistics
- `GET /api/logs` - Application logs
- `GET /api/logs/audit` - Audit logs
- `GET /api/health` - Health check

## Security Architecture

### Authentication Flow

1. **User Login**: Username/password → bcrypt verification
2. **JWT Generation**: 24-hour token with user payload
3. **Request Authentication**: Bearer token validation
4. **Role Authorization**: Admin/viewer permission checks
5. **Audit Logging**: All actions tracked with timestamps

### File Security
- Configuration files: 0600 permissions (root only)
- JWT secret: Cryptographically secure random generation
- SSL certificates: Auto-generated or custom
- Logs: Structured with user attribution

### Network Security
- HTTPS-only WebGUI (self-signed certificates)
- IPTables integration for packet filtering
- No external API dependencies
- Local MaxMind database (no external calls)

## Development Patterns

### Error Handling

```javascript
// Consistent error handling pattern
try {
    const result = await operation();
    logger.info('Operation successful', { operation, result });
    return { success: true, result };
} catch (error) {
    logger.error('Operation failed', { operation, error: error.message });
    return { success: false, error: error.message };
}
```

### Audit Logging

```javascript
// All significant operations must be audited
logger.audit('OPERATION_TYPE', username, {
    details: operationDetails,
    timestamp: new Date().toISOString()
});
```

### CLI/WebGUI Synchronization

```javascript
// Both interfaces use the same backend operations
const result = await iptablesManager.addRule(rule, user);
// Rule immediately available in both CLI and WebGUI
```

## Known Technical Decisions

### Why IPTables Instead of NFTables?

1. **Better Compatibility**: IPTables works on more Linux distributions
2. **Wider Support**: More documentation and community support
3. **Stability**: Mature and battle-tested
4. **Easier Debugging**: Simpler rule structure

### Why Vanilla JavaScript Instead of React/Vue?

1. **Zero Dependencies**: No external framework requirements
2. **Performance**: Faster loading and execution
3. **Simplicity**: Easier to maintain and debug
4. **Size Constraints**: Smaller package size

### Why MaxMind GeoLite2 Instead of API Services?

1. **Offline Operation**: No external dependencies
2. **Performance**: Local lookups are instant
3. **Reliability**: No API rate limits or downtime
4. **Privacy**: No external data sharing

### Why Node.js 22.19.0 LTS?

1. **Latest LTS**: Long-term support and stability
2. **Performance**: V8 engine improvements
3. **Security**: Latest security patches
4. **Modern Features**: ES2023+ support

## Performance Characteristics

### Resource Usage
- **Memory**: ~50MB base, ~100MB under load
- **CPU**: <1% idle, 2-5% during operations
- **Storage**: 50MB application + logs
- **Network**: Port 8443 (HTTPS), Port 22 (SSH)

### Scaling Considerations
- Single-server deployment optimized
- Rule processing is O(n) where n = number of rules
- MaxMind database loads into memory (9.8MB)
- Log rotation prevents disk space issues

## Common Issues and Solutions

### 1. IPTables Permission Issues
**Problem**: `iptables: Operation not permitted`
**Solution**: Ensure root privileges and iptables module loaded

### 2. Node.js Version Conflicts
**Problem**: `EBADENGINE` errors during installation
**Solution**: Install script automatically upgrades to Node.js 22.19.0

### 3. SSL Certificate Warnings
**Problem**: Browser warning about self-signed certificates
**Solution**: Expected behavior, users should accept certificate

### 4. Geo-blocking Not Working
**Problem**: Countries not being blocked effectively
**Solution**: Check MaxMind database path and IPTables rule generation

## Recent Changes (Latest Update)

### v0.0.1 Update - IPTables Migration

**Changes Made**:
1. **Firewall Engine**: Migrated from NFTables to IPTables for better compatibility
2. **WebGUI Fixes**: Fixed rule display confusion (Allow vs Accept)
3. **Footer Layout**: Fixed WebGUI footer positioning and styling
4. **Documentation**: Restructured Documentation.md and CLAUDE.md
5. **Installer**: Updated to install iptables instead of nftables

**Files Modified**:
- `src/core/iptables-manager.js` (NEW - replaces nftables-manager.js)
- `src/core/geo-blocker.js` (updated for iptables)
- `src/index.js` (updated imports)
- `src/cli/index.js` (updated for iptables)
- `web/app.js` (fixed rule display)
- `web/styles.css` (fixed footer layout)
- `install.sh` (updated for iptables)

## Version History

### v0.0.1 (Initial Release)

- Complete CLI and WebGUI implementation
- IPTables integration (migrated from NFTables)
- MaxMind GeoLite2 geo-blocking
- JWT authentication system
- Universal Linux installer
- Node.js 22.19.0 LTS support
- 6.3MB standalone package
- Fixed WebGUI layout and functionality

---

**Developer**: Lucas Catão de Moraes
**Email**: lucas@dolutech.com
**Company**: https://dolutech.com
**Project**: https://nfguard.org
**Repository**: https://github.com/nfguard/nfguard
**Issues**: https://github.com/nfguard/nfguard/issues

---

*This document serves as the complete memory bank for NFGuard development. Keep it updated with all architectural decisions, technical implementations, and development patterns for continued project evolution.*