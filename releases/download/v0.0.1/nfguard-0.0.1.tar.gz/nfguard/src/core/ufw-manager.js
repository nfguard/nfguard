const { exec } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execPromise = promisify(exec);

class UFWManager {
    constructor() {
        this.initialized = false;
        this.defaultSSHPort = 22;
        this.webguiPort = 8443;
    }

    async executeCommand(command) {
        try {
            logger.info(`Executing UFW command: ${command}`);
            const { stdout, stderr } = await execPromise(command);
            if (stderr && !stderr.includes('Rules updated')) {
                logger.warn(`UFW command warning: ${stderr}`);
            }
            return stdout;
        } catch (error) {
            logger.error(`UFW command failed: ${command}`, { error: error.message });
            throw error;
        }
    }

    async initializeUFW() {
        try {
            await this.executeCommand('ufw --force reset');
            await this.executeCommand('ufw --force enable');

            await this.executeCommand(`ufw allow ${this.defaultSSHPort}/tcp comment "SSH access"`);
            await this.executeCommand(`ufw allow ${this.webguiPort}/tcp comment "NFGuard WebGUI"`);

            this.initialized = true;
            logger.info('UFW initialized successfully');
        } catch (error) {
            logger.error('Failed to initialize UFW', { error: error.message });
            throw error;
        }
    }

    async enableFirewall() {
        try {
            await this.executeCommand('ufw --force enable');
            logger.audit('Firewall enabled via UFW');
            return true;
        } catch (error) {
            logger.error('Failed to enable UFW firewall', { error: error.message });
            throw error;
        }
    }

    async disableFirewall() {
        try {
            await this.executeCommand('ufw --force disable');
            logger.audit('Firewall disabled via UFW');
            return true;
        } catch (error) {
            logger.error('Failed to disable UFW firewall', { error: error.message });
            throw error;
        }
    }

    async restartFirewall() {
        try {
            await this.disableFirewall();
            await new Promise(resolve => setTimeout(resolve, 1000));
            await this.enableFirewall();
            logger.audit('Firewall restarted via UFW');
            return true;
        } catch (error) {
            logger.error('Failed to restart UFW firewall', { error: error.message });
            throw error;
        }
    }

    async flushRules() {
        try {
            await this.executeCommand('ufw --force reset');
            await this.executeCommand('ufw --force enable');
            await this.executeCommand(`ufw allow ${this.defaultSSHPort}/tcp comment "SSH access"`);
            await this.executeCommand(`ufw allow ${this.webguiPort}/tcp comment "NFGuard WebGUI"`);
            logger.audit('UFW rules flushed and defaults restored');
            return true;
        } catch (error) {
            logger.error('Failed to flush UFW rules', { error: error.message });
            throw error;
        }
    }

    async reloadDefaultRules() {
        return await this.flushRules();
    }

    async allowPort(port, protocol = 'tcp', comment = '') {
        try {
            const commentStr = comment ? ` comment "${comment}"` : '';
            await this.executeCommand(`ufw allow ${port}/${protocol}${commentStr}`);
            logger.audit(`Port ${port}/${protocol} allowed via UFW`, { comment });
            return true;
        } catch (error) {
            logger.error(`Failed to allow port ${port}/${protocol}`, { error: error.message });
            throw error;
        }
    }

    async denyPort(port, protocol = 'tcp', comment = '') {
        try {
            const commentStr = comment ? ` comment "${comment}"` : '';
            await this.executeCommand(`ufw deny ${port}/${protocol}${commentStr}`);
            logger.audit(`Port ${port}/${protocol} denied via UFW`, { comment });
            return true;
        } catch (error) {
            logger.error(`Failed to deny port ${port}/${protocol}`, { error: error.message });
            throw error;
        }
    }

    async removeRule(port, protocol = 'tcp') {
        try {
            await this.executeCommand(`ufw delete allow ${port}/${protocol}`);
            await this.executeCommand(`ufw delete deny ${port}/${protocol}`);
            logger.audit(`Rule for port ${port}/${protocol} removed via UFW`);
            return true;
        } catch (error) {
            logger.error(`Failed to remove rule for port ${port}/${protocol}`, { error: error.message });
            return false;
        }
    }

    async blockIP(ip, comment = '') {
        try {
            const commentStr = comment ? ` comment "${comment}"` : '';
            await this.executeCommand(`ufw deny from ${ip}${commentStr}`);
            logger.audit(`IP ${ip} blocked via UFW`, { comment });
            return true;
        } catch (error) {
            logger.error(`Failed to block IP ${ip}`, { error: error.message });
            throw error;
        }
    }

    async allowIP(ip, comment = '') {
        try {
            const commentStr = comment ? ` comment "${comment}"` : '';
            await this.executeCommand(`ufw allow from ${ip}${commentStr}`);
            logger.audit(`IP ${ip} allowed via UFW`, { comment });
            return true;
        } catch (error) {
            logger.error(`Failed to allow IP ${ip}`, { error: error.message });
            throw error;
        }
    }

    async unblockIP(ip) {
        try {
            await this.executeCommand(`ufw delete deny from ${ip}`);
            await this.executeCommand(`ufw delete allow from ${ip}`);
            logger.audit(`IP ${ip} unblocked via UFW`);
            return true;
        } catch (error) {
            logger.error(`Failed to unblock IP ${ip}`, { error: error.message });
            return false;
        }
    }

    async blockCountryRanges(ranges, country) {
        try {
            let blockedCount = 0;
            for (const range of ranges) {
                try {
                    await this.executeCommand(`ufw deny from ${range} comment "Geo-block ${country}"`);
                    blockedCount++;
                } catch (error) {
                    logger.warn(`Failed to block range ${range}`, { error: error.message });
                }
            }
            logger.audit(`Geo-blocking activated for ${country}`, {
                ranges: blockedCount,
                country
            });
            return true;
        } catch (error) {
            logger.error(`Failed to block country ranges for ${country}`, { error: error.message });
            throw error;
        }
    }

    async unblockCountryRanges(ranges, country) {
        try {
            let unblockedCount = 0;
            for (const range of ranges) {
                try {
                    await this.executeCommand(`ufw delete deny from ${range}`);
                    unblockedCount++;
                } catch (error) {
                    logger.warn(`Failed to unblock range ${range}`, { error: error.message });
                }
            }
            logger.audit(`Geo-blocking deactivated for ${country}`, {
                ranges: unblockedCount,
                country
            });
            return true;
        } catch (error) {
            logger.error(`Failed to unblock country ranges for ${country}`, { error: error.message });
            throw error;
        }
    }

    async restrictWebGUIAccess(allowedIP) {
        try {
            await this.executeCommand(`ufw delete allow ${this.webguiPort}/tcp`);

            await this.executeCommand(`ufw allow from ${allowedIP} to any port ${this.webguiPort} proto tcp comment "WebGUI restricted access"`);

            logger.audit('WebGUI access restricted via UFW', { allowedIP });
            return true;
        } catch (error) {
            logger.error('Failed to restrict WebGUI access via UFW', { error: error.message });
            throw error;
        }
    }

    async removeWebGUIRestriction() {
        try {
            await this.executeCommand(`ufw delete allow from any to any port ${this.webguiPort}`);

            await this.executeCommand(`ufw allow ${this.webguiPort}/tcp comment "NFGuard WebGUI"`);

            logger.audit('WebGUI access restriction removed via UFW');
            return true;
        } catch (error) {
            logger.error('Failed to remove WebGUI restriction via UFW', { error: error.message });
            throw error;
        }
    }

    async listRules() {
        try {
            const output = await this.executeCommand('ufw status numbered');
            return output;
        } catch (error) {
            logger.error('Failed to list UFW rules', { error: error.message });
            throw error;
        }
    }

    async getStatus() {
        try {
            const output = await this.executeCommand('ufw status verbose');
            return {
                enabled: output.includes('Status: active'),
                rules: output
            };
        } catch (error) {
            logger.error('Failed to get UFW status', { error: error.message });
            throw error;
        }
    }

    async getRules() {
        try {
            const output = await this.listRules();
            const rules = [];
            const lines = output.split('\n');

            for (const line of lines) {
                if (line.match(/^\[\s*\d+\]/)) {
                    const parts = line.split(/\s+/);
                    if (parts.length >= 4) {
                        rules.push({
                            number: parts[0].replace(/[\[\]]/g, ''),
                            action: parts[1],
                            from: parts[2],
                            to: parts[3],
                            proto: parts[4] || '',
                            comment: line.includes('#') ? line.split('#')[1].trim() : ''
                        });
                    }
                }
            }

            return rules;
        } catch (error) {
            logger.error('Failed to parse UFW rules', { error: error.message });
            return [];
        }
    }
}

module.exports = UFWManager;