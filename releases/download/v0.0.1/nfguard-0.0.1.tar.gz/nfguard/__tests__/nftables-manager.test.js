const mockStore = new Map();

jest.mock('child_process', () => ({
    exec: jest.fn((command, callback) => {
        if (typeof callback === 'function') {
            callback(null, '', '');
        }
    })
}));

jest.mock('fs-extra', () => ({
    ensureDirSync: jest.fn(),
    ensureDir: jest.fn(async () => {}),
    pathExists: jest.fn(async (filePath) => mockStore.has(filePath)),
    readJson: jest.fn(async (filePath) => {
        if (mockStore.has(filePath)) {
            return JSON.parse(mockStore.get(filePath));
        }
        return [];
    }),
    writeJson: jest.fn(async (filePath, data) => {
        mockStore.set(filePath, JSON.stringify(data));
    }),
    writeFile: jest.fn(async () => {}),
    readFile: jest.fn(async () => ''),
    remove: jest.fn(async () => {}),
    __reset: () => mockStore.clear()
}));

const childProcess = require('child_process');
const fs = require('fs-extra');
const NFTablesManager = require('../src/core/nftables-manager');

describe('NFTablesManager addRule', () => {
    let manager;

    beforeEach(() => {
        fs.__reset();
        childProcess.exec.mockClear();
        manager = new NFTablesManager();
    });

    test('adds tcp drop rule with source restriction', async () => {
        const rule = {
            type: 'port',
            direction: 'input',
            protocol: 'tcp',
            port: '80',
            source: '192.168.1.0/24',
            action: 'drop'
        };

        await manager.addRule(rule, 'tester');

        expect(childProcess.exec).toHaveBeenCalledTimes(1);
        const command = childProcess.exec.mock.calls[0][0];
        expect(command).toBe('nft add rule inet nfguard input tcp dport 80 ip saddr 192.168.1.0/24 counter drop');

        const savedRules = await fs.readJson(manager.rulesPath);
        expect(savedRules[0]).toMatchObject({
            type: 'port',
            direction: 'input',
            protocol: 'tcp',
            port: '80',
            source: '192.168.1.0/24',
            action: 'drop'
        });
    });

    test('adds output allow rule with destination filter', async () => {
        const rule = {
            type: 'port',
            direction: 'output',
            protocol: 'udp',
            port: '53',
            destination: '8.8.8.8',
            action: 'accept'
        };

        await manager.addRule(rule, 'tester');

        const command = childProcess.exec.mock.calls[0][0];
        expect(command).toBe('nft add rule inet nfguard output udp dport 53 ip daddr 8.8.8.8 counter accept');
    });

    test('adds icmp drop rule', async () => {
        const rule = {
            type: 'icmp',
            direction: 'input',
            action: 'drop'
        };

        await manager.addRule(rule, 'tester');

        const command = childProcess.exec.mock.calls[0][0];
        expect(command).toBe('nft add rule inet nfguard input icmp type echo-request counter drop');
    });

    test('throws when port rule is missing port', async () => {
        const rule = {
            type: 'port',
            direction: 'input',
            protocol: 'tcp',
            action: 'accept'
        };

        await expect(manager.addRule(rule, 'tester')).rejects.toThrow('Port is required for port rules');
        expect(childProcess.exec).not.toHaveBeenCalled();
    });
});