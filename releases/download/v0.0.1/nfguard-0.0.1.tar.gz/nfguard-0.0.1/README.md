# NFGuard - Advanced Firewall Management Tool

NFGuard is a comprehensive firewall management solution that provides both CLI and WebGUI interfaces for managing NFTables rules on Linux systems.

- **Repository**: https://github.com/nfguard/nfguard
- **Version**: v0.0.1
- **Developer**: Lucas Cat�o de Moraes
- **Website**: https://nfguard.org
- **Company**: https://dolutech.com

## Features
- WebGUI served over HTTPS (port 8443)
- Full-featured CLI utility (`nfguard`)
- Geo-blocking powered by MaxMind GeoLite2
- Real-time monitoring and statistics
- Configuration export/import tooling
- Universal installer for major Linux distributions

## Quick Installation
```bash
# Extract the package
tar -xzf nfguard-0.0.1.tar.gz
cd nfguard-0.0.1

# Run installer as root
sudo bash install.sh
```

## Default Access
- **WebGUI**: https://your-server-ip:8443
- **Default login**: nfguard / nfguard
- **CLI help**: `nfguard --help`

## Common CLI Examples
```bash
nfguard allow -p 80                     # Allow HTTP
nfguard block -p 53 -P udp -D output    # Block outbound DNS
nfguard block -s 192.168.1.100          # Block source IP
nfguard geo-block CN                    # Block country
nfguard list                            # Show saved and active rules
```

## Service Management
```bash
systemctl start nfguard
systemctl stop nfguard
systemctl restart nfguard
systemctl status nfguard
```

## Security Notes
- HTTPS-only WebGUI with self-signed certificates
- JWT authentication with rotating tokens
- Passwords hashed via bcrypt
- Detailed audit logging for all administrative actions

## Support
For documentation, issues, and updates visit https://github.com/nfguard/nfguard
