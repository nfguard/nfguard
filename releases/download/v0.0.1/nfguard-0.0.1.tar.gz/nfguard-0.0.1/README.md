# NFGuard - Advanced Firewall Management Tool

NFGuard is a comprehensive firewall management solution that provides both CLI and WebGUI interfaces for managing NFTables rules on Linux systems.

**Repository**: https://github.com/nfguard/nfguard
**Version**: v0.0.1
**Developer**: Lucas Catão de Moraes
**Website**: https://nfguard.org
**Company**: https://dolutech.com

## Features

- **WebGUI Interface**: Modern web interface accessible via HTTPS (port 8443)
- **CLI Tool**: Full-featured command-line interface
- **Geo-blocking**: Block traffic by country using MaxMind GeoLite2 database
- **Real-time Monitoring**: Live logs and statistics
- **Multi-user Support**: Role-based access control
- **Export/Import**: Configuration backup and restore
- **Universal Installer**: Works on all major Linux distributions

## Quick Installation

```bash
# Extract the package
tar -xzf nfguard-0.0.1.tar.gz
cd nfguard-0.0.1

# Run installer as root
sudo bash install.sh
```

## Default Access

- **WebGUI**: https://your-server-ip:8443
- **Default Login**: nfguard / nfguard
- **CLI**: `nfguard --help`

## System Requirements

- Linux with NFTables support (Ubuntu 22.04+, Debian 12+, CentOS/RHEL 8+, Fedora 38+)
- Node.js 22.19.0 LTS (installed automatically)
- Root privileges for installation

## CLI Examples

```bash
# Allow port
nfguard allow -p 80

# Block IP
nfguard block -s 192.168.1.100

# Block country
nfguard geo-block CN

# List rules
nfguard list

# Export configuration
nfguard export /backup/rules.conf
```

## Service Management

```bash
systemctl start nfguard
systemctl stop nfguard
systemctl restart nfguard
systemctl status nfguard
```

## Security

- HTTPS-only WebGUI with self-signed certificates
- JWT authentication with secure sessions
- Bcrypt password hashing
- Audit logging for all operations
- File permissions secured to root-only

## License

MIT License - See LICENSE file for details.

## Support

For issues and documentation: https://github.com/nfguard/nfguard
