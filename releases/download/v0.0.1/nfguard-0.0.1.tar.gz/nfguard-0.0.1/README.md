# NFGuard - Advanced NFTables Firewall Management

NFGuard é uma ferramenta completa de gerenciamento de firewall para servidores Linux, utilizando NFTables com interface CLI e WebGUI.

## Características

- **Interface WebGUI** moderna e responsiva (porta 8443)
- **CLI** completa para gerenciamento via linha de comando
- **Bloqueio por Geolocalização** de países
- **Gerenciamento de Regras** de entrada/saída de portas e IPs
- **Sistema de Autenticação** seguro com JWT
- **API REST** para integração
- **Suporte Multiplataforma** para distribuições Linux
- **Serviço Daemon** com systemd

## Instalação Rápida

### Via Script de Instalação

```bash
sudo bash install.sh
```

### Via Docker

```bash
docker-compose up -d
```

## Uso da CLI

### Comandos Básicos

```bash
# Inicializar NFTables
nfguard init

# Liberar porta
nfguard allow -p 80 -P tcp

# Bloquear IP
nfguard block -s 192.168.1.100

# Bloquear país
nfguard geo-block CN

# Listar regras
nfguard list

# Ver ajuda
nfguard --help
```

### Exemplos Avançados

```bash
# Liberar porta apenas para IP específico
nfguard allow -p 3306 -s 192.168.1.0/24

# Bloquear saída para IP
nfguard block -d 8.8.8.8 -D output

# Desbloquear país
nfguard geo-unblock RU

# Verificar geolocalização de IP
nfguard check-ip 1.1.1.1

# Exportar configuração
nfguard export backup.conf

# Importar configuração
nfguard import backup.conf
```

## Acesso WebGUI

Após a instalação, acesse:

```
https://seu-servidor:8443
```

**Credenciais padrão:**
- Usuário: `nfguard`
- Senha: `nfguard`

⚠️ **IMPORTANTE:** Altere a senha padrão após o primeiro login!

## Gerenciamento do Serviço

### Systemd

```bash
# Iniciar serviço
sudo systemctl start nfguard

# Parar serviço
sudo systemctl stop nfguard

# Reiniciar serviço
sudo systemctl restart nfguard

# Ver status
sudo systemctl status nfguard

# Habilitar na inicialização
sudo systemctl enable nfguard

# Ver logs
sudo journalctl -u nfguard -f
```

## API REST

A API está disponível em `https://servidor:8443/api`

### Endpoints Principais

- `POST /api/auth/login` - Autenticação
- `GET /api/rules` - Listar regras
- `POST /api/rules` - Adicionar regra
- `DELETE /api/rules/:id` - Remover regra
- `POST /api/geo/block` - Bloquear país
- `GET /api/geo/blocked` - Listar países bloqueados
- `GET /api/stats` - Estatísticas do firewall

### Exemplo de Uso da API

```javascript
// Login
const response = await fetch('https://servidor:8443/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        username: 'nfguard',
        password: 'nfguard'
    })
});

const { token } = await response.json();

// Adicionar regra
await fetch('https://servidor:8443/api/rules', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
        type: 'port',
        direction: 'input',
        protocol: 'tcp',
        port: '443',
        action: 'accept'
    })
});
```

## Estrutura do Projeto

```
nfguard/
├── src/
│   ├── core/
│   │   ├── nftables-manager.js    # Gerenciador NFTables
│   │   └── geo-blocker.js         # Bloqueio por geolocalização
│   ├── auth/
│   │   └── auth-manager.js        # Sistema de autenticação
│   ├── cli/
│   │   └── index.js               # Interface CLI
│   └── index.js                   # Servidor principal
├── web/
│   ├── index.html                 # Interface WebGUI
│   ├── styles.css                 # Estilos CSS
│   └── app.js                     # Aplicação frontend
├── docker/
│   ├── Dockerfile                 # Container Docker
│   └── docker-compose.yml         # Composição Docker
├── scripts/
│   └── install.sh                 # Script de instalação
└── package.json                   # Dependências Node.js
```

## Requisitos

- Linux com kernel 3.13+
- NFTables
- Node.js 14+
- NPM
- OpenSSL

## Segurança

- Todas as comunicações WebGUI usam HTTPS
- Autenticação via JWT com expiração
- Senhas armazenadas com bcrypt
- Certificados SSL gerados automaticamente
- Logs de auditoria de todas as ações

## Desenvolvimento

### Instalação para Desenvolvimento

```bash
git clone https://github.com/seu-usuario/nfguard.git
cd nfguard
npm install
npm run dev
```

### Testes

```bash
npm test
```

## Troubleshooting

### NFTables não funciona no Docker

Certifique-se de executar com privilégios:

```bash
docker run --cap-add=NET_ADMIN --cap-add=NET_RAW ...
```

### Porta 8443 já em uso

Mude a porta via variável de ambiente:

```bash
PORT=9443 node src/index.js
```

### Erro de certificado SSL

Regenere os certificados:

```bash
sudo rm -rf /etc/nfguard/ssl/*
sudo bash install.sh
```

## Contribuindo

Contribuições são bem-vindas! Por favor, abra uma issue ou pull request.

## Licença

MIT

## Suporte

Para suporte, abra uma issue no GitHub ou envie email para suporte@nfguard.io

## Roadmap

- [ ] Dashboard com gráficos em tempo real
- [ ] Integração com fail2ban
- [ ] Detecção de intrusão (IDS)
- [ ] Backup automático de regras
- [ ] Notificações por email/webhook
- [ ] Suporte para IPv6
- [ ] Interface mobile
- [ ] Clustering multi-servidor