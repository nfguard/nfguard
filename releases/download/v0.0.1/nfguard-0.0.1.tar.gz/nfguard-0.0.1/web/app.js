let authToken = null;
let currentUser = null;
let refreshInterval = null;

const API_URL = window.location.protocol + '//' + window.location.host + '/api';

async function apiCall(endpoint, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        }
    };

    if (authToken) {
        defaultOptions.headers['Authorization'] = `Bearer ${authToken}`;
    }

    const response = await fetch(`${API_URL}${endpoint}`, {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...options.headers
        }
    });

    if (response.status === 401) {
        localStorage.removeItem('authToken');
        showLogin();
        return null;
    }

    return response;
}

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await apiCall('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            showApp();

            if (data.user.isDefault) {
                showToast('Please change your default password', 'warning');
            }
        } else {
            document.getElementById('login-error').textContent = data.message || 'Login failed';
        }
    } catch (error) {
        document.getElementById('login-error').textContent = 'Connection error';
    }
});

function showLogin() {
    document.getElementById('login-container').style.display = 'flex';
    document.getElementById('app').style.display = 'none';
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
}

function showApp() {
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    document.getElementById('current-user').textContent = currentUser.username;

    loadDashboard();
    setupAutoRefresh();
}

document.querySelectorAll('.sidebar-menu a[data-page]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();

        const page = e.currentTarget.dataset.page;

        document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
        e.currentTarget.classList.add('active');

        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById(`${page}-page`).classList.add('active');

        const titles = {
            'dashboard': 'Dashboard',
            'rules': 'Firewall Rules',
            'geo': 'Geo Blocking',
            'logs': 'System Logs',
            'settings': 'Settings'
        };

        document.getElementById('page-title').textContent = titles[page];

        switch(page) {
            case 'dashboard':
                loadDashboard();
                break;
            case 'rules':
                loadRules();
                break;
            case 'geo':
                loadGeoBlocking();
                break;
            case 'logs':
                loadLogs();
                break;
        }
    });
});

document.getElementById('logout').addEventListener('click', async (e) => {
    e.preventDefault();

    await apiCall('/auth/logout', { method: 'POST' });

    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    showLogin();
});

document.getElementById('refresh-btn').addEventListener('click', () => {
    const activePage = document.querySelector('.sidebar-menu a.active').dataset.page;

    switch(activePage) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'rules':
            loadRules();
            break;
        case 'geo':
            loadGeoBlocking();
            break;
        case 'logs':
            loadLogs();
            break;
    }

    showToast('Data refreshed', 'success');
});

document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    document.getElementById('theme-toggle').innerHTML = isDark ?
        '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    localStorage.setItem('darkTheme', isDark);
});

async function loadDashboard() {
    try {
        const [rulesRes, geoRes, statsRes] = await Promise.all([
            apiCall('/rules'),
            apiCall('/geo/blocked'),
            apiCall('/stats')
        ]);

        const rulesData = await rulesRes.json();
        const geoData = await geoRes.json();
        const statsData = await statsRes.json();

        document.getElementById('active-rules').textContent = rulesData.rules.saved.length;
        document.getElementById('blocked-countries').textContent = geoData.countries.length;
        document.getElementById('total-packets').textContent = statsData.stats.packets || 0;

        const activityList = document.getElementById('activity-list');
        if (rulesData.rules.saved.length > 0) {
            const recentRules = rulesData.rules.saved.slice(-5).reverse();
            activityList.innerHTML = recentRules.map(rule => `
                <div class="activity-item">
                    Rule ${rule.id.substring(0, 8)}: ${rule.type} ${rule.action} on ${rule.direction}
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Failed to load dashboard:', error);
    }
}

async function loadRules() {
    try {
        const response = await apiCall('/rules');
        const data = await response.json();

        const tbody = document.getElementById('rules-tbody');

        if (data.rules.saved.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No rules configured</td></tr>';
        } else {
            tbody.innerHTML = data.rules.saved.map(rule => {
                // Format rule description based on type
                let description = '';
                let fromTo = '';

                if (rule.type === 'port') {
                    if (rule.protocol === 'icmp') {
                        description = `ICMP`;
                    } else {
                        description = `${rule.protocol.toUpperCase()} Port ${rule.port}`;
                    }
                } else if (rule.type === 'ip' || rule.type === 'network') {
                    description = `IP/Network`;
                }

                // Format source/destination for clarity
                if (rule.direction === 'input') {
                    if (rule.source) {
                        fromTo = `From ${rule.source}`;
                    } else {
                        fromTo = 'From Any';
                    }
                } else {
                    if (rule.destination) {
                        fromTo = `To ${rule.destination}`;
                    } else {
                        fromTo = 'To Any';
                    }
                }

                return `
                <tr>
                    <td>${rule.id.substring(0, 8)}</td>
                    <td>${description}</td>
                    <td>${rule.direction.charAt(0).toUpperCase() + rule.direction.slice(1)}</td>
                    <td>${fromTo}</td>
                    <td><span class="badge ${rule.action === 'accept' || rule.action === 'ACCEPT' ? 'success' : (rule.action === 'drop' || rule.action === 'DROP' ? 'danger' : 'warning')}">${rule.action === 'accept' ? 'ALLOW' : (rule.action === 'ACCEPT' ? 'ALLOW' : rule.action.toUpperCase())}</span></td>
                    <td>${new Date(rule.createdAt).toLocaleDateString()}</td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="deleteRule('${rule.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
                `;
            }).join('');
        }
    } catch (error) {
        console.error('Failed to load rules:', error);
    }
}

async function loadGeoBlocking() {
    try {
        const response = await apiCall('/geo/blocked');
        const data = await response.json();

        const list = document.getElementById('blocked-countries-list');

        if (data.countries.length === 0) {
            list.innerHTML = '<p class="no-data">No countries blocked</p>';
        } else {
            list.innerHTML = data.countries.map(country => `
                <div class="country-item">
                    <div>
                        <strong>${country.name}</strong> (${country.code})
                        <br>
                        <small>${country.ipRanges.length} IP ranges blocked</small>
                    </div>
                    <button class="btn btn-sm btn-danger" onclick="unblockCountry('${country.code}')">
                        Unblock
                    </button>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Failed to load geo blocking:', error);
    }
}

async function loadLogs() {
    try {
        const response = await apiCall('/logs?lines=50');
        const data = await response.json();

        const logViewer = document.getElementById('log-viewer');

        if (data.success && data.logs.length > 0) {
            logViewer.innerHTML = data.logs.map(log => {
                try {
                    const logObj = typeof log === 'string' ? JSON.parse(log) : log;
                    const level = logObj.level || 'info';
                    const timestamp = logObj.timestamp ? new Date(logObj.timestamp).toLocaleString() : '';
                    const message = logObj.message || log;

                    return `<div class="log-entry ${level}">[${timestamp}] [${level.toUpperCase()}] ${message}</div>`;
                } catch {
                    return `<div class="log-entry info">${log}</div>`;
                }
            }).reverse().join('');
        } else {
            logViewer.innerHTML = '<p class="no-data">No logs available</p>';
        }
    } catch (error) {
        console.error('Failed to load logs:', error);
        const logViewer = document.getElementById('log-viewer');
        logViewer.innerHTML = '<p class="no-data">Failed to load logs</p>';
    }
}

function showAddRuleModal() {
    document.getElementById('rule-modal').classList.add('show');
}

function showBlockCountryModal() {
    document.getElementById('country-modal').classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

document.getElementById('rule-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const ruleType = document.getElementById('rule-type').value;
    const protocol = document.getElementById('rule-protocol').value;
    const port = document.getElementById('rule-port').value;

    const rule = {
        type: ruleType,
        direction: 'input', // Always input for server firewall
        protocol: protocol,
        port: protocol === 'icmp' ? undefined : port,
        source: document.getElementById('rule-source').value.trim() || undefined,
        destination: undefined, // Not used for server firewall
        action: document.getElementById('rule-action').value
    };

    // Handle different rule types
    if (ruleType === 'ip' || ruleType === 'network') {
        const target = document.getElementById('rule-target');
        if (target && target.value.trim()) {
            rule.source = target.value.trim();
        }
        rule.protocol = undefined;
        rule.port = undefined;
    }

    // Validation: ICMP doesn't need port
    if (protocol === 'icmp' && ruleType === 'port') {
        rule.type = 'icmp';
    }

    try {
        const response = await apiCall('/rules', {
            method: 'POST',
            body: JSON.stringify(rule)
        });

        const data = await response.json();

        if (data.success) {
            showToast('Rule added successfully', 'success');
            closeModal('rule-modal');
            loadRules();
            document.getElementById('rule-form').reset();
        } else {
            showToast(data.error || 'Failed to add rule', 'error');
        }
    } catch (error) {
        showToast('Failed to add rule', 'error');
    }
});

document.getElementById('country-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    let countryCode = document.getElementById('country-code').value;
    const manualCode = document.getElementById('manual-country-code').value.trim().toUpperCase();

    // Use manual input if provided, otherwise use dropdown
    if (manualCode) {
        countryCode = manualCode;
    }

    if (!countryCode) {
        showToast('Please select a country or enter a country code', 'error');
        return;
    }

    // Validate country code format
    if (!/^[A-Z]{2}$/.test(countryCode)) {
        showToast('Country code must be 2 letters (e.g., CN, RU, US)', 'error');
        return;
    }

    try {
        const response = await apiCall('/geo/block', {
            method: 'POST',
            body: JSON.stringify({ countryCode })
        });

        const data = await response.json();

        if (data.success) {
            showToast(`Country ${countryCode} blocked successfully`, 'success');
            closeModal('country-modal');
            document.getElementById('country-code').value = '';
            document.getElementById('manual-country-code').value = '';
            loadGeoBlocks();
        } else {
            showToast(data.error || 'Failed to block country', 'error');
        }
    } catch (error) {
        showToast('Failed to block country', 'error');
    }
});

async function deleteRule(ruleId) {
    if (!confirm('Are you sure you want to delete this rule?')) {
        return;
    }

    try {
        const response = await apiCall(`/rules/${ruleId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast('Rule deleted successfully', 'success');
            loadRules();
        } else {
            showToast(data.error || 'Failed to delete rule', 'error');
        }
    } catch (error) {
        showToast('Failed to delete rule', 'error');
    }
}

async function unblockCountry(countryCode) {
    if (!confirm(`Are you sure you want to unblock ${countryCode}?`)) {
        return;
    }

    try {
        const response = await apiCall(`/geo/block/${countryCode}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast(`Unblocked traffic from ${countryCode}`, 'success');
            loadGeoBlocking();
        } else {
            showToast(data.error || 'Failed to unblock country', 'error');
        }
    } catch (error) {
        showToast('Failed to unblock country', 'error');
    }
}

async function lookupIP() {
    const ip = document.getElementById('ip-lookup-input').value;

    if (!ip) {
        showToast('Please enter an IP address', 'error');
        return;
    }

    try {
        const response = await apiCall(`/geo/check/${ip}`);
        const data = await response.json();

        if (data.success) {
            const result = document.getElementById('ip-lookup-result');
            result.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <p><strong>IP:</strong> ${data.info.ip}</p>
                        <p><strong>Country:</strong> ${data.info.country} ${data.info.blocked ? '<span style="color: red;">(BLOCKED)</span>' : '<span style="color: green;">(ALLOWED)</span>'}</p>
                        <p><strong>City:</strong> ${data.info.city || 'Unknown'}</p>
                        <p><strong>Region:</strong> ${data.info.region || 'Unknown'}</p>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        showToast('Failed to lookup IP', 'error');
    }
}

async function exportRules() {
    try {
        const response = await apiCall('/rules/export');
        const blob = await response.blob();

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'nfguard-rules.conf';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        showToast('Rules exported successfully', 'success');
    } catch (error) {
        showToast('Failed to export rules', 'error');
    }
}

async function confirmFlushRules() {
    if (!confirm('WARNING: This will remove all firewall rules. Are you sure?')) {
        return;
    }

    if (!confirm('This action cannot be undone. Please confirm again.')) {
        return;
    }

    try {
        const response = await apiCall('/rules/flush', {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('All rules flushed successfully', 'success');
            loadRules();
        } else {
            showToast(data.error || 'Failed to flush rules', 'error');
        }
    } catch (error) {
        showToast('Failed to flush rules', 'error');
    }
}

document.getElementById('account-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const newUsername = document.getElementById('new-username').value;
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (newPassword && newPassword !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        return;
    }

    try {
        if (newUsername) {
            const response = await apiCall('/auth/change-username', {
                method: 'POST',
                body: JSON.stringify({ newUsername, password: currentPassword })
            });

            const data = await response.json();

            if (!data.success) {
                showToast(data.message || 'Failed to change username', 'error');
                return;
            }
        }

        if (newPassword) {
            const response = await apiCall('/auth/change-password', {
                method: 'POST',
                body: JSON.stringify({ currentPassword, newPassword })
            });

            const data = await response.json();

            if (!data.success) {
                showToast(data.message || 'Failed to change password', 'error');
                return;
            }
        }

        showToast('Account updated successfully', 'success');
        document.getElementById('account-form').reset();
    } catch (error) {
        showToast('Failed to update account', 'error');
    }
});

function clearLogs() {
    document.getElementById('log-viewer').innerHTML = '<p class="no-data">Logs cleared</p>';
    showToast('Logs cleared', 'success');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function setupAutoRefresh() {
    const autoRefresh = document.getElementById('auto-refresh');

    if (autoRefresh && autoRefresh.checked) {
        refreshInterval = setInterval(() => {
            const activePage = document.querySelector('.sidebar-menu a.active').dataset.page;
            if (activePage === 'dashboard') {
                loadDashboard();
            }
        }, 30000);
    }
}

document.getElementById('auto-refresh')?.addEventListener('change', (e) => {
    if (e.target.checked) {
        setupAutoRefresh();
    } else {
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    }
});

document.getElementById('dark-theme')?.addEventListener('change', (e) => {
    if (e.target.checked) {
        document.body.classList.add('dark-theme');
        document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        document.body.classList.remove('dark-theme');
        document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-moon"></i>';
    }
    localStorage.setItem('darkTheme', e.target.checked);
});

window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

// Firewall control functions
async function enableFirewall() {
    try {
        const response = await apiCall('/firewall/enable', { method: 'POST' });
        if (response.success) {
            showToast('Firewall enabled successfully', 'success');
            await loadDashboard();
        } else {
            showToast('Failed to enable firewall: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error enabling firewall: ' + error.message, 'error');
    }
}

async function disableFirewall() {
    if (!confirm('Are you sure you want to disable the firewall? This will remove all protection.')) {
        return;
    }

    try {
        const response = await apiCall('/firewall/disable', { method: 'POST' });
        if (response.success) {
            showToast('Firewall disabled successfully', 'success');
            await loadDashboard();
        } else {
            showToast('Failed to disable firewall: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error disabling firewall: ' + error.message, 'error');
    }
}

async function restartFirewall() {
    try {
        showToast('Restarting firewall...', 'info');
        const response = await apiCall('/firewall/restart', { method: 'POST' });
        if (response.success) {
            showToast('Firewall restarted successfully', 'success');
            await loadDashboard();
            await loadRules();
        } else {
            showToast('Failed to restart firewall: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error restarting firewall: ' + error.message, 'error');
    }
}

async function loadDefaultRules() {
    if (!confirm('This will remove all current rules and load only default rules (SSH and WebGUI). Continue?')) {
        return;
    }

    try {
        const response = await apiCall('/rules/default', { method: 'POST' });
        if (response.success) {
            showToast('Default rules loaded successfully', 'success');
            await loadDashboard();
            await loadRules();
        } else {
            showToast('Failed to load default rules: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error loading default rules: ' + error.message, 'error');
    }
}

function confirmFlushRules() {
    if (confirm('Are you sure you want to flush ALL firewall rules? This will remove all protection except basic rules.')) {
        flushRules();
    }
}

async function flushRules() {
    try {
        const response = await apiCall('/rules/flush', { method: 'POST' });
        if (response.success) {
            showToast('All rules flushed successfully', 'success');
            await loadDashboard();
            await loadRules();
        } else {
            showToast('Failed to flush rules: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error flushing rules: ' + error.message, 'error');
    }
}

function showWebGUIRestrictionModal() {
    document.getElementById('webgui-restriction-modal').classList.add('show');
}

function toggleIPField() {
    const accessType = document.getElementById('access-type').value;
    const ipField = document.getElementById('ip-restriction-field');

    if (accessType === 'specific') {
        ipField.style.display = 'block';
    } else {
        ipField.style.display = 'none';
    }
}

// WebGUI restriction form handler
document.getElementById('webgui-restriction-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const accessType = document.getElementById('access-type').value;
    const allowedIP = accessType === 'specific' ? document.getElementById('allowed-ip').value : 'any';

    if (accessType === 'specific' && !allowedIP.trim()) {
        showToast('Please enter an IP address or domain', 'error');
        return;
    }

    try {
        const response = await apiCall('/webgui/restrict', {
            method: 'POST',
            body: JSON.stringify({ allowedIP: allowedIP })
        });

        if (response.success) {
            showToast('WebGUI access restriction updated successfully', 'success');
            closeModal('webgui-restriction-modal');
        } else {
            showToast('Failed to update restriction: ' + response.error, 'error');
        }
    } catch (error) {
        showToast('Error updating WebGUI restriction: ' + error.message, 'error');
    }
});

const savedToken = localStorage.getItem('authToken');
if (savedToken) {
    authToken = savedToken;
    apiCall('/auth/profile').then(async response => {
        if (response) {
            const data = await response.json();
            if (data.success) {
                currentUser = data.user;
                showApp();
            } else {
                showLogin();
            }
        }
    });
} else {
    showLogin();
}

const savedTheme = localStorage.getItem('darkTheme');
if (savedTheme === 'true') {
    document.body.classList.add('dark-theme');
    document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-sun"></i>';
}

// Toggle port field based on protocol selection
function togglePortField() {
    const protocol = document.getElementById('rule-protocol').value;
    const portField = document.getElementById('port-field') || document.getElementById('rule-port').parentElement;

    if (protocol === 'icmp') {
        portField.style.display = 'none';
        document.getElementById('rule-port').value = '';
    } else {
        portField.style.display = 'block';
    }
}

// Update rule form based on rule type
function updateRuleForm() {
    const ruleType = document.getElementById('rule-type').value;
    const portFields = document.getElementById('port-fields');
    const ipFields = document.getElementById('ip-fields');

    if (ruleType === 'port') {
        if (portFields) portFields.style.display = 'block';
        if (ipFields) ipFields.style.display = 'none';
    } else {
        if (portFields) portFields.style.display = 'none';
        if (ipFields) ipFields.style.display = 'block';
    }
}