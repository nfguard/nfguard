let authToken = null;
let currentUser = null;
let refreshInterval = null;

const API_URL = window.location.protocol + '//' + window.location.host + '/api';

async function apiCall(endpoint, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        }
    };

    if (authToken) {
        defaultOptions.headers['Authorization'] = `Bearer ${authToken}`;
    }

    const response = await fetch(`${API_URL}${endpoint}`, {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...options.headers
        }
    });

    if (response.status === 401) {
        localStorage.removeItem('authToken');
        showLogin();
        return null;
    }

    return response;
}

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await apiCall('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            showApp();

            if (data.user.isDefault) {
                showToast('Please change your default password', 'warning');
            }
        } else {
            document.getElementById('login-error').textContent = data.message || 'Login failed';
        }
    } catch (error) {
        document.getElementById('login-error').textContent = 'Connection error';
    }
});

function showLogin() {
    document.getElementById('login-container').style.display = 'flex';
    document.getElementById('app').style.display = 'none';
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
}

function showApp() {
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    document.getElementById('current-user').textContent = currentUser.username;

    loadDashboard();
    setupAutoRefresh();
}

document.querySelectorAll('.sidebar-menu a[data-page]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();

        const page = e.currentTarget.dataset.page;

        document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
        e.currentTarget.classList.add('active');

        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById(`${page}-page`).classList.add('active');

        const titles = {
            'dashboard': 'Dashboard',
            'rules': 'Firewall Rules',
            'geo': 'Geo Blocking',
            'logs': 'System Logs',
            'settings': 'Settings'
        };

        document.getElementById('page-title').textContent = titles[page];

        switch(page) {
            case 'dashboard':
                loadDashboard();
                break;
            case 'rules':
                loadRules();
                break;
            case 'geo':
                loadGeoBlocking();
                break;
            case 'logs':
                loadLogs();
                break;
        }
    });
});

document.getElementById('logout').addEventListener('click', async (e) => {
    e.preventDefault();

    await apiCall('/auth/logout', { method: 'POST' });

    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    showLogin();
});

document.getElementById('refresh-btn').addEventListener('click', () => {
    const activePage = document.querySelector('.sidebar-menu a.active').dataset.page;

    switch(activePage) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'rules':
            loadRules();
            break;
        case 'geo':
            loadGeoBlocking();
            break;
        case 'logs':
            loadLogs();
            break;
    }

    showToast('Data refreshed', 'success');
});

document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    document.getElementById('theme-toggle').innerHTML = isDark ?
        '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    localStorage.setItem('darkTheme', isDark);
});

async function loadDashboard() {
    try {
        const [rulesRes, geoRes, statsRes] = await Promise.all([
            apiCall('/rules'),
            apiCall('/geo/blocked'),
            apiCall('/stats')
        ]);

        const rulesData = await rulesRes.json();
        const geoData = await geoRes.json();
        const statsData = await statsRes.json();

        // Display both saved and active rules count
        const activeCount = rulesData.rules.active ? rulesData.rules.active.length : 0;
        const savedCount = rulesData.rules.saved.length;

        document.getElementById('active-rules').textContent = `${savedCount} saved / ${activeCount} active`;
        document.getElementById('blocked-countries').textContent = geoData.countries.length;

        // Display UFW status
        const statusElement = document.getElementById('total-packets');
        if (statsData.stats.status === 'active') {
            statusElement.innerHTML = '<span style="color: #28a745;">UFW Active ✓</span>';
        } else {
            statusElement.innerHTML = '<span style="color: #dc3545;">UFW Inactive ✗</span>';
        }

        const activityList = document.getElementById('activity-list');
        if (rulesData.rules.saved.length > 0) {
            const recentRules = rulesData.rules.saved.slice(-5).reverse();
            activityList.innerHTML = recentRules.map(rule => `
                <div class="activity-item">
                    <span class="activity-icon ${rule.action === 'allow' ? 'allow' : 'deny'}">
                        <i class="fas ${rule.action === 'allow' ? 'fa-check' : 'fa-ban'}"></i>
                    </span>
                    <div class="activity-content">
                        <strong>${rule.type.toUpperCase()}</strong>
                        ${rule.protocol ? rule.protocol.toUpperCase() : ''}
                        ${rule.port || ''} -
                        <span class="${rule.action === 'allow' ? 'text-success' : 'text-danger'}">
                            ${rule.action.toUpperCase()}
                        </span>
                        <small class="text-muted d-block">
                            ${new Date(rule.createdAt).toLocaleString()}
                        </small>
                    </div>
                </div>
            `).join('');
        } else {
            activityList.innerHTML = '<div class="text-muted text-center">No recent activity</div>';
        }
    } catch (error) {
        console.error('Failed to load dashboard:', error);
    }
}

async function loadRules() {
    try {
        const response = await apiCall('/rules');
        const data = await response.json();

        // Create enhanced rule management interface
        const rulesContainer = document.querySelector('#rules-page .card-body');

        rulesContainer.innerHTML = `
            <div class="rules-header mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="rules-tabs">
                        <button class="btn btn-outline-primary btn-sm tab-btn active" onclick="switchRuleView('saved')">
                            <i class="fas fa-save"></i> Saved Rules (${data.rules.saved.length})
                        </button>
                        <button class="btn btn-outline-success btn-sm tab-btn" onclick="switchRuleView('active')">
                            <i class="fas fa-fire"></i> Active UFW (${data.rules.active ? data.rules.active.length : 0})
                        </button>
                        <button class="btn btn-outline-info btn-sm tab-btn" onclick="switchRuleView('formatted')">
                            <i class="fas fa-list"></i> Formatted View
                        </button>
                    </div>
                    <div class="rules-actions">
                        <button class="btn btn-primary btn-sm" onclick="showAddRuleModal()">
                            <i class="fas fa-plus"></i> Add Rule
                        </button>
                        <button class="btn btn-warning btn-sm" onclick="exportRules()">
                            <i class="fas fa-download"></i> Export
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="confirmFlushRules()">
                            <i class="fas fa-trash"></i> Flush All
                        </button>
                    </div>
                </div>
            </div>

            <!-- Saved Rules View -->
            <div id="saved-rules" class="rule-view">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0"><i class="fas fa-save"></i> Saved Configuration Rules</h6>
                    </div>
                    <div class="card-body p-0">
                        ${data.rules.saved.length === 0 ?
                            '<div class="text-center p-4 text-muted">No saved rules configured</div>' :
                            generateSavedRulesTable(data.rules.saved)
                        }
                    </div>
                </div>
            </div>

            <!-- Active UFW Rules View -->
            <div id="active-rules" class="rule-view" style="display:none;">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h6 class="mb-0"><i class="fas fa-fire"></i> Active UFW Rules</h6>
                    </div>
                    <div class="card-body">
                        ${data.rules.active && data.rules.active.length > 0 ?
                            `<pre class="ufw-output">${data.rules.active.join('\\n')}</pre>` :
                            '<div class="text-center p-4 text-muted">No active UFW rules</div>'
                        }
                    </div>
                </div>
            </div>

            <!-- Formatted Rules View -->
            <div id="formatted-rules" class="rule-view" style="display:none;">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0"><i class="fas fa-list"></i> Formatted Rules Display</h6>
                    </div>
                    <div class="card-body p-0">
                        ${data.rules.formatted && data.rules.formatted.length > 0 ?
                            generateFormattedRulesTable(data.rules.formatted) :
                            '<div class="text-center p-4 text-muted">No formatted rules available</div>'
                        }
                    </div>
                </div>
            </div>
        `;

    } catch (error) {
        console.error('Failed to load rules:', error);
    }
}

function generateSavedRulesTable(rules) {
    return `
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="10%">ID</th>
                        <th width="15%">Type</th>
                        <th width="15%">Protocol</th>
                        <th width="15%">Port/Target</th>
                        <th width="20%">Source</th>
                        <th width="15%">Action</th>
                        <th width="10%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${rules.map(rule => `
                        <tr>
                            <td><code>${rule.id.substring(0, 8)}</code></td>
                            <td>
                                <span class="badge bg-secondary">${rule.type.toUpperCase()}</span>
                            </td>
                            <td>${rule.protocol ?
                                `<span class="badge bg-info">${rule.protocol.toUpperCase()}</span>` :
                                '<span class="text-muted">-</span>'
                            }</td>
                            <td>${rule.port ?
                                `<strong>${rule.port}</strong>` :
                                '<span class="text-muted">-</span>'
                            }</td>
                            <td>${rule.source ?
                                `<code>${rule.source}</code>` :
                                '<span class="text-muted">Any</span>'
                            }</td>
                            <td>
                                <span class="badge ${rule.action === 'allow' || rule.action === 'ACCEPT' ? 'bg-success' : 'bg-danger'}">
                                    <i class="fas ${rule.action === 'allow' || rule.action === 'ACCEPT' ? 'fa-check' : 'fa-ban'}"></i>
                                    ${(rule.action === 'allow' || rule.action === 'ACCEPT') ? 'ALLOW' : rule.action.toUpperCase()}
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteRule('${rule.id}')" title="Delete Rule">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function generateFormattedRulesTable(rules) {
    return `
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="8%">#</th>
                        <th width="15%">Action</th>
                        <th width="25%">From</th>
                        <th width="25%">To</th>
                        <th width="15%">Protocol</th>
                        <th width="12%">Port</th>
                    </tr>
                </thead>
                <tbody>
                    ${rules.map(rule => {
                        // Parse details for better display
                        let from = 'Anywhere';
                        let to = 'Anywhere';
                        let portInfo = '-';

                        const details = rule.details || '';
                        if (details) {
                            const portMatch = details.match(/(\\d+)(\\/\\w+)?/);
                            if (portMatch) {
                                portInfo = portMatch[0];
                            }

                            if (details.includes('from')) {
                                const fromMatch = details.match(/from\\s+(\\S+)/);
                                if (fromMatch) from = fromMatch[1];
                            }
                            if (details.includes('to')) {
                                const toMatch = details.match(/to\\s+(\\S+)/);
                                if (toMatch) to = toMatch[1];
                            }
                        }

                        return `
                            <tr>
                                <td><strong>${rule.number}</strong></td>
                                <td>
                                    <span class="badge ${rule.action === 'ALLOW' ? 'bg-success' : rule.action === 'DENY' ? 'bg-danger' : 'bg-warning'}">
                                        <i class="fas ${rule.action === 'ALLOW' ? 'fa-check' : 'fa-ban'}"></i>
                                        ${rule.action}
                                    </span>
                                </td>
                                <td><code>${from}</code></td>
                                <td><code>${to}</code></td>
                                <td>
                                    <span class="badge bg-info">${rule.protocol || 'any'}</span>
                                </td>
                                <td>${portInfo !== '-' ? `<strong>${portInfo}</strong>` : '<span class="text-muted">-</span>'}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function switchRuleView(view) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.add('btn-outline-primary', 'btn-outline-success', 'btn-outline-info');
        btn.classList.remove('btn-primary', 'btn-success', 'btn-info');
    });

    event.target.classList.add('active');
    if (view === 'saved') {
        event.target.classList.remove('btn-outline-primary');
        event.target.classList.add('btn-primary');
    } else if (view === 'active') {
        event.target.classList.remove('btn-outline-success');
        event.target.classList.add('btn-success');
    } else if (view === 'formatted') {
        event.target.classList.remove('btn-outline-info');
        event.target.classList.add('btn-info');
    }

    // Update view
    document.querySelectorAll('.rule-view').forEach(v => {
        v.style.display = 'none';
    });

    const targetView = view === 'formatted' ? 'formatted-rules' : `${view}-rules`;
    document.getElementById(targetView).style.display = 'block';
}

async function loadGeoBlocking() {
    try {
        const response = await apiCall('/geo/blocked');
        const data = await response.json();

        const list = document.getElementById('blocked-countries-list');

        if (data.countries.length === 0) {
            list.innerHTML = '<div class="text-center p-4 text-muted">No countries blocked</div>';
        } else {
            list.innerHTML = `
                <div class="row">
                    ${data.countries.map(country => `
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="card border-danger">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="card-title mb-1">
                                                <i class="fas fa-flag"></i> ${country.name}
                                            </h6>
                                            <p class="card-text">
                                                <small class="text-muted">Code: ${country.code}</small><br>
                                                <small class="text-info">${country.ipRanges.length} IP ranges</small><br>
                                                <small class="text-muted">Blocked: ${new Date(country.blockedAt).toLocaleDateString()}</small>
                                            </p>
                                        </div>
                                        <button class="btn btn-sm btn-outline-success" onclick="unblockCountry('${country.code}')" title="Unblock Country">
                                            <i class="fas fa-unlock"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
    } catch (error) {
        console.error('Failed to load geo blocking:', error);
    }
}

async function loadLogs() {
    try {
        const response = await apiCall('/logs?lines=50');
        const data = await response.json();

        const logViewer = document.getElementById('log-viewer');

        if (data.success && data.logs.length > 0) {
            logViewer.innerHTML = data.logs.map(log => {
                try {
                    const logObj = typeof log === 'string' ? JSON.parse(log) : log;
                    const level = logObj.level || 'info';
                    const timestamp = logObj.timestamp ? new Date(logObj.timestamp).toLocaleString() : '';
                    const message = logObj.message || log;

                    const levelIcon = {
                        'info': 'fa-info-circle text-info',
                        'warning': 'fa-exclamation-triangle text-warning',
                        'error': 'fa-times-circle text-danger',
                        'audit': 'fa-shield-alt text-success'
                    };

                    return `
                        <div class="log-entry border-bottom py-2">
                            <div class="d-flex align-items-start">
                                <i class="fas ${levelIcon[level] || 'fa-info-circle text-info'} me-2 mt-1"></i>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between">
                                        <span class="log-message">${message}</span>
                                        <small class="text-muted">${timestamp}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                } catch {
                    return `
                        <div class="log-entry border-bottom py-2">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-info-circle text-info me-2 mt-1"></i>
                                <span class="log-message">${log}</span>
                            </div>
                        </div>
                    `;
                }
            }).reverse().join('');
        } else {
            logViewer.innerHTML = '<div class="text-center p-4 text-muted">No logs available</div>';
        }
    } catch (error) {
        console.error('Failed to load logs:', error);
        const logViewer = document.getElementById('log-viewer');
        logViewer.innerHTML = '<div class="text-center p-4 text-danger">Failed to load logs</div>';
    }
}

function showAddRuleModal() {
    document.getElementById('rule-modal').classList.add('show');
}

function showBlockCountryModal() {
    document.getElementById('country-modal').classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

document.getElementById('rule-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const ruleType = document.getElementById('rule-type').value;
    const protocol = document.getElementById('rule-protocol').value;
    const port = document.getElementById('rule-port').value;

    const rule = {
        type: ruleType,
        direction: 'in',
        protocol: protocol,
        port: protocol === 'icmp' ? undefined : port,
        source: document.getElementById('rule-source').value.trim() || undefined,
        destination: undefined,
        action: document.getElementById('rule-action').value,
        comment: document.getElementById('rule-comment').value.trim() || undefined
    };

    if (ruleType === 'ip' || ruleType === 'network') {
        const target = document.getElementById('rule-target');
        if (target && target.value.trim()) {
            rule.source = target.value.trim();
        }
        rule.protocol = undefined;
        rule.port = undefined;
    }

    if (protocol === 'icmp' && ruleType === 'port') {
        rule.type = 'icmp';
    }

    try {
        const response = await apiCall('/rules', {
            method: 'POST',
            body: JSON.stringify(rule)
        });

        const data = await response.json();

        if (data.success) {
            showToast('Rule added successfully', 'success');
            closeModal('rule-modal');
            loadRules();
            document.getElementById('rule-form').reset();
        } else {
            showToast(data.error || 'Failed to add rule', 'error');
        }
    } catch (error) {
        showToast('Failed to add rule', 'error');
    }
});

document.getElementById('country-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    let countryCode = document.getElementById('country-code').value;
    const manualCode = document.getElementById('manual-country-code').value.trim().toUpperCase();

    if (manualCode) {
        countryCode = manualCode;
    }

    if (!countryCode) {
        showToast('Please select a country or enter a country code', 'error');
        return;
    }

    if (!/^[A-Z]{2}$/.test(countryCode)) {
        showToast('Country code must be 2 letters (e.g., CN, RU, US)', 'error');
        return;
    }

    try {
        const response = await apiCall('/geo/block', {
            method: 'POST',
            body: JSON.stringify({ countryCode })
        });

        const data = await response.json();

        if (data.success) {
            showToast(`Country ${countryCode} blocked successfully`, 'success');
            closeModal('country-modal');
            document.getElementById('country-code').value = '';
            document.getElementById('manual-country-code').value = '';
            loadGeoBlocking();
        } else {
            showToast(data.error || 'Failed to block country', 'error');
        }
    } catch (error) {
        showToast('Failed to block country', 'error');
    }
});

async function deleteRule(ruleId) {
    if (!confirm('Are you sure you want to delete this rule?')) {
        return;
    }

    try {
        const response = await apiCall(`/rules/${ruleId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast('Rule deleted successfully', 'success');
            loadRules();
        } else {
            showToast(data.error || 'Failed to delete rule', 'error');
        }
    } catch (error) {
        showToast('Failed to delete rule', 'error');
    }
}

async function unblockCountry(countryCode) {
    if (!confirm(`Are you sure you want to unblock ${countryCode}?`)) {
        return;
    }

    try {
        const response = await apiCall(`/geo/block/${countryCode}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast(`Unblocked traffic from ${countryCode}`, 'success');
            loadGeoBlocking();
        } else {
            showToast(data.error || 'Failed to unblock country', 'error');
        }
    } catch (error) {
        showToast('Failed to unblock country', 'error');
    }
}

async function lookupIP() {
    const ip = document.getElementById('ip-lookup-input').value;

    if (!ip) {
        showToast('Please enter an IP address', 'error');
        return;
    }

    try {
        const response = await apiCall(`/geo/check/${ip}`);
        const data = await response.json();

        if (data.success) {
            const result = document.getElementById('ip-lookup-result');
            result.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">IP Information</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>IP:</strong> <code>${data.info.ip}</code></p>
                                <p><strong>Country:</strong> ${data.info.country}
                                    ${data.info.blocked ?
                                        '<span class="badge bg-danger ms-2">BLOCKED</span>' :
                                        '<span class="badge bg-success ms-2">ALLOWED</span>'
                                    }
                                </p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>City:</strong> ${data.info.city || 'Unknown'}</p>
                                <p><strong>Region:</strong> ${data.info.region || 'Unknown'}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        showToast('Failed to lookup IP', 'error');
    }
}

async function exportRules() {
    try {
        const response = await apiCall('/rules/export');
        const blob = await response.blob();

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'nfguard-rules.json';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        showToast('Rules exported successfully', 'success');
    } catch (error) {
        showToast('Failed to export rules', 'error');
    }
}

async function confirmFlushRules() {
    if (!confirm('WARNING: This will remove all firewall rules. Are you sure?')) {
        return;
    }

    if (!confirm('This action cannot be undone. Please confirm again.')) {
        return;
    }

    try {
        const response = await apiCall('/rules/flush', {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('All rules flushed successfully', 'success');
            loadRules();
        } else {
            showToast(data.error || 'Failed to flush rules', 'error');
        }
    } catch (error) {
        showToast('Failed to flush rules', 'error');
    }
}

document.getElementById('account-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const newUsername = document.getElementById('new-username').value;
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (newPassword && newPassword !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        return;
    }

    try {
        if (newUsername) {
            const response = await apiCall('/auth/change-username', {
                method: 'POST',
                body: JSON.stringify({ newUsername, password: currentPassword })
            });

            const data = await response.json();

            if (!data.success) {
                showToast(data.message || 'Failed to change username', 'error');
                return;
            }
        }

        if (newPassword) {
            const response = await apiCall('/auth/change-password', {
                method: 'POST',
                body: JSON.stringify({ currentPassword, newPassword })
            });

            const data = await response.json();

            if (!data.success) {
                showToast(data.message || 'Failed to change password', 'error');
                return;
            }
        }

        showToast('Account updated successfully', 'success');
        document.getElementById('account-form').reset();
    } catch (error) {
        showToast('Failed to update account', 'error');
    }
});

function clearLogs() {
    document.getElementById('log-viewer').innerHTML = '<div class="text-center p-4 text-muted">Logs cleared</div>';
    showToast('Logs cleared', 'success');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function setupAutoRefresh() {
    const autoRefresh = document.getElementById('auto-refresh');

    if (autoRefresh && autoRefresh.checked) {
        refreshInterval = setInterval(() => {
            const activePage = document.querySelector('.sidebar-menu a.active').dataset.page;
            if (activePage === 'dashboard') {
                loadDashboard();
            }
        }, 30000);
    }
}

document.getElementById('auto-refresh')?.addEventListener('change', (e) => {
    if (e.target.checked) {
        setupAutoRefresh();
    } else {
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    }
});

document.getElementById('dark-theme')?.addEventListener('change', (e) => {
    if (e.target.checked) {
        document.body.classList.add('dark-theme');
        document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        document.body.classList.remove('dark-theme');
        document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-moon"></i>';
    }
    localStorage.setItem('darkTheme', e.target.checked);
});

window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

// Toggle port field based on protocol selection
function togglePortField() {
    const protocol = document.getElementById('rule-protocol').value;
    const portField = document.getElementById('port-field') || document.getElementById('rule-port').parentElement;

    if (protocol === 'icmp') {
        portField.style.display = 'none';
        document.getElementById('rule-port').value = '';
    } else {
        portField.style.display = 'block';
    }
}

// Update rule form based on rule type
function updateRuleForm() {
    const ruleType = document.getElementById('rule-type').value;
    const portFields = document.getElementById('port-fields');
    const ipFields = document.getElementById('ip-fields');

    if (ruleType === 'port') {
        if (portFields) portFields.style.display = 'block';
        if (ipFields) ipFields.style.display = 'none';
    } else {
        if (portFields) portFields.style.display = 'none';
        if (ipFields) ipFields.style.display = 'block';
    }
}

// Initialize app
const savedToken = localStorage.getItem('authToken');
if (savedToken) {
    authToken = savedToken;
    apiCall('/auth/profile').then(async response => {
        if (response) {
            const data = await response.json();
            if (data.success) {
                currentUser = data.user;
                showApp();
            } else {
                showLogin();
            }
        }
    });
} else {
    showLogin();
}

const savedTheme = localStorage.getItem('darkTheme');
if (savedTheme === 'true') {
    document.body.classList.add('dark-theme');
    document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-sun"></i>';
}