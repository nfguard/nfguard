#!/bin/bash
set -e

VERSION="0.0.1"
BUILD_DIR="nfguard-${VERSION}"
PACKAGE_NAME="${BUILD_DIR}.tar.gz"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}============================================"
echo " NFGuard Build Script v${VERSION}"
echo " Creating standalone package"
echo -e "============================================${NC}"

echo -e "${YELLOW}Cleaning previous builds...${NC}"
rm -rf "${BUILD_DIR}" "${PACKAGE_NAME}"

echo -e "${YELLOW}Creating build directory...${NC}"
mkdir -p "${BUILD_DIR}"

echo -e "${YELLOW}Copying source files...${NC}"
cp -r src "${BUILD_DIR}/"
cp -r web "${BUILD_DIR}/"
cp package.json "${BUILD_DIR}/"
cp package-lock.json "${BUILD_DIR}/"
cp install.sh "${BUILD_DIR}/"
cp README.md "${BUILD_DIR}/"
cp .gitignore "${BUILD_DIR}/"

echo -e "${YELLOW}Preparing production package.json...${NC}"
cd "${BUILD_DIR}"
cat > package.json <<'EOF'
{
  "name": "nfguard",
  "version": "0.0.1",
  "description": "Advanced NFTables Firewall Management Tool with CLI and WebGUI",
  "main": "src/index.js",
  "bin": {
    "nfguard": "src/cli/index.js"
  },
  "scripts": {
    "start": "node src/index.js",
    "install-service": "bash install.sh"
  },
  "keywords": [
    "firewall",
    "nftables",
    "security",
    "linux",
    "geo-blocking"
  ],
  "author": "Lucas Cat�o de Moraes <lucas@dolutech.com>",
  "license": "MIT",
  "homepage": "https://nfguard.org",
  "repository": {
    "type": "git",
    "url": "https://github.com/nfguard/nfguard.git"
  },
  "bugs": {
    "url": "https://github.com/nfguard/nfguard/issues"
  },
  "engines": {
    "node": ">=22.0.0"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "body-parser": "^1.20.2",
    "chalk": "^4.1.2",
    "cli-table3": "^0.6.3",
    "commander": "^11.1.0",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "express-session": "^1.17.3",
    "fs-extra": "^11.1.1",
    "ip-cidr": "^4.0.2",
    "jsonwebtoken": "^9.0.2",
    "maxmind": "^5.0.0",
    "winston": "^3.11.0"
  }
}
EOF

echo -e "${YELLOW}Installing production dependencies...${NC}"
npm install --production --no-optional

rm -rf .git
rm -f package-lock.json

cat > README.md <<'EOF'
# NFGuard - Advanced Firewall Management Tool

NFGuard is a comprehensive firewall management solution that provides both CLI and WebGUI interfaces for managing NFTables rules on Linux systems.

- **Repository**: https://github.com/nfguard/nfguard
- **Version**: v0.0.1
- **Developer**: Lucas Cat�o de Moraes
- **Website**: https://nfguard.org
- **Company**: https://dolutech.com

## Features
- WebGUI served over HTTPS (port 8443)
- Full-featured CLI utility (`nfguard`)
- Geo-blocking powered by MaxMind GeoLite2
- Real-time monitoring and statistics
- Configuration export/import tooling
- Universal installer for major Linux distributions

## Quick Installation
```bash
# Extract the package
tar -xzf nfguard-0.0.1.tar.gz
cd nfguard-0.0.1

# Run installer as root
sudo bash install.sh
```

## Default Access
- **WebGUI**: https://your-server-ip:8443
- **Default login**: nfguard / nfguard
- **CLI help**: `nfguard --help`

## Common CLI Examples
```bash
nfguard allow -p 80                     # Allow HTTP
nfguard block -p 53 -P udp -D output    # Block outbound DNS
nfguard block -s 192.168.1.100          # Block source IP
nfguard geo-block CN                    # Block country
nfguard list                            # Show saved and active rules
```

## Service Management
```bash
systemctl start nfguard
systemctl stop nfguard
systemctl restart nfguard
systemctl status nfguard
```

## Security Notes
- HTTPS-only WebGUI with self-signed certificates
- JWT authentication with rotating tokens
- Passwords hashed via bcrypt
- Detailed audit logging for all administrative actions

## Support
For documentation, issues, and updates visit https://github.com/nfguard/nfguard
EOF

cd ..

echo -e "${YELLOW}Creating tar.gz package...${NC}"
tar -czf "${PACKAGE_NAME}" "${BUILD_DIR}/"
PACKAGE_SIZE=$(du -h "${PACKAGE_NAME}" | cut -f1)

rm -rf "${BUILD_DIR}"

echo -e "${GREEN}============================================"
echo " Build complete!"
echo " Package : ${PACKAGE_NAME}"
echo " Size    : ${PACKAGE_SIZE}"
echo

echo " Next steps:"
echo "  1. tar -xzf ${PACKAGE_NAME}"
echo "  2. cd nfguard-${VERSION}"
echo "  3. sudo bash install.sh"
echo -e "============================================${NC}"
