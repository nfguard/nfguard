#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════╗"
echo "║        NFGuard Installation Script        ║"
echo "║          Firewall Management Tool         ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}"
   exit 1
fi

detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        ID=$ID
    elif type lsb_release >/dev/null 2>&1; then
        OS=$(lsb_release -si)
        VER=$(lsb_release -sr)
    elif [ -f /etc/lsb-release ]; then
        . /etc/lsb-release
        OS=$DISTRIB_ID
        VER=$DISTRIB_RELEASE
    else
        OS=$(uname -s)
        VER=$(uname -r)
    fi

    echo -e "${GREEN}Detected: $OS $VER${NC}"
}

check_dependencies() {
    echo -e "${YELLOW}Checking dependencies...${NC}"

    MISSING_DEPS=()

    if ! command -v iptables &> /dev/null; then
        MISSING_DEPS+=("iptables")
    fi

    if ! command -v node &> /dev/null; then
        MISSING_DEPS+=("nodejs")
    else
        # Check Node.js version (require 22.19.0+)
        NODE_VERSION=$(node --version | cut -d'v' -f2)
        NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1)
        NODE_MINOR=$(echo $NODE_VERSION | cut -d'.' -f2)
        NODE_PATCH=$(echo $NODE_VERSION | cut -d'.' -f3)

        if [ "$NODE_MAJOR" -lt 22 ] || \
           [ "$NODE_MAJOR" -eq 22 -a "$NODE_MINOR" -lt 19 ]; then
            echo -e "${YELLOW}Node.js version $NODE_VERSION detected. Upgrading to v22.19.0 LTS...${NC}"
            MISSING_DEPS+=("nodejs")
        fi
    fi

    if ! command -v npm &> /dev/null; then
        MISSING_DEPS+=("npm")
    fi

    if ! command -v openssl &> /dev/null; then
        MISSING_DEPS+=("openssl")
    fi

    if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
        echo -e "${YELLOW}Missing dependencies: ${MISSING_DEPS[*]}${NC}"
        return 1
    fi

    return 0
}

install_dependencies() {
    echo -e "${YELLOW}Installing dependencies...${NC}"

    case $ID in
        ubuntu|debian)
            apt-get update
            # Install Node.js 22 from NodeSource
            curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
            apt-get install -y iptables nodejs openssl curl wget
            ;;
        fedora|rhel|centos)
            # Install Node.js 22 from NodeSource
            curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
            dnf install -y iptables nodejs openssl curl wget
            ;;
        arch|manjaro)
            pacman -Sy --noconfirm iptables nodejs npm openssl curl wget
            ;;
        opensuse*)
            # Install Node.js 22 from NodeSource
            curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
            zypper install -y iptables nodejs openssl curl wget
            ;;
        alpine)
            apk add --no-cache iptables nodejs npm openssl curl wget
            ;;
        *)
            echo -e "${RED}Unsupported distribution. Please install dependencies manually:${NC}"
            echo "- iptables"
            echo "- nodejs 22.19.0 LTS"
            echo "- npm"
            echo "- openssl"
            exit 1
            ;;
    esac
}

install_nfguard() {
    echo -e "${YELLOW}Installing NFGuard...${NC}"

    INSTALL_DIR="/opt/nfguard"
    CONFIG_DIR="/etc/nfguard"
    LOG_DIR="/var/log/nfguard"

    mkdir -p $INSTALL_DIR
    mkdir -p $CONFIG_DIR
    mkdir -p $LOG_DIR

    if [ -d "./src" ] && [ -f "./package.json" ]; then
        cp -r ./* $INSTALL_DIR/
    else
        echo -e "${RED}Source files not found. Please run this script from the NFGuard directory.${NC}"
        exit 1
    fi

    cd $INSTALL_DIR

    echo -e "${YELLOW}Installing Node.js dependencies...${NC}"
    npm install --production

    ln -sf $INSTALL_DIR/src/cli/index.js /usr/local/bin/nfguard
    chmod +x /usr/local/bin/nfguard

    echo -e "${GREEN}NFGuard installed successfully!${NC}"
}

create_systemd_service() {
    echo -e "${YELLOW}Creating systemd service...${NC}"

    cat > /etc/systemd/system/nfguard.service << EOF
[Unit]
Description=NFGuard Firewall Management Service
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/nfguard
ExecStart=/usr/bin/node /opt/nfguard/src/index.js
Restart=always
RestartSec=10
StandardOutput=append:/var/log/nfguard/service.log
StandardError=append:/var/log/nfguard/error.log
Environment="NODE_ENV=production"
Environment="PORT=8443"

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable nfguard.service

    echo -e "${GREEN}Systemd service created successfully!${NC}"
}

create_openrc_service() {
    echo -e "${YELLOW}Creating OpenRC service...${NC}"

    cat > /etc/init.d/nfguard << 'EOF'
#!/sbin/openrc-run

name="NFGuard"
description="NFGuard Firewall Management Service"
command="/usr/bin/node"
command_args="/opt/nfguard/src/index.js"
command_background="yes"
pidfile="/run/${RC_SVCNAME}.pid"
start_stop_daemon_args="--stdout /var/log/nfguard/service.log --stderr /var/log/nfguard/error.log"

depend() {
    need net
    after iptables
}

start_pre() {
    checkpath --directory --mode 0755 /var/log/nfguard
}
EOF

    chmod +x /etc/init.d/nfguard
    rc-update add nfguard default

    echo -e "${GREEN}OpenRC service created successfully!${NC}"
}

setup_firewall_rules() {
    echo -e "${YELLOW}Setting up initial firewall rules...${NC}"

    nft flush ruleset 2>/dev/null || true

    nft add table inet nfguard
    nft add chain inet nfguard input { type filter hook input priority 0 \; policy drop \; }
    nft add chain inet nfguard forward { type filter hook forward priority 0 \; policy drop \; }
    nft add chain inet nfguard output { type filter hook output priority 0 \; policy accept \; }

    nft add rule inet nfguard input iif lo accept
    nft add rule inet nfguard input ct state established,related accept
    nft add rule inet nfguard input tcp dport 22 accept
    nft add rule inet nfguard input tcp dport 8443 accept
    nft add rule inet nfguard input ct state invalid drop

    echo -e "${GREEN}Firewall rules configured!${NC}"
}

generate_ssl_certificates() {
    echo -e "${YELLOW}Generating SSL certificates...${NC}"

    SSL_DIR="/etc/nfguard/ssl"
    mkdir -p $SSL_DIR

    if [ ! -f "$SSL_DIR/cert.pem" ] || [ ! -f "$SSL_DIR/key.pem" ]; then
        openssl req -x509 -newkey rsa:2048 -nodes \
            -keyout $SSL_DIR/key.pem \
            -out $SSL_DIR/cert.pem \
            -days 365 \
            -subj "/C=US/ST=State/L=City/O=NFGuard/CN=localhost"

        chmod 600 $SSL_DIR/key.pem
        chmod 644 $SSL_DIR/cert.pem
    fi

    echo -e "${GREEN}SSL certificates generated!${NC}"
}

start_service() {
    echo -e "${YELLOW}Starting NFGuard service...${NC}"

    if command -v systemctl &> /dev/null; then
        systemctl start nfguard
        systemctl status nfguard --no-pager
    elif command -v rc-service &> /dev/null; then
        rc-service nfguard start
    else
        echo -e "${YELLOW}Please start the service manually:${NC}"
        echo "node /opt/nfguard/src/index.js"
    fi
}

print_success_message() {
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════╗"
    echo "║         NFGuard Installation Complete!           ║"
    echo "╠═══════════════════════════════════════════════════╣"
    echo "║                                                   ║"
    echo "║  WebGUI: https://$(hostname -I | awk '{print $1}'):8443          ║"
    echo "║  Default Login: nfguard / nfguard                ║"
    echo "║                                                   ║"
    echo "║  CLI Commands:                                   ║"
    echo "║  - nfguard --help                               ║"
    echo "║  - nfguard allow -p 80                          ║"
    echo "║  - nfguard block -s 192.168.1.0/24             ║"
    echo "║  - nfguard geo-block CN                         ║"
    echo "║  - nfguard list                                 ║"
    echo "║                                                   ║"
    echo "║  Service Management:                            ║"
    echo "║  - systemctl start nfguard                      ║"
    echo "║  - systemctl stop nfguard                       ║"
    echo "║  - systemctl restart nfguard                    ║"
    echo "║  - systemctl status nfguard                     ║"
    echo "║                                                   ║"
    echo "║  IMPORTANT: Change the default password!        ║"
    echo "╚═══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

main() {
    detect_distro

    if ! check_dependencies; then
        echo -e "${YELLOW}Installing missing dependencies...${NC}"
        install_dependencies
    fi

    install_nfguard

    if command -v systemctl &> /dev/null; then
        create_systemd_service
    elif command -v rc-service &> /dev/null; then
        create_openrc_service
    fi

    setup_firewall_rules
    generate_ssl_certificates

    echo -e "${YELLOW}Do you want to start NFGuard now? (y/n)${NC}"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        start_service
    fi

    print_success_message
}

main "$@"