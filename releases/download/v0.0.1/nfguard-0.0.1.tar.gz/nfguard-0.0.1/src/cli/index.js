#!/usr/bin/env node

// Check if running as root for firewall operations
if (process.getuid && process.getuid() !== 0) {
    console.error('\x1b[31m%s\x1b[0m', '✗ NFGuard CLI must be run as root for firewall management.');
    console.error('  Please run with: sudo nfguard <command>');
    process.exit(1);
}

const { program } = require('commander');
const chalk = require('chalk');
const { execSync } = require('child_process');
const UFWManager = require('../core/ufw-manager');
const GeoBlocker = require('../core/geo-blocker');
const Updater = require('../core/updater');
const Table = require('cli-table3');
const fs = require('fs-extra');

const ufw = new UFWManager();
const geoBlocker = new GeoBlocker(ufw);
const updater = new Updater();

// Helper Functions
function buildRuleFromOptions(options, action) {
    const direction = (options.direction || 'in').toLowerCase();
    const rawProtocol = options.protocol ? options.protocol.toLowerCase() : 'tcp';
    const source = options.source ? options.source.trim() : undefined;
    const destination = options.destination ? options.destination.trim() : undefined;
    const port = options.port ? String(options.port).trim() : undefined;

    let type;
    let protocol = rawProtocol;

    if (rawProtocol === 'icmp') {
        type = 'icmp';
        protocol = 'icmp';
    } else if (port) {
        type = 'port';
    } else if (source || destination) {
        type = source && source.includes('/') ? 'network' : 'ip';
        protocol = undefined;
    } else {
        throw new Error('Specify a port or an IP/network for this rule');
    }

    if (type === 'port' && !port) {
        throw new Error('Port is required for TCP or UDP rules');
    }

    if ((type === 'ip' || type === 'network') && !source && !destination) {
        throw new Error('Source or destination is required for IP or network rules');
    }

    return {
        type,
        direction,
        protocol,
        port,
        source,
        destination,
        action,
        comment: options.comment || `NFGuard ${action} rule`
    };
}

function formatRulesTable(rules, verbose = false) {
    if (!rules || rules.length === 0) {
        return chalk.yellow('No rules found');
    }

    const table = new Table({
        head: verbose ?
            ['#', 'Rule ID', 'Action', 'Protocol', 'Port', 'Source', 'Direction', 'Comment', 'Created'] :
            ['#', 'Rule ID', 'Action', 'Protocol', 'Port', 'Source', 'Direction', 'Comment'],
        colors: false,
        style: { head: ['cyan'], border: ['gray'] },
        colWidths: verbose ? [3, 10, 8, 8, 8, 15, 8, 20, 12] : [3, 10, 8, 8, 8, 15, 8, 20]
    });

    rules.forEach((rule, index) => {
        const actionColor = rule.action === 'allow' ? chalk.green :
                           rule.action === 'reject' ? chalk.yellow : chalk.red;

        const row = [
            chalk.gray(index + 1),
            chalk.blue(rule.id ? rule.id.substring(0, 8) : 'N/A'),
            actionColor(rule.action.toUpperCase()),
            rule.protocol ? chalk.cyan(rule.protocol) : chalk.gray('-'),
            rule.port ? chalk.magenta(rule.port) : chalk.gray('-'),
            rule.source ? chalk.green(rule.source) : chalk.gray('Any'),
            rule.direction ? chalk.yellow(rule.direction) : chalk.gray('in'),
            rule.comment ? rule.comment.substring(0, 18) + (rule.comment.length > 18 ? '...' : '') : chalk.gray('-')
        ];

        if (verbose && rule.createdAt) {
            row.push(chalk.gray(new Date(rule.createdAt).toLocaleDateString()));
        }

        table.push(row);
    });

    return table.toString();
}

function formatStatusOutput(stats) {
    const table = new Table({
        head: ['Property', 'Value'],
        colors: false,
        style: { head: ['cyan'], border: ['gray'] }
    });

    table.push(
        ['Status', stats.status === 'active' ? chalk.green('Active') : chalk.red('Inactive')],
        ['Default Incoming', stats.default_incoming === 'deny' ? chalk.red('Deny') : chalk.green('Allow')],
        ['Default Outgoing', stats.default_outgoing === 'allow' ? chalk.green('Allow') : chalk.red('Deny')],
        ['Default Forward', stats.default_forward || 'Deny'],
        ['Logging', stats.logging || 'Off'],
        ['Total Rules', stats.total_rules || 0],
        ['Active Rules', stats.active_count || 0]
    );

    return table.toString();
}

function commandExists(cmd) {
    try {
        execSync(`command -v ${cmd}`, { stdio: 'ignore' });
        return true;
    } catch (error) {
        return false;
    }
}

// ================================
// FIREWALL MANAGEMENT COMMANDS
// ================================

// Status Command
program
    .command('status')
    .description('Show detailed firewall status and rules')
    .option('-v, --verbose', 'Show verbose output')
    .option('-n, --numbered', 'Show rule numbers')
    .action(async (options) => {
        try {
            console.log(chalk.blue.bold('🔍 NFGuard Firewall Status\n'));

            const stats = await ufw.getStatistics();
            console.log(formatStatusOutput(stats));

            if (options.verbose) {
                console.log('\n' + chalk.blue.bold('📋 Active Rules:'));
                const rules = await ufw.listRules();
                console.log(formatRulesTable(rules));
            }
        } catch (error) {
            console.error(chalk.red('✗ Error getting status:'), error.message);
        }
    });

// Enable/Disable Commands
program
    .command('enable')
    .description('Enable UFW firewall')
    .action(async () => {
        try {
            await ufw.executeCommand('ufw --force enable');
            console.log(chalk.green('✓ Firewall enabled'));
        } catch (error) {
            console.error(chalk.red('✗ Error enabling firewall:'), error.message);
        }
    });

program
    .command('disable')
    .description('Disable UFW firewall')
    .action(async () => {
        try {
            await ufw.executeCommand('ufw --force disable');
            console.log(chalk.yellow('⚠ Firewall disabled'));
        } catch (error) {
            console.error(chalk.red('✗ Error disabling firewall:'), error.message);
        }
    });

// Reset Command
program
    .command('reset')
    .description('Reset firewall to default settings')
    .option('-f, --force', 'Force reset without confirmation')
    .action(async (options) => {
        try {
            if (!options.force) {
                console.log(chalk.yellow('⚠ This will reset ALL firewall rules to defaults'));
                console.log('Use --force to confirm');
                return;
            }

            await ufw.flushRules();
            console.log(chalk.green('✓ Firewall reset to defaults'));
        } catch (error) {
            console.error(chalk.red('✗ Error resetting firewall:'), error.message);
        }
    });

// ================================
// RULE MANAGEMENT COMMANDS
// ================================

// Allow Command
program
    .command('allow')
    .description('Add allow rule')
    .option('-p, --port <port>', 'Port number or range (e.g., 80, 1000:2000)')
    .option('-P, --protocol <proto>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP or network')
    .option('-d, --destination <ip>', 'Destination IP or network')
    .option('-D, --direction <dir>', 'Direction (in/out)', 'in')
    .option('-c, --comment <text>', 'Comment for the rule')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'allow');
            await ufw.addRule(rule);
            console.log(chalk.green('✓ Allow rule added successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Error adding allow rule:'), error.message);
        }
    });

// Block/Deny Command
program
    .command('block')
    .alias('deny')
    .description('Add block/deny rule')
    .option('-p, --port <port>', 'Port number or range')
    .option('-P, --protocol <proto>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP or network')
    .option('-d, --destination <ip>', 'Destination IP or network')
    .option('-D, --direction <dir>', 'Direction (in/out)', 'in')
    .option('-c, --comment <text>', 'Comment for the rule')
    .action(async (options) => {
        try {
            console.log('🔍 Checking for conflicting rules...');
            const rule = buildRuleFromOptions(options, 'deny');
            await ufw.addRule(rule);
            console.log(chalk.red('✓ Block rule added successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Error adding block rule:'), error.message);
        }
    });

// Reject Command
program
    .command('reject')
    .description('Add reject rule (sends rejection response)')
    .option('-p, --port <port>', 'Port number or range')
    .option('-P, --protocol <proto>', 'Protocol (tcp/udp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP or network')
    .option('-d, --destination <ip>', 'Destination IP or network')
    .option('-D, --direction <dir>', 'Direction (in/out)', 'in')
    .option('-c, --comment <text>', 'Comment for the rule')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'reject');
            await ufw.addRule(rule);
            console.log(chalk.yellow('✓ Reject rule added successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Error adding reject rule:'), error.message);
        }
    });

// Delete Rule Command
program
    .command('delete <ruleId>')
    .description('Delete a specific rule by ID')
    .option('--preview', 'Preview rule before deletion')
    .action(async (ruleId, options) => {
        try {
            const rules = await ufw.listRules();
            const rule = rules.find(r => r.id.startsWith(ruleId));

            if (!rule) {
                console.error(chalk.red('✗ Rule not found'));
                return;
            }

            if (options.preview) {
                console.log(chalk.blue('Rule to delete:'));
                console.log(`  ${rule.action.toUpperCase()} ${rule.protocol || ''} ${rule.port || ''} ${rule.source ? 'from ' + rule.source : ''}`);
                console.log('Use without --preview to confirm deletion');
                return;
            }

            await ufw.deleteRule(ruleId);
            console.log(chalk.green('✓ Rule deleted successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Error deleting rule:'), error.message);
        }
    });

// List Rules Command
program
    .command('list')
    .alias('ls')
    .description('List all firewall rules')
    .option('-v, --verbose', 'Show detailed information')
    .option('-n, --numbered', 'Show rule numbers')
    .option('-a, --all', 'Show all UFW rules including system rules')
    .action(async (options) => {
        try {
            const rules = await ufw.listRules();
            console.log(chalk.blue.bold('📋 NFGuard Firewall Rules\n'));

            if (rules.length === 0) {
                console.log(chalk.yellow('No custom rules found. Use "nfguard allow" or "nfguard block" to add rules.'));
                return;
            }

            console.log(formatRulesTable(rules, options.verbose));

            if (options.all) {
                console.log('\n' + chalk.cyan.bold('🔍 Current UFW Status:\n'));
                try {
                    const { stdout } = await ufw.executeCommand('ufw status numbered');
                    console.log(stdout);
                } catch (error) {
                    console.log(chalk.red('Failed to get UFW status'));
                }
            }

            console.log(chalk.gray(`\nTotal rules: ${rules.length}`));

        } catch (error) {
            console.error(chalk.red('✗ Error listing rules:'), error.message);
        }
    });

// Rules Management Commands
const rulesCommand = program
    .command('rules')
    .description('Advanced rule management commands');

rulesCommand
    .command('remove <ruleId>')
    .alias('rm')
    .description('Remove a specific rule by ID')
    .option('--preview', 'Preview rule before deletion')
    .action(async (ruleId, options) => {
        try {
            const rules = await ufw.listRules();
            const rule = rules.find(r => r.id.startsWith(ruleId));

            if (!rule) {
                console.error(chalk.red('✗ Rule not found'));
                console.log(chalk.yellow('Use "nfguard list" to see available rule IDs'));
                return;
            }

            if (options.preview) {
                console.log(chalk.blue.bold('📋 Rule Preview:\n'));
                const table = new Table({
                    head: ['Property', 'Value'],
                    colors: false,
                    style: { head: ['cyan'], border: ['gray'] }
                });

                table.push(
                    ['Rule ID', rule.id.substring(0, 8) + '...'],
                    ['Action', rule.action.toUpperCase()],
                    ['Protocol', rule.protocol || 'Any'],
                    ['Port', rule.port || 'Any'],
                    ['Source', rule.source || 'Any'],
                    ['Direction', rule.direction || 'in'],
                    ['Comment', rule.comment || 'None']
                );

                console.log(table.toString());
                console.log(chalk.yellow('\nUse without --preview to confirm deletion'));
                return;
            }

            console.log(chalk.yellow(`⚠ Removing rule: ${rule.action.toUpperCase()} ${rule.protocol || ''} ${rule.port || ''}`));

            await ufw.deleteRule(ruleId);
            console.log(chalk.green('✓ Rule deleted successfully'));

        } catch (error) {
            console.error(chalk.red('✗ Error deleting rule:'), error.message);
        }
    });

rulesCommand
    .command('show <ruleId>')
    .description('Show detailed information about a specific rule')
    .action(async (ruleId) => {
        try {
            const rules = await ufw.listRules();
            const rule = rules.find(r => r.id.startsWith(ruleId));

            if (!rule) {
                console.error(chalk.red('✗ Rule not found'));
                return;
            }

            console.log(chalk.blue.bold(`📋 Rule Details: ${rule.id.substring(0, 8)}\n`));

            const table = new Table({
                head: ['Property', 'Value'],
                colors: false,
                style: { head: ['cyan'], border: ['gray'] }
            });

            table.push(
                ['Full ID', rule.id],
                ['Type', rule.type || 'Unknown'],
                ['Action', rule.action.toUpperCase()],
                ['Protocol', rule.protocol || 'Any'],
                ['Port', rule.port || 'Any'],
                ['Source', rule.source || 'Any'],
                ['Destination', rule.destination || 'Any'],
                ['Direction', rule.direction || 'in'],
                ['Comment', rule.comment || 'None'],
                ['Created', rule.createdAt ? new Date(rule.createdAt).toLocaleString() : 'Unknown']
            );

            console.log(table.toString());

        } catch (error) {
            console.error(chalk.red('✗ Error showing rule:'), error.message);
        }
    });

rulesCommand
    .command('count')
    .description('Show rule statistics')
    .action(async () => {
        try {
            const rules = await ufw.listRules();
            const stats = await ufw.getStatistics();

            console.log(chalk.blue.bold('📊 Rule Statistics\n'));

            const table = new Table({
                head: ['Statistic', 'Count'],
                colors: false,
                style: { head: ['cyan'], border: ['gray'] }
            });

            const allowRules = rules.filter(r => r.action === 'allow').length;
            const denyRules = rules.filter(r => r.action === 'deny' || r.action === 'drop').length;
            const rejectRules = rules.filter(r => r.action === 'reject').length;

            table.push(
                ['Total Rules', rules.length],
                ['Allow Rules', allowRules],
                ['Deny/Drop Rules', denyRules],
                ['Reject Rules', rejectRules],
                ['UFW Status', stats.status || 'Unknown'],
                ['Active UFW Rules', stats.active_count || 0]
            );

            console.log(table.toString());

        } catch (error) {
            console.error(chalk.red('✗ Error getting statistics:'), error.message);
        }
    });

// ================================
// DEFAULT POLICY COMMANDS
// ================================

program
    .command('default <direction> <policy>')
    .description('Set default policy (incoming/outgoing/forward allow/deny)')
    .action(async (direction, policy) => {
        try {
            const validDirections = ['incoming', 'outgoing', 'forward'];
            const validPolicies = ['allow', 'deny', 'reject'];

            if (!validDirections.includes(direction)) {
                console.error(chalk.red('✗ Invalid direction. Use: incoming, outgoing, or forward'));
                return;
            }

            if (!validPolicies.includes(policy)) {
                console.error(chalk.red('✗ Invalid policy. Use: allow, deny, or reject'));
                return;
            }

            await ufw.executeCommand(`ufw default ${policy} ${direction}`);
            console.log(chalk.green(`✓ Default ${direction} policy set to ${policy.toUpperCase()}`));
        } catch (error) {
            console.error(chalk.red('✗ Error setting default policy:'), error.message);
        }
    });

// ================================
// LOGGING COMMANDS
// ================================

program
    .command('logging <level>')
    .description('Set logging level (off/low/medium/high/full)')
    .action(async (level) => {
        try {
            const validLevels = ['off', 'low', 'medium', 'high', 'full'];

            if (!validLevels.includes(level)) {
                console.error(chalk.red('✗ Invalid logging level. Use: off, low, medium, high, or full'));
                return;
            }

            await ufw.executeCommand(`ufw logging ${level}`);
            console.log(chalk.green(`✓ Logging set to ${level.toUpperCase()}`));
        } catch (error) {
            console.error(chalk.red('✗ Error setting logging:'), error.message);
        }
    });

// ================================
// GEO-BLOCKING COMMANDS
// ================================

program
    .command('geo-block <countryCode>')
    .description('Block traffic from a specific country using ipset')
    .option('-c, --comment <comment>', 'Add comment to the block rule')
    .action(async (countryCode, options) => {
        try {
            console.log(chalk.blue(`🌍 Blocking traffic from ${countryCode.toUpperCase()}...`));
            console.log(chalk.gray('  Creating ipset and applying firewall rules...'));

            const result = await geoBlocker.blockCountry(countryCode.toUpperCase());

            console.log(chalk.green(`✓ Country ${countryCode.toUpperCase()} blocked successfully`));
            console.log(chalk.gray(`  📊 Blocked ${result.rulesAdded} IP ranges using ipset: ${result.ipsetName}`));
            console.log(chalk.gray(`  🛡️  Firewall rule applied for geo-blocking`));

            if (options.comment) {
                console.log(chalk.gray(`  💬 Comment: ${options.comment}`));
            }
        } catch (error) {
            console.error(chalk.red('✗ Error blocking country:'), error.message);
            if (error.message.includes('ipset')) {
                console.error(chalk.yellow('  💡 Hint: Make sure ipset is installed and you have root permissions'));
            }
        }
    });

program
    .command('geo-stats')
    .description('Show geo-blocking statistics and ipset information')
    .action(async () => {
        try {
            const stats = await geoBlocker.getGeoStats();

            console.log(chalk.blue.bold('📊 Geo-blocking Statistics:\n'));

            console.log(chalk.cyan('Database Status:'));
            console.log(chalk.gray(`  MMDB database: ${stats.mmdbAvailable ? '✓ Available' : '✗ Not found'}`));
            console.log(chalk.gray(`  Country data: ${stats.countryDataLoaded ? '✓ Loaded' : '✗ Not loaded'}`));
            console.log();

            console.log(chalk.cyan('Blocking Status:'));
            console.log(chalk.gray(`  Blocked countries: ${stats.blockedCountries}`));
            console.log(chalk.gray(`  Total IP ranges: ${stats.totalBlocks}`));
            console.log(chalk.gray(`  Active ipsets: ${stats.ipsets.length}`));
            console.log();

            if (stats.ipsets.length > 0) {
                console.log(chalk.cyan('Active IPSets:'));
                stats.ipsets.forEach(ipset => {
                    console.log(chalk.gray(`  ${ipset.name} (${ipset.country}): ${ipset.entries} entries`));
                });
            }
        } catch (error) {
            console.error(chalk.red('✗ Error getting geo stats:'), error.message);
        }
    });

program
    .command('geo-unblock <countryCode>')
    .description('Unblock traffic from a specific country (removes ipset)')
    .action(async (countryCode) => {
        try {
            console.log(chalk.blue(`🌍 Unblocking traffic from ${countryCode.toUpperCase()}...`));
            console.log(chalk.gray('  Removing ipset and firewall rules...'));

            const result = await geoBlocker.unblockCountry(countryCode.toUpperCase());

            console.log(chalk.green(`✓ Country ${countryCode.toUpperCase()} unblocked successfully`));
            console.log(chalk.gray(`  🗑️  Removed ipset and associated firewall rules`));
        } catch (error) {
            console.error(chalk.red('✗ Error unblocking country:'), error.message);
            if (error.message.includes('not currently blocked')) {
                console.error(chalk.yellow(`  💡 Hint: Use 'nfguard geo-list' to see currently blocked countries`));
            }
        }
    });

program
    .command('geo-list')
    .description('List blocked countries with ipset information')
    .option('-v, --verbose', 'Show detailed information')
    .action(async (options) => {
        try {
            const countries = await geoBlocker.listBlockedCountries();
            if (countries.length === 0) {
                console.log(chalk.yellow('🌍 No countries currently blocked'));
                console.log(chalk.gray('  Use "nfguard geo-block <COUNTRY_CODE>" to block a country'));
                return;
            }

            console.log(chalk.blue.bold(`🌍 Blocked Countries (${countries.length}):\n`));

            if (options.verbose) {
                const stats = await geoBlocker.getGeoStats();
                console.log(chalk.cyan('📊 Geo-blocking Statistics:'));
                console.log(chalk.gray(`  Total blocked countries: ${stats.blockedCountries}`));
                console.log(chalk.gray(`  Total IP ranges: ${stats.totalBlocks}`));
                console.log(chalk.gray(`  Active ipsets: ${stats.ipsets.length}`));
                console.log(chalk.gray(`  MMDB database: ${stats.mmdbAvailable ? '✓ Available' : '✗ Not found'}`));
                console.log(chalk.gray(`  Country data: ${stats.countryDataLoaded ? '✓ Loaded' : '✗ Not loaded'}`));
                console.log();
            }

            countries.forEach(country => {
                console.log(chalk.red(`  ✗ ${country.code} - ${country.name || 'Unknown'}`));
                if (options.verbose && country.ipRanges) {
                    console.log(chalk.gray(`    IP ranges: ${country.ipRanges.length}`));
                    console.log(chalk.gray(`    Blocked at: ${new Date(country.blockedAt).toLocaleString()}`));
                }
            });
        } catch (error) {
            console.error(chalk.red('✗ Error listing blocked countries:'), error.message);
        }
    });

program
    .command('geo-check <ip>')
    .description('Check IP geolocation and blocking status')
    .action(async (ip) => {
        try {
            const info = await geoBlocker.checkIP(ip);
            console.log(chalk.blue.bold(`🔍 IP Information: ${ip}\n`));

            const table = new Table({
                head: ['Property', 'Value'],
                colors: false,
                style: { head: ['cyan'], border: ['gray'] }
            });

            table.push(
                ['Country', info.country || 'Unknown'],
                ['Country Code', info.countryCode || 'Unknown'],
                ['City', info.city || 'Unknown'],
                ['ISP', info.isp || 'Unknown'],
                ['Blocked', info.blocked ? chalk.red('Yes') : chalk.green('No')]
            );

            console.log(table.toString());
        } catch (error) {
            console.error(chalk.red('✗ Error checking IP:'), error.message);
        }
    });

// ================================
// ADVANCED COMMANDS
// ================================

program
    .command('backup <filename>')
    .description('Backup current firewall configuration')
    .action(async (filename) => {
        try {
            const config = await ufw.exportRules();
            await fs.writeJson(filename, config, { spaces: 2 });
            console.log(chalk.green(`✓ Configuration backed up to ${filename}`));
        } catch (error) {
            console.error(chalk.red('✗ Error backing up configuration:'), error.message);
        }
    });

program
    .command('restore <filename>')
    .description('Restore firewall configuration from backup')
    .option('-f, --force', 'Force restore without confirmation')
    .action(async (filename, options) => {
        try {
            if (!await fs.pathExists(filename)) {
                console.error(chalk.red('✗ Backup file not found'));
                return;
            }

            if (!options.force) {
                console.log(chalk.yellow('⚠ This will replace current configuration'));
                console.log('Use --force to confirm');
                return;
            }

            const config = await fs.readJson(filename);
            await ufw.importRules(config);
            console.log(chalk.green('✓ Configuration restored successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Error restoring configuration:'), error.message);
        }
    });

program
    .command('conflicts')
    .description('Check for rule conflicts')
    .action(async () => {
        try {
            console.log(chalk.blue.bold('🔍 Checking for rule conflicts...\n'));

            const rules = await ufw.listRules();
            const conflicts = [];

            for (let i = 0; i < rules.length; i++) {
                for (let j = i + 1; j < rules.length; j++) {
                    if (ufw.rulesConflict(rules[i], rules[j])) {
                        conflicts.push({ rule1: rules[i], rule2: rules[j] });
                    }
                }
            }

            if (conflicts.length === 0) {
                console.log(chalk.green('✓ No conflicts detected'));
                return;
            }

            console.log(chalk.red(`⚠ Found ${conflicts.length} conflict(s):\n`));
            conflicts.forEach((conflict, index) => {
                const r1 = conflict.rule1;
                const r2 = conflict.rule2;
                console.log(chalk.yellow(`Conflict ${index + 1}:`));
                console.log(`  Rule 1: ${r1.action.toUpperCase()} ${r1.protocol || ''} ${r1.port || ''} (${r1.id.substring(0, 8)})`);
                console.log(`  Rule 2: ${r2.action.toUpperCase()} ${r2.protocol || ''} ${r2.port || ''} (${r2.id.substring(0, 8)})\n`);
            });
        } catch (error) {
            console.error(chalk.red('✗ Error checking conflicts:'), error.message);
        }
    });

// ================================
// MONITORING COMMANDS
// ================================

program
    .command('logs')
    .description('Show recent firewall logs')
    .option('-n, --lines <number>', 'Number of lines to show', '50')
    .option('-f, --follow', 'Follow log output')
    .action(async (options) => {
        try {
            if (options.follow) {
                console.log(chalk.blue('📜 Following UFW logs (Ctrl+C to stop)...'));
                const { spawn } = require('child_process');
                const tail = spawn('tail', ['-f', '/var/log/ufw.log']);

                tail.stdout.on('data', (data) => {
                    console.log(data.toString().trim());
                });

                tail.stderr.on('data', (data) => {
                    console.error(chalk.red(data.toString().trim()));
                });
            } else {
                const { stdout } = await ufw.executeCommand(`tail -n ${options.lines} /var/log/ufw.log`);
                console.log(chalk.blue.bold('📜 Recent UFW Logs:\n'));
                console.log(stdout);
            }
        } catch (error) {
            console.error(chalk.red('✗ Error reading logs:'), error.message);
        }
    });

program
    .command('stats')
    .description('Show detailed firewall statistics')
    .action(async () => {
        try {
            const stats = await ufw.getStatistics();
            console.log(chalk.blue.bold('📊 Firewall Statistics\n'));
            console.log(formatStatusOutput(stats));
        } catch (error) {
            console.error(chalk.red('✗ Error getting statistics:'), error.message);
        }
    });

// ================================
// SERVICE MANAGEMENT
// ================================

program
    .command('service <action>')
    .description('Manage UFW service (start/stop/restart/status)')
    .action(async (action) => {
        try {
            const validActions = ['start', 'stop', 'restart', 'status'];

            if (!validActions.includes(action)) {
                console.error(chalk.red('✗ Invalid action. Use: start, stop, restart, or status'));
                return;
            }

            const { stdout } = await ufw.executeCommand(`systemctl ${action} ufw`);
            console.log(chalk.green(`✓ UFW service ${action} completed`));

            if (action === 'status') {
                console.log('\n' + stdout);
            }
        } catch (error) {
            console.error(chalk.red(`✗ Error ${action}ing UFW service:`), error.message);
        }
    });

program
    .command('uninstall')
    .description('Completely remove NFGuard from this system')
    .option('-f, --force', 'Skip confirmation prompt')
    .action(async (options) => {
        try {
            if (!options.force) {
                const readline = require('readline');
                const rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout
                });

                const answer = await new Promise((resolve) => {
                    rl.question(chalk.yellow('This will remove NFGuard completely, continue? (y/N): '), resolve);
                });

                rl.close();

                if (!answer || !['y', 'yes'].includes(answer.toLowerCase())) {
                    console.log(chalk.yellow('Uninstall cancelled.'));
                    return;
                }
            }

            console.log(chalk.blue.bold('\n🧹 NFGuard Uninstall\n'));

            const runCommand = (cmd, successMsg, failureMsg) => {
                try {
                    execSync(cmd, { stdio: 'ignore' });
                    if (successMsg) {
                        console.log(chalk.green(`✓ ${successMsg}`));
                    }
                } catch (error) {
                    if (failureMsg) {
                        console.log(chalk.gray(`• ${failureMsg}`));
                    }
                }
            };

            if (commandExists('systemctl')) {
                console.log(chalk.cyan('Stopping systemd service...'));
                runCommand('systemctl stop nfguard', 'NFGuard service stopped', 'NFGuard service already stopped');
                runCommand('systemctl disable nfguard', 'NFGuard service disabled', 'NFGuard service not enabled');

                const servicePath = '/etc/systemd/system/nfguard.service';
                if (await fs.pathExists(servicePath)) {
                    await fs.remove(servicePath);
                    console.log(chalk.green('✓ Removed systemd service file'));
                } else {
                    console.log(chalk.gray('• Systemd service file not found'));
                }

                runCommand('systemctl daemon-reload', 'Systemd daemon reloaded', 'Failed to reload systemd daemon (reload manually if needed)');
            } else if (commandExists('rc-service')) {
                console.log(chalk.cyan('Stopping OpenRC service...'));
                runCommand('rc-service nfguard stop', 'NFGuard service stopped', 'NFGuard service already stopped');
                runCommand('rc-update del nfguard default', 'Removed NFGuard from default runlevel', 'NFGuard not registered in default runlevel');

                const initPath = '/etc/init.d/nfguard';
                if (await fs.pathExists(initPath)) {
                    await fs.remove(initPath);
                    console.log(chalk.green('✓ Removed OpenRC service file'));
                } else {
                    console.log(chalk.gray('• OpenRC service file not found'));
                }
            } else {
                console.log(chalk.yellow('Service manager not detected. Stop any running NFGuard processes manually if needed.'));
            }

            const removalTargets = [
                { path: '/usr/local/bin/nfguard', label: 'CLI entry point' },
                { path: '/opt/nfguard', label: 'Application directory' },
                { path: '/etc/nfguard', label: 'Configuration directory' },
                { path: '/var/log/nfguard', label: 'Log directory' }
            ];

            for (const target of removalTargets) {
                if (await fs.pathExists(target.path)) {
                    await fs.remove(target.path);
                    console.log(chalk.green(`✓ Removed ${target.label}`));
                } else {
                    console.log(chalk.gray(`• ${target.label} already absent`));
                }
            }

            console.log(chalk.green.bold('\n✓ NFGuard has been completely removed from this system.'));
            console.log(chalk.gray('You may also remove any manual backups or dependencies if they are no longer needed.'));
        } catch (error) {
            console.error(chalk.red('✗ Uninstall failed:'), error.message);
        }
    });

// ================================
// MAIN PROGRAM SETUP
// ================================

// ================================
// UPDATE COMMANDS
// ================================

program
    .command('update-check')
    .description('Check for available updates')
    .action(async () => {
        try {
            console.log(chalk.blue.bold('🔍 Checking for updates...\n'));

            const status = await updater.getUpdateStatus();

            if (status.error) {
                console.error(chalk.red('✗ Error checking for updates:'), status.error);
                return;
            }

            console.log(chalk.cyan('Current version:'), chalk.yellow(status.currentVersion));
            console.log(chalk.cyan('Latest version:'), chalk.yellow(status.latestVersion));

            if (status.updateAvailable) {
                console.log(chalk.green.bold('\n🎉 Update available!'));
                console.log(chalk.gray(`Download URL: ${status.downloadUrl}`));
                console.log(chalk.yellow('\nRun'), chalk.cyan('nfguard update'), chalk.yellow('to install the update.'));
            } else {
                console.log(chalk.green.bold('\n✓ You are using the latest version!'));
            }
        } catch (error) {
            console.error(chalk.red('✗ Error checking for updates:'), error.message);
        }
    });

program
    .command('update')
    .description('Update NFGuard to the latest version')
    .option('-y, --yes', 'Auto-confirm update without prompting')
    .action(async (options) => {
        try {
            console.log(chalk.blue.bold('🚀 NFGuard Update Manager\n'));

            // Check for updates first
            console.log(chalk.blue('🔍 Checking for updates...'));
            const status = await updater.getUpdateStatus();

            if (status.error) {
                console.error(chalk.red('✗ Error checking for updates:'), status.error);
                return;
            }

            if (!status.updateAvailable) {
                console.log(chalk.green.bold('✓ You are already using the latest version!'));
                console.log(chalk.gray(`Current version: ${status.currentVersion}`));
                return;
            }

            console.log(chalk.cyan('Current version:'), chalk.yellow(status.currentVersion));
            console.log(chalk.cyan('Latest version:'), chalk.green(status.latestVersion));
            console.log();

            // Confirm update
            if (!options.yes) {
                const readline = require('readline');
                const rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout
                });

                const answer = await new Promise((resolve) => {
                    rl.question(chalk.yellow('Do you want to proceed with the update? (y/N): '), resolve);
                });

                rl.close();

                if (answer.toLowerCase() !== 'y' && answer.toLowerCase() !== 'yes') {
                    console.log(chalk.yellow('Update cancelled.'));
                    return;
                }
            }

            console.log(chalk.blue.bold('\n🔄 Starting update process...\n'));

            // Perform the update
            const result = await updater.performUpdate();

            if (result.success) {
                console.log(chalk.green.bold('✓ Update completed successfully!'));
                console.log(chalk.cyan('Updated from'), chalk.yellow(result.previousVersion), chalk.cyan('to'), chalk.green(result.newVersion));

                if (result.backupPath) {
                    console.log(chalk.gray(`Backup created at: ${result.backupPath}`));
                }

                console.log(chalk.yellow('\n⚠️  Please restart any active NFGuard services.'));
                console.log(chalk.cyan('The WebGUI service should restart automatically.'));
            } else {
                console.error(chalk.red('✗ Update failed:'), result.message);
            }
        } catch (error) {
            console.error(chalk.red('✗ Update failed:'), error.message);
            console.log(chalk.yellow('\n💡 If the update failed, NFGuard should have automatically rolled back to the previous version.'));
            console.log(chalk.cyan('Please check the service status:'), chalk.white('sudo systemctl status nfguard'));
        }
    });

program
    .command('version')
    .description('Show NFGuard version information')
    .action(async () => {
        try {
            const status = await updater.getUpdateStatus();

            console.log(chalk.blue.bold('📦 NFGuard Version Information\n'));
            console.log(chalk.cyan('Current Version:'), chalk.yellow(status.currentVersion));
            console.log(chalk.cyan('Latest Version:'), chalk.yellow(status.latestVersion || 'Unknown'));

            if (status.updateAvailable) {
                console.log(chalk.cyan('Status:'), chalk.red('Update available'));
                console.log(chalk.yellow('\nRun'), chalk.cyan('nfguard update-check'), chalk.yellow('for more details.'));
            } else {
                console.log(chalk.cyan('Status:'), chalk.green('Up to date'));
            }

            console.log();
            console.log(chalk.cyan('Author:'), 'Lucas Catão de Moraes');
            console.log(chalk.cyan('License:'), 'MIT');
            console.log(chalk.cyan('Homepage:'), chalk.blue('https://nfguard.org'));
        } catch (error) {
            console.log(chalk.blue.bold('📦 NFGuard Version Information\n'));
            console.log(chalk.cyan('Current Version:'), chalk.yellow('0.0.1'));
            console.log(chalk.cyan('Latest Version:'), chalk.red('Unknown (check failed)'));
            console.log(chalk.cyan('Author:'), 'Lucas Catão de Moraes');
            console.log(chalk.cyan('License:'), 'MIT');
        }
    });

program
    .name('nfguard')
    .description('NFGuard - Advanced UFW Firewall Management Tool')
    .version('0.0.1')
    .helpOption('-h, --help', 'Display help for command')
    .addHelpText('before', `
${chalk.blue.bold('╔══════════════════════════════════════════════════════════════╗')}
${chalk.blue.bold('║')}                   ${chalk.yellow.bold('NFGuard v0.0.1')}                           ${chalk.blue.bold('║')}
${chalk.blue.bold('║')}            ${chalk.gray('Advanced UFW Firewall Management')}               ${chalk.blue.bold('║')}
${chalk.blue.bold('╚══════════════════════════════════════════════════════════════╝')}

${chalk.cyan.bold('🔥 FIREWALL CONTROL:')}
  ${chalk.green('nfguard enable')}              Enable UFW firewall
  ${chalk.red('nfguard disable')}             Disable UFW firewall
  ${chalk.yellow('nfguard reload')}              Reload UFW configuration
  ${chalk.red('nfguard reset --force')}       Reset to default settings

${chalk.cyan.bold('📋 RULE MANAGEMENT:')}
  ${chalk.green('nfguard list')}               List all firewall rules
  ${chalk.green('nfguard list --verbose')}     Show detailed rule information
  ${chalk.green('nfguard list --all')}         Include UFW system rules

  ${chalk.blue('nfguard allow -p 80')}         Allow TCP port 80
  ${chalk.blue('nfguard allow -p 53 -P udp')} Allow UDP port 53 (DNS)
  ${chalk.blue('nfguard allow -p 22 -s 192.168.1.0/24')} Allow SSH from subnet

  ${chalk.red('nfguard block -p 3389')}        Block RDP port
  ${chalk.red('nfguard block -s 10.0.0.1')}   Block specific IP
  ${chalk.red('nfguard block -P icmp')}        Block ICMP/ping

  ${chalk.yellow('nfguard reject -p 23')}        Reject telnet (send rejection)

${chalk.cyan.bold('🔧 ADVANCED RULES:')}
  ${chalk.magenta('nfguard rules remove abc12345')}  Remove rule by ID
  ${chalk.magenta('nfguard rules remove abc12345 --preview')} Preview before delete
  ${chalk.magenta('nfguard rules show abc12345')}     Show detailed rule info
  ${chalk.magenta('nfguard rules count')}             Show rule statistics

${chalk.cyan.bold('🌍 GEO-BLOCKING:')}
  ${chalk.red('nfguard geo-block CN')}         Block traffic from China
  ${chalk.green('nfguard geo-unblock CN')}       Unblock country
  ${chalk.blue('nfguard geo-list')}             List blocked countries
  ${chalk.cyan('nfguard geo-check 8.8.8.8')}    Check IP location

${chalk.cyan.bold('⚙️  SYSTEM SETTINGS:')}
  ${chalk.blue('nfguard default incoming deny')} Set default incoming policy
  ${chalk.blue('nfguard default outgoing allow')} Set default outgoing policy
  ${chalk.blue('nfguard logging medium')}       Set logging level (off/low/medium/high/full)

${chalk.cyan.bold('📊 MONITORING:')}
  ${chalk.green('nfguard status')}             Show firewall status
  ${chalk.green('nfguard status --verbose')}   Detailed status with rules
  ${chalk.blue('nfguard stats')}              Show firewall statistics
  ${chalk.yellow('nfguard conflicts')}          Check for rule conflicts
  ${chalk.cyan('nfguard logs')}               Show recent UFW logs
  ${chalk.cyan('nfguard logs --follow')}       Follow logs in real-time

${chalk.cyan.bold('💾 BACKUP & RESTORE:')}
  ${chalk.blue('nfguard backup config.json')}  Backup configuration
  ${chalk.yellow('nfguard restore config.json --force')} Restore configuration

${chalk.cyan.bold('🔧 SERVICE CONTROL:')}
  ${chalk.green('nfguard service start')}      Start UFW service
  ${chalk.red('nfguard service stop')}       Stop UFW service
  ${chalk.yellow('nfguard service restart')}    Restart UFW service
  ${chalk.blue('nfguard service status')}     Show service status

${chalk.gray('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}
${chalk.yellow.bold('📝 EXAMPLES:')}

  ${chalk.gray('# Allow web server ports')}
  ${chalk.green('nfguard allow -p 80 -c "HTTP Web Server"')}
  ${chalk.green('nfguard allow -p 443 -c "HTTPS Web Server"')}

  ${chalk.gray('# Block dangerous ports')}
  ${chalk.red('nfguard block -p 135 -c "Block RPC"')}
  ${chalk.red('nfguard block -p 445 -c "Block SMB"')}

  ${chalk.gray('# Geographic blocking')}
  ${chalk.red('nfguard geo-block RU -c "Block Russia"')}
  ${chalk.red('nfguard geo-block CN -c "Block China"')}

  ${chalk.gray('# Allow from specific networks')}
  ${chalk.green('nfguard allow -p 22 -s 192.168.1.0/24 -c "SSH from LAN"')}
  ${chalk.green('nfguard allow -p 3306 -s 10.0.0.0/8 -c "MySQL from private"')}

  ${chalk.gray('# View and manage rules')}
  ${chalk.blue('nfguard list --verbose')}
  ${chalk.magenta('nfguard rules remove a1b2c3d4')}

${chalk.gray('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}
${chalk.yellow.bold('⚠️  IMPORTANT NOTES:')}

  • All commands require ${chalk.red.bold('sudo')} privileges
  • Rule IDs are shown in ${chalk.blue('nfguard list')} command
  • WebGUI available at ${chalk.cyan('https://localhost:8443')}
  • Default login: ${chalk.yellow('nfguard/nfguard')}
  • SSH and WebGUI ports are auto-detected and protected

${chalk.gray('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')}
    `);

// Add global options
program
    .option('-v, --verbose', 'Enable verbose output')
    .option('--no-color', 'Disable colored output');

// Handle unknown commands
program.on('command:*', () => {
    console.error(chalk.red('✗ Invalid command. Use --help to see available commands.'));
    process.exit(1);
});

// Show help if no arguments provided
if (process.argv.length <= 2) {
    program.help();
}

program.parse(process.argv);
