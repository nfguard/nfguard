#!/usr/bin/env node

const { program } = require('commander');
const chalk = require('chalk');
const UFWManager = require('../core/ufw-manager');
const GeoBlocker = require('../core/geo-blocker');
const Table = require('cli-table3');

const ufw = new UFWManager();
const geoBlocker = new GeoBlocker(ufw);

function buildRuleFromOptions(options, action) {
    const direction = (options.direction || 'in').toLowerCase();
    const rawProtocol = options.protocol ? options.protocol.toLowerCase() : 'tcp';
    const source = options.source ? options.source.trim() : undefined;
    const destination = options.destination ? options.destination.trim() : undefined;
    const port = options.port ? String(options.port).trim() : undefined;

    let type;
    let protocol = rawProtocol;

    if (rawProtocol === 'icmp') {
        type = 'icmp';
        protocol = 'icmp';
    } else if (port) {
        type = 'port';
    } else if (source || destination) {
        type = source && source.includes('/') ? 'network' : 'ip';
        protocol = undefined;
    } else {
        throw new Error('Specify a port or an IP/network for this rule');
    }

    if (type === 'port' && !port) {
        throw new Error('Port is required for TCP or UDP rules');
    }

    if ((type === 'ip' || type === 'network') && !source && !destination) {
        throw new Error('Source or destination is required for IP or network rules');
    }

    return {
        type,
        direction,
        protocol,
        port,
        source,
        destination,
        action,
        comment: options.comment
    };
}

function printSuccess(message) {
    console.log(chalk.green(`✓ ${message}`));
}

function printError(prefix, error) {
    const message = error && error.message ? error.message : error;
    console.error(chalk.red(`✗ ${prefix}`), message);
}

function printWarning(message) {
    console.log(chalk.yellow(`⚠ ${message}`));
}

program
    .name('nfguard')
    .description('NFGuard - Advanced UFW Firewall Management CLI')
    .version('1.0.0')
    .addHelpText('after', `
${chalk.cyan('Examples:')}
  $ nfguard list                    # List all firewall rules
  $ nfguard allow -p 80             # Allow TCP port 80
  $ nfguard block -s 192.168.1.100  # Block IP address
  $ nfguard block -P icmp           # Block ICMP (ping)
  $ nfguard geo-block CN            # Block traffic from China
  $ nfguard stats                   # Show firewall statistics

${chalk.yellow('Note:')} NFGuard uses UFW (Uncomplicated Firewall) for better rule management.
`);

program
    .command('init')
    .description('Initialize UFW with base configuration')
    .action(async () => {
        try {
            // Check if UFW is installed
            const isInstalled = await ufw.checkUFWInstalled();
            if (!isInstalled) {
                printWarning('UFW not installed. Installing...');
                await ufw.installUFW();
            }

            await ufw.initializeUFW();
            printSuccess('UFW initialized successfully');
            console.log(chalk.cyan('\nBase rules applied:'));
            console.log('  • SSH (port 22) - Allowed');
            console.log('  • NFGuard WebGUI (port 8443) - Allowed');
            console.log('  • Default: Deny incoming, Allow outgoing');
        } catch (error) {
            printError('Failed to initialize UFW:', error);
        }
    });

program
    .command('allow')
    .description('Allow traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (in/out)', 'in')
    .option('-c, --comment <comment>', 'Rule comment')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'allow');
            await ufw.addRule(rule);
            printSuccess('Rule added successfully');
        } catch (error) {
            printError('Failed to add rule:', error);
        }
    });

program
    .command('block')
    .description('Block traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (in/out)', 'in')
    .option('-c, --comment <comment>', 'Rule comment')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'deny');
            await ufw.addRule(rule);
            printSuccess('Rule added successfully');

            if (options.protocol === 'icmp') {
                console.log(chalk.cyan('ℹ ICMP blocking rule has been applied'));
                console.log(chalk.gray('  Note: UFW reload may be required for ICMP rules'));
            }
        } catch (error) {
            printError('Failed to add rule:', error);
        }
    });

program
    .command('geo-block <country>')
    .description('Block traffic from a country (use ISO code, e.g., CN, RU, US)')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.blockCountry(countryCode);
            printSuccess(`Blocked traffic from ${countryCode}`);
        } catch (error) {
            printError('Failed to block country:', error);
        }
    });

program
    .command('geo-unblock <country>')
    .description('Unblock traffic from a country')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.unblockCountry(countryCode);
            printSuccess(`Unblocked traffic from ${countryCode}`);
        } catch (error) {
            printError('Failed to unblock country:', error);
        }
    });

program
    .command('geo-list')
    .description('List blocked countries')
    .action(async () => {
        try {
            const countries = await geoBlocker.listBlockedCountries();

            if (countries.length === 0) {
                console.log(chalk.yellow('No countries are currently blocked'));
                return;
            }

            console.log(chalk.cyan('\n╔══════════════════════════════════════════════════════════════════╗'));
            console.log(chalk.cyan('║                      BLOCKED COUNTRIES                          ║'));
            console.log(chalk.cyan('╚══════════════════════════════════════════════════════════════════╝\n'));

            const table = new Table({
                head: ['Country Code', 'Country Name', 'IP Ranges', 'Blocked At'],
                colWidths: [15, 25, 15, 25],
                style: { head: ['cyan'] }
            });

            countries.forEach(country => {
                table.push([
                    country.code,
                    country.name,
                    country.ipRanges.length,
                    new Date(country.blockedAt).toLocaleString()
                ]);
            });

            console.log(table.toString());
        } catch (error) {
            printError('Failed to list blocked countries:', error);
        }
    });

program
    .command('list')
    .description('List all firewall rules')
    .option('-s, --saved', 'Show only saved rules')
    .option('-a, --active', 'Show only active UFW rules')
    .action(async (options) => {
        try {
            const rules = await ufw.listRules();

            // Header
            console.log();
            console.log(chalk.bgCyan.black('                     NFGuard Firewall Rules                      '));
            console.log();

            // Show saved rules if not filtered to active only
            if (!options.active) {
                console.log(chalk.cyan('┌─────────────────────────────────────────────────────────────────┐'));
                console.log(chalk.cyan('│                         SAVED RULES                            │'));
                console.log(chalk.cyan('└─────────────────────────────────────────────────────────────────┘'));

                if (rules.saved.length === 0) {
                    console.log(chalk.gray('  No saved rules configured\n'));
                } else {
                    const savedTable = new Table({
                        head: ['ID', 'Type', 'Protocol', 'Port', 'Source', 'Action', 'Created'],
                        colWidths: [10, 10, 10, 10, 20, 10, 25],
                        style: {
                            head: ['white'],
                            border: ['gray']
                        }
                    });

                    rules.saved.forEach(rule => {
                        const actionColor = rule.action === 'allow' || rule.action === 'ACCEPT' ?
                            chalk.green(rule.action.toUpperCase()) :
                            chalk.red(rule.action.toUpperCase());

                        savedTable.push([
                            rule.id.substring(0, 8),
                            rule.type,
                            rule.protocol || '-',
                            rule.port || '-',
                            rule.source || 'Any',
                            actionColor,
                            new Date(rule.createdAt).toLocaleString()
                        ]);
                    });

                    console.log(savedTable.toString());
                }
            }

            // Show active UFW rules if not filtered to saved only
            if (!options.saved) {
                console.log(chalk.green('┌─────────────────────────────────────────────────────────────────┐'));
                console.log(chalk.green('│                      ACTIVE UFW RULES                          │'));
                console.log(chalk.green('└─────────────────────────────────────────────────────────────────┘'));

                if (rules.formatted && rules.formatted.length > 0) {
                    const activeTable = new Table({
                        head: ['#', 'Action', 'From', 'To', 'Protocol', 'Port/Details'],
                        colWidths: [5, 10, 20, 20, 12, 30],
                        style: {
                            head: ['white'],
                            border: ['gray']
                        }
                    });

                    rules.formatted.forEach(rule => {
                        const actionColor = rule.action === 'ALLOW' ?
                            chalk.green(rule.action) :
                            rule.action === 'DENY' ?
                            chalk.red(rule.action) :
                            chalk.yellow(rule.action);

                        // Parse details for better display
                        let from = 'Anywhere';
                        let to = 'Anywhere';
                        let portInfo = '-';

                        const details = rule.details;
                        if (details) {
                            // Extract port information
                            const portMatch = details.match(/(\d+)(\/\w+)?/);
                            if (portMatch) {
                                portInfo = portMatch[0];
                            }

                            // Extract source/destination
                            if (details.includes('from')) {
                                const fromMatch = details.match(/from\s+(\S+)/);
                                if (fromMatch) from = fromMatch[1];
                            }
                            if (details.includes('to')) {
                                const toMatch = details.match(/to\s+(\S+)/);
                                if (toMatch) to = toMatch[1];
                            }
                        }

                        activeTable.push([
                            rule.number,
                            actionColor,
                            from,
                            to,
                            rule.protocol || 'any',
                            portInfo
                        ]);
                    });

                    console.log(activeTable.toString());
                } else if (rules.active.length > 0) {
                    // Fallback to raw output
                    console.log(chalk.gray('\nRaw UFW output:'));
                    rules.active.forEach(rule => {
                        console.log(chalk.gray('  ' + rule));
                    });
                } else {
                    console.log(chalk.gray('  No active UFW rules\n'));
                }
            }

            // Summary
            console.log(chalk.yellow('\n┌─────────────────────────────────────────────────────────────────┐'));
            console.log(chalk.yellow('│                           SUMMARY                              │'));
            console.log(chalk.yellow('└─────────────────────────────────────────────────────────────────┘'));

            const stats = await ufw.getStatistics();
            console.log(chalk.white(`  UFW Status:     ${stats.status === 'active' ? chalk.green('Active') : chalk.red('Inactive')}`));
            console.log(chalk.white(`  Saved Rules:    ${rules.saved.length}`));
            console.log(chalk.white(`  Active Rules:   ${rules.active.length}`));
            console.log(chalk.white(`  Default Policy: ${chalk.red('Deny In')} / ${chalk.green('Allow Out')}`));

        } catch (error) {
            printError('Failed to list rules:', error);
        }
    });

program
    .command('delete <ruleId>')
    .description('Delete a firewall rule by ID')
    .action(async (ruleId) => {
        try {
            await ufw.deleteRule(ruleId);
            printSuccess('Rule deleted successfully');
        } catch (error) {
            printError('Failed to delete rule:', error);
        }
    });

program
    .command('flush')
    .description('Flush all firewall rules and reset to defaults')
    .option('-f, --force', 'Force flush without confirmation')
    .action(async (options) => {
        if (!options.force) {
            console.log(chalk.yellow('\n⚠  Warning: This will remove all firewall rules!'));
            console.log(chalk.yellow('   UFW will be reset to default state.'));
            console.log(chalk.white('\n   Use --force flag to confirm\n'));
            return;
        }

        try {
            console.log(chalk.yellow('Flushing all UFW rules...'));
            await ufw.flushRules();
            printSuccess('All rules flushed successfully');
            console.log(chalk.green('✓ Base security rules restored (SSH, WebGUI)'));
        } catch (error) {
            printError('Failed to flush rules:', error);
        }
    });

program
    .command('export <file>')
    .description('Export firewall configuration')
    .action(async (file) => {
        try {
            const config = await ufw.exportRules();
            const fs = require('fs-extra');
            await fs.writeJson(file, config, { spaces: 2 });
            printSuccess(`Configuration exported to ${file}`);
        } catch (error) {
            printError('Failed to export configuration:', error);
        }
    });

program
    .command('import <file>')
    .description('Import firewall configuration')
    .action(async (file) => {
        try {
            const fs = require('fs-extra');
            const config = await fs.readJson(file);
            await ufw.importRules(config);
            printSuccess(`Configuration imported from ${file}`);
        } catch (error) {
            printError('Failed to import configuration:', error);
        }
    });

program
    .command('stats')
    .description('Show firewall statistics')
    .action(async () => {
        try {
            const stats = await ufw.getStatistics();
            const rules = await ufw.listRules();

            console.log();
            console.log(chalk.bgMagenta.black('                    UFW Firewall Statistics                      '));
            console.log();

            const table = new Table({
                style: { head: ['cyan'] }
            });

            const statusColor = stats.status === 'active' ? chalk.green('Active ✓') : chalk.red('Inactive ✗');

            table.push(
                { 'Firewall Status': statusColor },
                { 'Default Incoming Policy': chalk.red(stats.default_incoming?.toUpperCase() || 'DENY') },
                { 'Default Outgoing Policy': chalk.green(stats.default_outgoing?.toUpperCase() || 'ALLOW') },
                { 'Active UFW Rules': stats.rules_count || 0 },
                { 'Saved Configuration Rules': stats.saved_count || 0 },
                { 'Total Rules': (stats.rules_count + stats.saved_count) || 0 }
            );

            console.log(table.toString());

            if (stats.status !== 'active') {
                console.log(chalk.yellow('\n⚠ UFW is not active. Run "nfguard init" to enable it.'));
            }

        } catch (error) {
            printError('Failed to get statistics:', error);
        }
    });

program
    .command('status')
    .description('Show current UFW status')
    .action(async () => {
        try {
            const { exec } = require('child_process');
            exec('ufw status verbose', (error, stdout, stderr) => {
                if (error) {
                    printError('Failed to get UFW status:', error);
                    return;
                }

                console.log(chalk.cyan('\n╔══════════════════════════════════════════════════════════════════╗'));
                console.log(chalk.cyan('║                         UFW STATUS                              ║'));
                console.log(chalk.cyan('╚══════════════════════════════════════════════════════════════════╝\n'));

                console.log(stdout);
            });
        } catch (error) {
            printError('Failed to get status:', error);
        }
    });

program.parse(process.argv);