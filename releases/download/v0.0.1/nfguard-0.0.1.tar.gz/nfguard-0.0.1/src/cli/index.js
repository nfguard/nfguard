#!/usr/bin/env node

const { program } = require('commander');
const chalk = require('chalk');
const IPTablesManager = require('../core/iptables-manager');
const GeoBlocker = require('../core/geo-blocker');
const Table = require('cli-table3');

const iptables = new IPTablesManager();
const geoBlocker = new GeoBlocker(iptables);

function buildRuleFromOptions(options, action) {
    const direction = (options.direction || 'input').toLowerCase();
    const rawProtocol = options.protocol ? options.protocol.toLowerCase() : 'tcp';
    const source = options.source ? options.source.trim() : undefined;
    const destination = options.destination ? options.destination.trim() : undefined;
    const port = options.port ? String(options.port).trim() : undefined;

    let type;
    let protocol = rawProtocol;

    if (rawProtocol === 'icmp') {
        type = 'icmp';
        protocol = 'icmp';
    } else if (port) {
        type = 'port';
    } else if (source || destination) {
        type = source && source.includes('/') ? 'network' : 'ip';
        protocol = undefined;
    } else {
        throw new Error('Specify a port or an IP/network for this rule');
    }

    if (type === 'port' && !port) {
        throw new Error('Port is required for TCP or UDP rules');
    }

    if ((type === 'ip' || type === 'network') && !source && !destination) {
        throw new Error('Source or destination is required for IP or network rules');
    }

    return {
        type,
        direction,
        protocol,
        port,
        source,
        destination,
        action
    };
}

function printSuccess(message) {
    console.log(chalk.green(`[OK] ${message}`));
}

function printError(prefix, error) {
    const message = error && error.message ? error.message : error;
    console.error(chalk.red(`[ERR] ${prefix}`), message);
}

program
    .name('nfguard')
    .description('NFGuard - Advanced NFTables Firewall Management')
    .version('1.0.0');

program
    .command('init')
    .description('Initialize IPTables with base configuration')
    .action(async () => {
        try {
            await iptables.initializeIPTables();
            printSuccess('IPTables initialized successfully');
        } catch (error) {
            printError('Failed to initialize IPTables:', error);
        }
    });

program
    .command('allow')
    .description('Allow traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (input/output/forward)', 'input')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'accept');
            await iptables.addRule(rule);
            printSuccess('Rule added successfully');
        } catch (error) {
            printError('Failed to add rule:', error);
        }
    });

program
    .command('block')
    .description('Block traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp/icmp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (input/output/forward)', 'input')
    .action(async (options) => {
        try {
            const rule = buildRuleFromOptions(options, 'drop');
            await iptables.addRule(rule);
            printSuccess('Rule added successfully');
        } catch (error) {
            printError('Failed to add rule:', error);
        }
    });

program
    .command('geo-block <country>')
    .description('Block traffic from a country (use ISO code, e.g., CN, RU, US)')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.blockCountry(countryCode);
            printSuccess(`Blocked traffic from ${countryCode}`);
        } catch (error) {
            printError('Failed to block country:', error);
        }
    });

program
    .command('geo-unblock <country>')
    .description('Unblock traffic from a country')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.unblockCountry(countryCode);
            printSuccess(`Unblocked traffic from ${countryCode}`);
        } catch (error) {
            printError('Failed to unblock country:', error);
        }
    });

program
    .command('geo-list')
    .description('List blocked countries')
    .action(async () => {
        try {
            const countries = await geoBlocker.listBlockedCountries();

            if (countries.length === 0) {
                console.log(chalk.yellow('No countries are currently blocked'));
                return;
            }

            const table = new Table({
                head: ['Country Code', 'Country Name', 'IP Ranges', 'Blocked At'],
                colWidths: [15, 25, 15, 25]
            });

            countries.forEach(country => {
                table.push([
                    country.code,
                    country.name,
                    country.ipRanges.length,
                    country.blockedAt
                ]);
            });

            console.log(table.toString());
        } catch (error) {
            printError('Failed to list blocked countries:', error);
        }
    });

program
    .command('geo-update')
    .description('Update GeoIP database')
    .action(async () => {
        try {
            await geoBlocker.updateGeoDatabase();
            printSuccess('GeoIP database update triggered');
        } catch (error) {
            printError('Failed to update GeoIP database:', error);
        }
    });

program
    .command('check-ip <ip>')
    .description('Check if an IP is blocked and get country information')
    .action(async (ip) => {
        try {
            const result = await geoBlocker.checkIP(ip);
            const table = new Table();
            table.push(
                { 'IP Address': result.ip },
                { 'Country': `${result.countryName} (${result.country})` },
                { 'Blocked': result.blocked ? 'Yes' : 'No' }
            );

            console.log(table.toString());
        } catch (error) {
            printError('Failed to check IP:', error);
        }
    });

program
    .command('list')
    .description('List all firewall rules')
    .action(async () => {
        try {
            const rules = await iptables.listRules();

            console.log(chalk.cyan('\n=== Saved Rules ==='));
            if (rules.saved.length === 0) {
                console.log(chalk.yellow('No saved rules'));
            } else {
                const table = new Table({
                    head: ['ID', 'Type', 'Direction', 'Port', 'Source', 'Destination', 'Action'],
                    colWidths: [15, 10, 12, 10, 20, 20, 10]
                });

                rules.saved.forEach(rule => {
                    table.push([
                        rule.id.substring(0, 8),
                        rule.type,
                        rule.direction,
                        rule.port || '-',
                        rule.source || '-',
                        rule.destination || '-',
                        rule.action
                    ]);
                });

                console.log(table.toString());
            }

            console.log(chalk.cyan('\n=== Active NFTables Rules ==='));
            rules.active.forEach(rule => {
                console.log(chalk.gray(rule));
            });
        } catch (error) {
            printError('Failed to list rules:', error);
        }
    });

program
    .command('delete <ruleId>')
    .description('Delete a firewall rule by ID')
    .action(async (ruleId) => {
        try {
            await iptables.deleteRule(ruleId);
            printSuccess('Rule deleted successfully');
        } catch (error) {
            printError('Failed to delete rule:', error);
        }
    });

program
    .command('flush')
    .description('Flush all firewall rules and reset to defaults')
    .option('-f, --force', 'Force flush without confirmation')
    .action(async (options) => {
        if (!options.force) {
            console.log(chalk.yellow('Warning: This will remove all firewall rules!'));
            console.log('Use --force flag to confirm');
            return;
        }

        try {
            await iptables.flushRules();
            printSuccess('All rules flushed successfully');
        } catch (error) {
            printError('Failed to flush rules:', error);
        }
    });

program
    .command('export <file>')
    .description('Export firewall configuration')
    .action(async (file) => {
        try {
            const config = await iptables.exportRules();
            const fs = require('fs-extra');
            await fs.writeFile(file, config);
            printSuccess(`Configuration exported to ${file}`);
        } catch (error) {
            printError('Failed to export configuration:', error);
        }
    });

program
    .command('import <file>')
    .description('Import firewall configuration')
    .action(async (file) => {
        try {
            const fs = require('fs-extra');
            const config = await fs.readFile(file, 'utf8');
            await iptables.importRules(config);
            printSuccess(`Configuration imported from ${file}`);
        } catch (error) {
            printError('Failed to import configuration:', error);
        }
    });

program
    .command('stats')
    .description('Show firewall statistics')
    .action(async () => {
        try {
            const stats = await iptables.getStatistics();

            const table = new Table();
            table.push(
                { 'Total Packets': stats.packets || 0 },
                { 'Total Bytes': stats.bytes || 0 },
                { 'Active Rules': stats.rules || 0 }
            );

            console.log(table.toString());
        } catch (error) {
            printError('Failed to get statistics:', error);
        }
    });

program.parse(process.argv);