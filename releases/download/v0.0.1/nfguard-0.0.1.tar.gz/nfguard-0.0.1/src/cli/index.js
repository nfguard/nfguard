#!/usr/bin/env node

const { program } = require('commander');
const chalk = require('chalk');
const NFTablesManager = require('../core/nftables-manager');
const GeoBlocker = require('../core/geo-blocker');
const Table = require('cli-table3');

const nftables = new NFTablesManager();
const geoBlocker = new GeoBlocker(nftables);

program
    .name('nfguard')
    .description('NFGuard - Advanced NFTables Firewall Management')
    .version('1.0.0');

program
    .command('init')
    .description('Initialize NFTables with base configuration')
    .action(async () => {
        try {
            await nftables.initializeNFTables();
            console.log(chalk.green('✓ NFTables initialized successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Failed to initialize NFTables:'), error.message);
        }
    });

program
    .command('allow')
    .description('Allow traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (input/output)', 'input')
    .action(async (options) => {
        try {
            const rule = {
                type: options.port ? 'port' : 'ip',
                direction: options.direction,
                protocol: options.protocol,
                port: options.port,
                source: options.source,
                destination: options.destination,
                action: 'accept'
            };

            await nftables.addRule(rule);
            console.log(chalk.green('✓ Rule added successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Failed to add rule:'), error.message);
        }
    });

program
    .command('block')
    .description('Block traffic')
    .option('-p, --port <port>', 'Port number')
    .option('-P, --protocol <protocol>', 'Protocol (tcp/udp)', 'tcp')
    .option('-s, --source <ip>', 'Source IP address or network')
    .option('-d, --destination <ip>', 'Destination IP address or network')
    .option('-D, --direction <direction>', 'Direction (input/output)', 'input')
    .action(async (options) => {
        try {
            const rule = {
                type: options.port ? 'port' : 'ip',
                direction: options.direction,
                protocol: options.protocol,
                port: options.port,
                source: options.source,
                destination: options.destination,
                action: 'drop'
            };

            await nftables.addRule(rule);
            console.log(chalk.green('✓ Rule added successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Failed to add rule:'), error.message);
        }
    });

program
    .command('geo-block <country>')
    .description('Block traffic from a country (use ISO code, e.g., CN, RU, US)')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.blockCountry(countryCode);
            console.log(chalk.green(`✓ Blocked traffic from ${countryCode}`));
        } catch (error) {
            console.error(chalk.red('✗ Failed to block country:'), error.message);
        }
    });

program
    .command('geo-unblock <country>')
    .description('Unblock traffic from a country')
    .action(async (country) => {
        try {
            const countryCode = country.toUpperCase();
            await geoBlocker.unblockCountry(countryCode);
            console.log(chalk.green(`✓ Unblocked traffic from ${countryCode}`));
        } catch (error) {
            console.error(chalk.red('✗ Failed to unblock country:'), error.message);
        }
    });

program
    .command('geo-list')
    .description('List blocked countries')
    .action(async () => {
        try {
            const countries = await geoBlocker.listBlockedCountries();

            if (countries.length === 0) {
                console.log(chalk.yellow('No countries are currently blocked'));
                return;
            }

            const table = new Table({
                head: ['Country Code', 'Country Name', 'IP Ranges', 'Blocked At'],
                colWidths: [15, 25, 15, 25]
            });

            countries.forEach(country => {
                table.push([
                    country.code,
                    country.name,
                    country.ipRanges.length,
                    new Date(country.blockedAt).toLocaleString()
                ]);
            });

            console.log(table.toString());
        } catch (error) {
            console.error(chalk.red('✗ Failed to list blocked countries:'), error.message);
        }
    });

program
    .command('check-ip <ip>')
    .description('Check IP geolocation and block status')
    .action(async (ip) => {
        try {
            const info = await geoBlocker.checkIP(ip);

            const table = new Table();
            table.push(
                { 'IP Address': info.ip },
                { 'Country': `${info.country} ${info.blocked ? chalk.red('(BLOCKED)') : chalk.green('(ALLOWED)')}` },
                { 'City': info.city || 'Unknown' },
                { 'Region': info.region || 'Unknown' },
                { 'Timezone': info.timezone || 'Unknown' }
            );

            console.log(table.toString());
        } catch (error) {
            console.error(chalk.red('✗ Failed to check IP:'), error.message);
        }
    });

program
    .command('list')
    .description('List all firewall rules')
    .action(async () => {
        try {
            const rules = await nftables.listRules();

            console.log(chalk.cyan('\n=== Saved Rules ==='));
            if (rules.saved.length === 0) {
                console.log(chalk.yellow('No saved rules'));
            } else {
                const table = new Table({
                    head: ['ID', 'Type', 'Direction', 'Port', 'Source', 'Destination', 'Action'],
                    colWidths: [15, 10, 12, 10, 20, 20, 10]
                });

                rules.saved.forEach(rule => {
                    table.push([
                        rule.id.substring(0, 8),
                        rule.type,
                        rule.direction,
                        rule.port || '-',
                        rule.source || '-',
                        rule.destination || '-',
                        rule.action
                    ]);
                });

                console.log(table.toString());
            }

            console.log(chalk.cyan('\n=== Active NFTables Rules ==='));
            rules.active.forEach(rule => {
                console.log(chalk.gray(rule));
            });
        } catch (error) {
            console.error(chalk.red('✗ Failed to list rules:'), error.message);
        }
    });

program
    .command('delete <ruleId>')
    .description('Delete a firewall rule by ID')
    .action(async (ruleId) => {
        try {
            await nftables.deleteRule(ruleId);
            console.log(chalk.green('✓ Rule deleted successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Failed to delete rule:'), error.message);
        }
    });

program
    .command('flush')
    .description('Flush all firewall rules and reset to defaults')
    .option('-f, --force', 'Force flush without confirmation')
    .action(async (options) => {
        if (!options.force) {
            console.log(chalk.yellow('Warning: This will remove all firewall rules!'));
            console.log('Use --force flag to confirm');
            return;
        }

        try {
            await nftables.flushRules();
            console.log(chalk.green('✓ All rules flushed successfully'));
        } catch (error) {
            console.error(chalk.red('✗ Failed to flush rules:'), error.message);
        }
    });

program
    .command('export <file>')
    .description('Export firewall configuration')
    .action(async (file) => {
        try {
            const config = await nftables.exportRules();
            const fs = require('fs-extra');
            await fs.writeFile(file, config);
            console.log(chalk.green(`✓ Configuration exported to ${file}`));
        } catch (error) {
            console.error(chalk.red('✗ Failed to export configuration:'), error.message);
        }
    });

program
    .command('import <file>')
    .description('Import firewall configuration')
    .action(async (file) => {
        try {
            const fs = require('fs-extra');
            const config = await fs.readFile(file, 'utf8');
            await nftables.importRules(config);
            console.log(chalk.green(`✓ Configuration imported from ${file}`));
        } catch (error) {
            console.error(chalk.red('✗ Failed to import configuration:'), error.message);
        }
    });

program
    .command('stats')
    .description('Show firewall statistics')
    .action(async () => {
        try {
            const stats = await nftables.getStatistics();

            const table = new Table();
            table.push(
                { 'Total Packets': stats.packets || 0 },
                { 'Total Bytes': stats.bytes || 0 },
                { 'Active Rules': stats.rules || 0 }
            );

            console.log(table.toString());
        } catch (error) {
            console.error(chalk.red('✗ Failed to get statistics:'), error.message);
        }
    });

program.parse(process.argv);