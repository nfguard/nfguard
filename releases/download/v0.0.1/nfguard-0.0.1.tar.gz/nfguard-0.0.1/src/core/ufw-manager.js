const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class UFWManager {
    constructor() {
        this.rulesPath = process.env.NFGUARD_RULES_PATH || '/etc/nfguard/rules.json';
        this.ensureDirectories();
    }

    ensureDirectories() {
        const rulesDir = path.dirname(this.rulesPath);
        fs.ensureDirSync(rulesDir);
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command, silent = false) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error && !silent) {
                    logger.error(`UFW command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    if (!silent) {
                        logger.info(`UFW command executed: ${command}`, { stdout: stdout.trim() });
                    }
                    resolve({ stdout, stderr, error });
                }
            });
        });
    }

    async initializeUFW() {
        try {
            // Enable UFW non-interactively
            await this.executeCommand('echo "y" | ufw --force enable');

            // Set default policies
            await this.executeCommand('ufw default deny incoming');
            await this.executeCommand('ufw default allow outgoing');
            await this.executeCommand('ufw default deny forward');

            // Allow essential services
            await this.executeCommand('ufw allow 22/tcp comment "SSH Access"');
            await this.executeCommand('ufw allow 8443/tcp comment "NFGuard WebGUI"');

            // Enable logging
            await this.executeCommand('ufw logging on');

            logger.info('UFW initialized successfully');
            return true;
        } catch (error) {
            logger.error('Failed to initialize UFW', error);
            throw error;
        }
    }

    normalizeRuleInput(rule) {
        if (!rule || typeof rule !== 'object') {
            throw new Error('Invalid rule payload');
        }

        const normalized = {
            type: (rule.type || '').toLowerCase(),
            direction: (rule.direction || 'in').toLowerCase(),
            protocol: rule.protocol ? String(rule.protocol).toLowerCase() : undefined,
            port: rule.port !== undefined && rule.port !== null && rule.port !== '' ? String(rule.port).trim() : undefined,
            source: rule.source ? String(rule.source).trim() : undefined,
            destination: rule.destination ? String(rule.destination).trim() : undefined,
            action: (rule.action || '').toLowerCase(),
            comment: rule.comment || ''
        };

        // Convert direction to UFW format
        if (normalized.direction === 'input') normalized.direction = 'in';
        if (normalized.direction === 'output') normalized.direction = 'out';

        return normalized;
    }

    buildUFWCommand(rule, action = 'allow') {
        const parts = ['ufw'];

        // Insert or add
        parts.push('insert', '1');

        // Action (allow/deny/reject)
        if (rule.action === 'drop' || rule.action === 'deny') {
            parts.push('deny');
        } else if (rule.action === 'reject') {
            parts.push('reject');
        } else {
            parts.push('allow');
        }

        // Direction
        parts.push(rule.direction || 'in');

        // From source
        if (rule.source) {
            parts.push('from', rule.source);
        }

        // To destination
        if (rule.destination) {
            parts.push('to', rule.destination);
        } else if (rule.direction === 'in') {
            parts.push('to', 'any');
        }

        // Port and protocol
        if (rule.port) {
            parts.push('port', rule.port);
            if (rule.protocol && rule.protocol !== 'any') {
                parts.push('proto', rule.protocol);
            }
        } else if (rule.protocol === 'icmp') {
            // For ICMP, we need a different approach
            return this.buildICMPCommand(rule);
        }

        // Add comment
        if (rule.comment) {
            parts.push('comment', `"${rule.comment}"`);
        } else {
            const comment = `NFGuard Rule - ${rule.type} ${rule.protocol || ''} ${rule.port || ''}`.trim();
            parts.push('comment', `"${comment}"`);
        }

        return parts.join(' ');
    }

    buildICMPCommand(rule) {
        const parts = ['ufw'];

        // For ICMP blocking
        if (rule.action === 'drop' || rule.action === 'deny') {
            // UFW doesn't have direct ICMP blocking, we need to use raw iptables via UFW
            // So we'll add a rule to /etc/ufw/before.rules
            return `echo "-A ufw-before-input -p icmp --icmp-type echo-request -j DROP" >> /etc/ufw/before.rules && ufw reload`;
        } else {
            // Allow ICMP
            parts.push('allow', 'in');
            if (rule.source) {
                parts.push('from', rule.source);
            }
            parts.push('to', 'any', 'proto', 'icmp');
            parts.push('comment', '"ICMP/Ping"');
        }

        return parts.join(' ');
    }

    async addRule(rule, user = 'system') {
        const normalizedRule = this.normalizeRuleInput(rule);

        // Special handling for ICMP
        if (normalizedRule.protocol === 'icmp' || normalizedRule.type === 'icmp') {
            return await this.addICMPRule(normalizedRule, user);
        }

        const command = this.buildUFWCommand(normalizedRule);

        logger.audit('ADD_RULE', user, {
            rule: normalizedRule,
            command: command,
            timestamp: new Date().toISOString()
        });

        try {
            await this.executeCommand(command);
            const storedRule = await this.saveRule(normalizedRule);

            // Reload UFW to apply changes
            await this.executeCommand('ufw reload');

            logger.info(`Rule added successfully via UFW: ${storedRule.type} ${storedRule.protocol || ''} ${storedRule.port || ''}`);
            return storedRule;
        } catch (error) {
            logger.error(`Failed to add rule: ${command}`, error);
            throw new Error(`Failed to add firewall rule: ${error.message}`);
        }
    }

    async addICMPRule(rule, user = 'system') {
        try {
            if (rule.action === 'drop' || rule.action === 'deny') {
                // Block ICMP using UFW's before.rules
                const beforeRulesPath = '/etc/ufw/before.rules';
                const beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                // Check if ICMP block rule already exists
                if (!beforeRules.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP')) {
                    // Find the right place to insert (before COMMIT)
                    const lines = beforeRules.split('\n');
                    const commitIndex = lines.findIndex(line => line.trim() === 'COMMIT');

                    if (commitIndex > 0) {
                        // Insert ICMP block rule before COMMIT
                        lines.splice(commitIndex, 0,
                            '# Block ICMP echo-request (ping) - Added by NFGuard',
                            '-A ufw-before-input -p icmp --icmp-type echo-request -j DROP'
                        );

                        await fs.writeFile(beforeRulesPath, lines.join('\n'));
                        await this.executeCommand('ufw reload');

                        const storedRule = await this.saveRule({
                            ...rule,
                            type: 'icmp',
                            protocol: 'icmp',
                            comment: 'Block ICMP/Ping'
                        });

                        logger.info('ICMP blocking rule added successfully');
                        return storedRule;
                    }
                }
            } else {
                // Allow ICMP
                await this.executeCommand('ufw allow in proto icmp comment "Allow ICMP/Ping"');

                const storedRule = await this.saveRule({
                    ...rule,
                    type: 'icmp',
                    protocol: 'icmp',
                    comment: 'Allow ICMP/Ping'
                });

                return storedRule;
            }
        } catch (error) {
            logger.error('Failed to add ICMP rule', error);
            throw new Error(`Failed to add ICMP rule: ${error.message}`);
        }
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        try {
            // Get UFW rule number
            const { stdout } = await this.executeCommand('ufw status numbered');
            const lines = stdout.split('\n');

            // Find the rule number to delete
            let ruleNumber = null;

            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (rule.port && line.includes(rule.port)) {
                    const match = line.match(/\[(\d+)\]/);
                    if (match) {
                        ruleNumber = match[1];
                        break;
                    }
                } else if (rule.source && line.includes(rule.source)) {
                    const match = line.match(/\[(\d+)\]/);
                    if (match) {
                        ruleNumber = match[1];
                        break;
                    }
                }
            }

            if (ruleNumber) {
                await this.executeCommand(`echo "y" | ufw delete ${ruleNumber}`);
            }

            // Special handling for ICMP rules
            if (rule.type === 'icmp' && (rule.action === 'drop' || rule.action === 'deny')) {
                const beforeRulesPath = '/etc/ufw/before.rules';
                let beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                // Remove ICMP block rule
                const lines = beforeRules.split('\n');
                const filtered = lines.filter(line =>
                    !line.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP') &&
                    !line.includes('# Block ICMP echo-request (ping) - Added by NFGuard')
                );

                await fs.writeFile(beforeRulesPath, filtered.join('\n'));
                await this.executeCommand('ufw reload');
            }
        } catch (error) {
            logger.error(`Failed to delete rule from UFW`, error);
        }

        // Remove from saved rules
        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules, { spaces: 2 });

        return true;
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];
        const formattedRules = [];

        try {
            // Get UFW status in different formats
            const { stdout: statusVerbose } = await this.executeCommand('ufw status verbose', true);
            const { stdout: statusNumbered } = await this.executeCommand('ufw status numbered', true);

            // Parse UFW output for active rules
            const lines = statusNumbered.split('\n');
            let inRules = false;

            for (const line of lines) {
                if (line.includes('---')) {
                    inRules = true;
                    continue;
                }

                if (inRules && line.trim() && line.includes('[')) {
                    activeRules.push(line.trim());

                    // Parse the rule for formatted display
                    const match = line.match(/\[(\d+)\]\s+(\S+)\s+(\S+)\s+(\S+)\s*(.*)/);
                    if (match) {
                        const [, num, action, direction, proto, rest] = match;
                        formattedRules.push({
                            number: num,
                            action: action,
                            direction: direction,
                            protocol: proto,
                            details: rest || '',
                            raw: line.trim()
                        });
                    }
                }
            }

            // Also check for ICMP rules in before.rules
            try {
                const beforeRules = await fs.readFile('/etc/ufw/before.rules', 'utf8');
                if (beforeRules.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP')) {
                    activeRules.push('ICMP echo-request (ping) - BLOCKED via before.rules');
                    formattedRules.push({
                        number: 'N/A',
                        action: 'DENY',
                        direction: 'IN',
                        protocol: 'icmp',
                        details: 'echo-request (ping) - Blocked',
                        raw: 'ICMP Ping Blocked'
                    });
                }
            } catch (e) {
                // Ignore errors reading before.rules
            }

        } catch (error) {
            logger.error('Failed to list UFW rules', error);
        }

        return {
            saved: rules,
            active: activeRules,
            formatted: formattedRules
        };
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        const storedRule = {
            ...rule,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        rules.push(storedRule);
        await fs.writeJson(this.rulesPath, rules, { spaces: 2 });
        return storedRule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        // Export UFW rules
        const { stdout } = await this.executeCommand('ufw status verbose');
        const savedRules = await this.loadRules();

        return {
            ufw_status: stdout,
            saved_rules: savedRules,
            exported_at: new Date().toISOString()
        };
    }

    async importRules(config) {
        if (typeof config === 'string') {
            config = JSON.parse(config);
        }

        if (config.saved_rules) {
            for (const rule of config.saved_rules) {
                try {
                    await this.addRule(rule);
                } catch (error) {
                    logger.error(`Failed to import rule: ${JSON.stringify(rule)}`, error);
                }
            }
        }

        return true;
    }

    async flushRules() {
        try {
            // Reset UFW to default state
            await this.executeCommand('echo "y" | ufw --force reset');

            // Re-initialize with base rules
            await this.initializeUFW();

            // Clear saved rules
            await fs.writeJson(this.rulesPath, [], { spaces: 2 });

            // Remove ICMP blocks from before.rules
            try {
                const beforeRulesPath = '/etc/ufw/before.rules';
                let beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                const lines = beforeRules.split('\n');
                const filtered = lines.filter(line =>
                    !line.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP') &&
                    !line.includes('# Block ICMP echo-request (ping) - Added by NFGuard')
                );

                await fs.writeFile(beforeRulesPath, filtered.join('\n'));
            } catch (e) {
                // Ignore errors
            }

            await this.executeCommand('ufw reload');

            logger.info('All UFW rules flushed, base rules restored');
            return true;
        } catch (error) {
            logger.error('Failed to flush UFW rules', error);
            throw error;
        }
    }

    async getStatistics() {
        try {
            const { stdout } = await this.executeCommand('ufw status verbose');
            const rules = await this.listRules();

            // Parse UFW status for statistics
            const stats = {
                status: 'inactive',
                default_incoming: 'unknown',
                default_outgoing: 'unknown',
                rules_count: rules.active.length,
                saved_count: rules.saved.length
            };

            if (stdout.includes('Status: active')) {
                stats.status = 'active';
            }

            const incomingMatch = stdout.match(/Default: deny \(incoming\)/);
            if (incomingMatch) stats.default_incoming = 'deny';

            const outgoingMatch = stdout.match(/allow \(outgoing\)/);
            if (outgoingMatch) stats.default_outgoing = 'allow';

            return stats;
        } catch (error) {
            logger.error('Failed to get UFW statistics', error);
            return {
                status: 'error',
                rules_count: 0,
                saved_count: 0
            };
        }
    }

    async checkUFWInstalled() {
        try {
            const { error } = await this.executeCommand('which ufw', true);
            return !error;
        } catch {
            return false;
        }
    }

    async installUFW() {
        try {
            // Detect package manager and install UFW
            const { error: aptError } = await this.executeCommand('which apt-get', true);
            const { error: yumError } = await this.executeCommand('which yum', true);
            const { error: dnfError } = await this.executeCommand('which dnf', true);
            const { error: pacmanError } = await this.executeCommand('which pacman', true);

            if (!aptError) {
                await this.executeCommand('apt-get update && apt-get install -y ufw');
            } else if (!dnfError) {
                await this.executeCommand('dnf install -y ufw');
            } else if (!yumError) {
                await this.executeCommand('yum install -y ufw');
            } else if (!pacmanError) {
                await this.executeCommand('pacman -S --noconfirm ufw');
            } else {
                throw new Error('No supported package manager found');
            }

            logger.info('UFW installed successfully');
            return true;
        } catch (error) {
            logger.error('Failed to install UFW', error);
            throw error;
        }
    }
}

module.exports = UFWManager;