const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class UFWManager {
    constructor() {
        this.rulesPath = process.env.NFGUARD_RULES_PATH || '/etc/nfguard/rules.json';
        this.ensureDirectories();
    }

    ensureDirectories() {
        const rulesDir = path.dirname(this.rulesPath);
        fs.ensureDirSync(rulesDir);
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command, silent = false) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error && !silent) {
                    logger.error(`UFW command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    if (!silent) {
                        logger.info(`UFW command executed: ${command}`, { stdout: stdout.trim() });
                    }
                    resolve({ stdout, stderr, error });
                }
            });
        });
    }

    async getSSHPort() {
        try {
            // Try to read SSH port from sshd_config
            const sshConfigPaths = ['/etc/ssh/sshd_config', '/etc/sshd_config'];

            for (const configPath of sshConfigPaths) {
                try {
                    const config = await fs.readFile(configPath, 'utf8');
                    const lines = config.split('\n');

                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith('Port ') && !trimmed.startsWith('#')) {
                            const port = trimmed.split(' ')[1];
                            if (port && !isNaN(port)) {
                                logger.info(`Detected SSH port from ${configPath}: ${port}`);
                                return parseInt(port);
                            }
                        }
                    }
                } catch (e) {
                    // Continue to next path
                }
            }

            // Default SSH port if not found
            logger.info('SSH port not found in config, using default: 22');
            return 22;
        } catch (error) {
            logger.warn('Failed to detect SSH port, using default: 22');
            return 22;
        }
    }

    async getWebGUIPort() {
        // Get from environment or default
        return process.env.PORT || 8443;
    }

    async initializeUFW() {
        try {
            // Enable UFW non-interactively
            await this.executeCommand('echo "y" | ufw --force enable');

            // Set default policies
            await this.executeCommand('ufw default deny incoming');
            await this.executeCommand('ufw default allow outgoing');
            await this.executeCommand('ufw default deny forward');

            // Auto-detect and allow essential services
            const sshPort = await this.getSSHPort();
            const webguiPort = await this.getWebGUIPort();

            await this.executeCommand(`ufw allow ${sshPort}/tcp comment "SSH Access (Auto-detected)"`);
            await this.executeCommand(`ufw allow ${webguiPort}/tcp comment "NFGuard WebGUI (Auto-allowed)"`);

            // Enable logging
            await this.executeCommand('ufw logging on');

            logger.info(`UFW initialized successfully - SSH: ${sshPort}, WebGUI: ${webguiPort}`);
            return true;
        } catch (error) {
            logger.error('Failed to initialize UFW', error);
            throw error;
        }
    }

    normalizeRuleInput(rule) {
        if (!rule || typeof rule !== 'object') {
            throw new Error('Invalid rule payload');
        }

        const normalized = {
            type: (rule.type || '').toLowerCase(),
            direction: (rule.direction || 'in').toLowerCase(),
            protocol: rule.protocol ? String(rule.protocol).toLowerCase() : undefined,
            port: rule.port !== undefined && rule.port !== null && rule.port !== '' ? String(rule.port).trim() : undefined,
            source: rule.source ? String(rule.source).trim() : undefined,
            destination: rule.destination ? String(rule.destination).trim() : undefined,
            action: (rule.action || '').toLowerCase(),
            comment: rule.comment || ''
        };

        // Convert direction to UFW format
        if (normalized.direction === 'input') normalized.direction = 'in';
        if (normalized.direction === 'output') normalized.direction = 'out';

        return normalized;
    }

    buildUFWCommand(rule, action = 'allow') {
        const parts = ['ufw'];

        // For DENY rules, insert at position 1 for highest priority
        // For ALLOW rules, just add normally
        if (rule.action === 'drop' || rule.action === 'deny' || rule.action === 'reject') {
            parts.push('insert', '1');
        }

        // Action (allow/deny/reject)
        if (rule.action === 'drop' || rule.action === 'deny') {
            parts.push('deny');
        } else if (rule.action === 'reject') {
            parts.push('reject');
        } else {
            parts.push('allow');
        }

        // Direction
        parts.push(rule.direction || 'in');

        // From source
        if (rule.source) {
            parts.push('from', rule.source);
        }

        // To destination
        if (rule.destination) {
            parts.push('to', rule.destination);
        } else if (rule.direction === 'in') {
            parts.push('to', 'any');
        }

        // Port and protocol
        if (rule.port) {
            parts.push('port', rule.port);
            if (rule.protocol && rule.protocol !== 'any') {
                parts.push('proto', rule.protocol);
            }
        } else if (rule.protocol === 'icmp') {
            // For ICMP, we need a different approach
            return this.buildICMPCommand(rule);
        }

        // Add comment
        if (rule.comment) {
            parts.push('comment', `"${rule.comment}"`);
        } else {
            const comment = `NFGuard Rule - ${rule.type} ${rule.protocol || ''} ${rule.port || ''}`.trim();
            parts.push('comment', `"${comment}"`);
        }

        return parts.join(' ');
    }

    buildICMPCommand(rule) {
        const parts = ['ufw'];

        // For ICMP blocking
        if (rule.action === 'drop' || rule.action === 'deny') {
            // UFW doesn't have direct ICMP blocking, we need to use raw iptables via UFW
            // So we'll add a rule to /etc/ufw/before.rules
            return `echo "-A ufw-before-input -p icmp --icmp-type echo-request -j DROP" >> /etc/ufw/before.rules && ufw reload`;
        } else {
            // Allow ICMP
            parts.push('allow', 'in');
            if (rule.source) {
                parts.push('from', rule.source);
            }
            parts.push('to', 'any', 'proto', 'icmp');
            parts.push('comment', '"ICMP/Ping"');
        }

        return parts.join(' ');
    }

    async addRule(rule, user = 'system') {
        const normalizedRule = this.normalizeRuleInput(rule);

        // Check for conflicting rules and remove them
        await this.resolveConflicts(normalizedRule, user);

        // Special handling for ICMP
        if (normalizedRule.protocol === 'icmp' || normalizedRule.type === 'icmp') {
            return await this.addICMPRule(normalizedRule, user);
        }

        const command = this.buildUFWCommand(normalizedRule);

        logger.audit('ADD_RULE', user, {
            rule: normalizedRule,
            command: command,
            timestamp: new Date().toISOString()
        });

        try {
            await this.executeCommand(command);
            const storedRule = await this.saveRule(normalizedRule);

            // Reload UFW to apply changes
            await this.executeCommand('ufw reload');

            logger.info(`Rule added successfully via UFW: ${storedRule.type} ${storedRule.protocol || ''} ${storedRule.port || ''}`);
            return storedRule;
        } catch (error) {
            logger.error(`Failed to add rule: ${command}`, error);
            throw new Error(`Failed to add firewall rule: ${error.message}`);
        }
    }

    async addICMPRule(rule, user = 'system') {
        try {
            if (rule.action === 'drop' || rule.action === 'deny') {
                // Block ICMP using UFW's before.rules
                const beforeRulesPath = '/etc/ufw/before.rules';
                const beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                // Check if ICMP block rule already exists
                if (!beforeRules.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP')) {
                    // Find the right place to insert (before COMMIT)
                    const lines = beforeRules.split('\n');
                    const commitIndex = lines.findIndex(line => line.trim() === 'COMMIT');

                    if (commitIndex > 0) {
                        // Insert ICMP block rule before COMMIT
                        lines.splice(commitIndex, 0,
                            '# Block ICMP echo-request (ping) - Added by NFGuard',
                            '-A ufw-before-input -p icmp --icmp-type echo-request -j DROP'
                        );

                        await fs.writeFile(beforeRulesPath, lines.join('\n'));
                        await this.executeCommand('ufw reload');

                        const storedRule = await this.saveRule({
                            ...rule,
                            type: 'icmp',
                            protocol: 'icmp',
                            comment: 'Block ICMP/Ping'
                        });

                        logger.info('ICMP blocking rule added successfully');
                        return storedRule;
                    }
                }
            } else {
                // Allow ICMP
                await this.executeCommand('ufw allow in proto icmp comment "Allow ICMP/Ping"');

                const storedRule = await this.saveRule({
                    ...rule,
                    type: 'icmp',
                    protocol: 'icmp',
                    comment: 'Allow ICMP/Ping'
                });

                return storedRule;
            }
        } catch (error) {
            logger.error('Failed to add ICMP rule', error);
            throw new Error(`Failed to add ICMP rule: ${error.message}`);
        }
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        try {
            // Get UFW rule number
            const { stdout } = await this.executeCommand('ufw status numbered');
            const lines = stdout.split('\n');

            // Find the rule number to delete
            let ruleNumber = null;

            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (rule.port && line.includes(rule.port)) {
                    const match = line.match(/\[(\d+)\]/);
                    if (match) {
                        ruleNumber = match[1];
                        break;
                    }
                } else if (rule.source && line.includes(rule.source)) {
                    const match = line.match(/\[(\d+)\]/);
                    if (match) {
                        ruleNumber = match[1];
                        break;
                    }
                }
            }

            if (ruleNumber) {
                await this.executeCommand(`echo "y" | ufw delete ${ruleNumber}`);
            }

            // Special handling for ICMP rules
            if (rule.type === 'icmp' && (rule.action === 'drop' || rule.action === 'deny')) {
                const beforeRulesPath = '/etc/ufw/before.rules';
                let beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                // Remove ICMP block rule
                const lines = beforeRules.split('\n');
                const filtered = lines.filter(line =>
                    !line.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP') &&
                    !line.includes('# Block ICMP echo-request (ping) - Added by NFGuard')
                );

                await fs.writeFile(beforeRulesPath, filtered.join('\n'));
                await this.executeCommand('ufw reload');
            }
        } catch (error) {
            logger.error(`Failed to delete rule from UFW`, error);
        }

        // Remove from saved rules
        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules, { spaces: 2 });

        return true;
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];
        const formattedRules = [];

        try {
            // Get UFW status in different formats
            const { stdout: statusVerbose } = await this.executeCommand('ufw status verbose', true);
            const { stdout: statusNumbered } = await this.executeCommand('ufw status numbered', true);

            // Parse UFW output for active rules
            const lines = statusNumbered.split('\n');
            let inRules = false;

            for (const line of lines) {
                if (line.includes('---')) {
                    inRules = true;
                    continue;
                }

                if (inRules && line.trim() && line.includes('[')) {
                    activeRules.push(line.trim());

                    // Parse the rule for formatted display
                    const match = line.match(/\[(\d+)\]\s+(\S+)\s+(\S+)\s+(\S+)\s*(.*)/);
                    if (match) {
                        const [, num, action, direction, proto, rest] = match;
                        formattedRules.push({
                            number: num,
                            action: action,
                            direction: direction,
                            protocol: proto,
                            details: rest || '',
                            raw: line.trim()
                        });
                    }
                }
            }

            // Also check for ICMP rules in before.rules
            try {
                const beforeRules = await fs.readFile('/etc/ufw/before.rules', 'utf8');
                if (beforeRules.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP')) {
                    activeRules.push('ICMP echo-request (ping) - BLOCKED via before.rules');
                    formattedRules.push({
                        number: 'N/A',
                        action: 'DENY',
                        direction: 'IN',
                        protocol: 'icmp',
                        details: 'echo-request (ping) - Blocked',
                        raw: 'ICMP Ping Blocked'
                    });
                }
            } catch (e) {
                // Ignore errors reading before.rules
            }

        } catch (error) {
            logger.error('Failed to list UFW rules', error);
        }

        return {
            saved: rules,
            active: activeRules,
            formatted: formattedRules
        };
    }

    async getSavedRules() {
        try {
            return await this.loadRules();
        } catch (error) {
            logger.error('Failed to get saved rules', error);
            return [];
        }
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        const storedRule = {
            ...rule,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        rules.push(storedRule);
        await fs.writeJson(this.rulesPath, rules, { spaces: 2 });
        return storedRule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        // Export UFW rules
        const { stdout } = await this.executeCommand('ufw status verbose');
        const savedRules = await this.loadRules();

        return {
            ufw_status: stdout,
            saved_rules: savedRules,
            exported_at: new Date().toISOString()
        };
    }

    async importRules(config) {
        if (typeof config === 'string') {
            config = JSON.parse(config);
        }

        if (config.saved_rules) {
            for (const rule of config.saved_rules) {
                try {
                    await this.addRule(rule);
                } catch (error) {
                    logger.error(`Failed to import rule: ${JSON.stringify(rule)}`, error);
                }
            }
        }

        return true;
    }

    async flushRules() {
        try {
            // Reset UFW to default state
            await this.executeCommand('echo "y" | ufw --force reset');

            // Re-initialize with base rules
            await this.initializeUFW();

            // Clear saved rules
            await fs.writeJson(this.rulesPath, [], { spaces: 2 });

            // Remove ICMP blocks from before.rules
            try {
                const beforeRulesPath = '/etc/ufw/before.rules';
                let beforeRules = await fs.readFile(beforeRulesPath, 'utf8');

                const lines = beforeRules.split('\n');
                const filtered = lines.filter(line =>
                    !line.includes('-A ufw-before-input -p icmp --icmp-type echo-request -j DROP') &&
                    !line.includes('# Block ICMP echo-request (ping) - Added by NFGuard')
                );

                await fs.writeFile(beforeRulesPath, filtered.join('\n'));
            } catch (e) {
                // Ignore errors
            }

            await this.executeCommand('ufw reload');

            logger.info('All UFW rules flushed, base rules restored');
            return true;
        } catch (error) {
            logger.error('Failed to flush UFW rules', error);
            throw error;
        }
    }

    async getStatistics() {
        try {
            const { stdout } = await this.executeCommand('ufw status verbose');
            const rules = await this.listRules();

            // Parse UFW status for statistics
            const stats = {
                status: 'inactive',
                default_incoming: 'unknown',
                default_outgoing: 'unknown',
                rules_count: rules.active.length,
                saved_count: rules.saved.length
            };

            if (stdout.includes('Status: active')) {
                stats.status = 'active';
            }

            const incomingMatch = stdout.match(/Default: deny \(incoming\)/);
            if (incomingMatch) stats.default_incoming = 'deny';

            const outgoingMatch = stdout.match(/allow \(outgoing\)/);
            if (outgoingMatch) stats.default_outgoing = 'allow';

            return stats;
        } catch (error) {
            logger.error('Failed to get UFW statistics', error);
            return {
                status: 'error',
                rules_count: 0,
                saved_count: 0
            };
        }
    }

    async isEssentialPort(port, protocol = 'tcp') {
        const sshPort = await this.getSSHPort();
        const webguiPort = await this.getWebGUIPort();

        const essentialPorts = [
            { port: sshPort, protocol: 'tcp', name: 'SSH' },
            { port: parseInt(webguiPort), protocol: 'tcp', name: 'WebGUI' }
        ];

        return essentialPorts.find(ep =>
            ep.port === parseInt(port) && ep.protocol === protocol
        );
    }

    async resolveConflicts(newRule, user = 'system') {
        try {
            const existingRules = await this.loadRules();
            const conflictingRules = [];

            for (const rule of existingRules) {
                if (this.rulesConflict(newRule, rule)) {
                    conflictingRules.push(rule);
                }
            }

            // Check if we're trying to block an essential port
            if (newRule.port && (newRule.action === 'deny' || newRule.action === 'drop')) {
                const essential = await this.isEssentialPort(newRule.port, newRule.protocol);
                if (essential) {
                    logger.warn(`⚠️  Warning: Blocking essential ${essential.name} port ${newRule.port}`);
                    logger.warn(`   This will remove the auto-allowed rule and may affect connectivity`);
                }
            }

            // Remove any UFW rules for the same port/protocol directly
            if (newRule.port && newRule.protocol) {
                try {
                    // Enhanced cleanup - try more variations
                    const deleteCommands = [
                        `ufw delete allow ${newRule.port}/${newRule.protocol}`,
                        `ufw delete deny ${newRule.port}/${newRule.protocol}`,
                        `ufw delete reject ${newRule.port}/${newRule.protocol}`,
                        `ufw delete allow in ${newRule.port}/${newRule.protocol}`,
                        `ufw delete deny in ${newRule.port}/${newRule.protocol}`,
                        `ufw delete reject in ${newRule.port}/${newRule.protocol}`,
                        `ufw delete allow out ${newRule.port}/${newRule.protocol}`,
                        `ufw delete deny out ${newRule.port}/${newRule.protocol}`,
                        `ufw delete reject out ${newRule.port}/${newRule.protocol}`
                    ];

                    let removedCount = 0;
                    for (const cmd of deleteCommands) {
                        try {
                            const result = await this.executeCommand(cmd, true);
                            if (result.stdout && !result.stdout.includes('Could not delete')) {
                                logger.info(`✓ Removed existing UFW rule: ${cmd.replace('ufw delete ', '')}`);
                                removedCount++;
                            }
                        } catch (e) {
                            // Ignore errors - rule might not exist
                        }
                    }

                    if (removedCount > 0) {
                        logger.info(`✓ Cleaned ${removedCount} existing UFW rule(s) for port ${newRule.port}`);
                    }
                } catch (error) {
                    // Continue if cleanup fails
                }
            }

            // Remove conflicting rules from our saved rules
            for (const conflictRule of conflictingRules) {
                const conflictDescription = `${conflictRule.type} ${conflictRule.protocol || ''} ${conflictRule.port || ''} - ${conflictRule.action.toUpperCase()}`;
                const newRuleDescription = `${newRule.type} ${newRule.protocol || ''} ${newRule.port || ''} - ${newRule.action.toUpperCase()}`;

                logger.info(`Conflict detected and resolving:`);
                logger.info(`  Removing: ${conflictRule.id.substring(0, 8)} (${conflictDescription})`);
                logger.info(`  Adding:   ${newRuleDescription}`);

                logger.audit('REMOVE_CONFLICT', user, {
                    removedRule: conflictRule,
                    newRule: newRule,
                    reason: 'automatic_conflict_resolution',
                    conflictType: this.getConflictType(conflictRule, newRule),
                    timestamp: new Date().toISOString()
                });

                await this.deleteRule(conflictRule.id, `${user}_auto_conflict`);
            }

            if (conflictingRules.length > 0) {
                logger.info(`✓ Resolved ${conflictingRules.length} conflicting rule(s) automatically`);
            }

        } catch (error) {
            logger.error('Failed to resolve rule conflicts', error);
            // Continue with adding rule even if conflict resolution fails
        }
    }

    rulesConflict(rule1, rule2) {
        // Normalize actions for comparison
        const action1 = (rule1.action || '').toLowerCase();
        const action2 = (rule2.action || '').toLowerCase();

        // Same direction is required for conflict
        if (rule1.direction !== rule2.direction) {
            return false;
        }

        // Port-based conflicts
        if (rule1.port && rule2.port &&
            rule1.port === rule2.port &&
            rule1.protocol === rule2.protocol) {

            // Different actions = conflict
            if (action1 !== action2) {
                // Check if sources overlap
                if (this.sourcesOverlap(rule1.source, rule2.source)) {
                    return true;
                }
            }
        }

        // ICMP conflicts
        if (rule1.type === 'icmp' && rule2.type === 'icmp') {
            if (action1 !== action2) {
                if (this.sourcesOverlap(rule1.source, rule2.source)) {
                    return true;
                }
            }
        }

        // IP/Network conflicts
        if ((rule1.type === 'ip' || rule1.type === 'network') &&
            (rule2.type === 'ip' || rule2.type === 'network')) {

            if (action1 !== action2) {
                if (this.sourcesOverlap(rule1.source, rule2.source)) {
                    return true;
                }
            }
        }

        return false;
    }

    sourcesOverlap(source1, source2) {
        // If both are undefined/null = overlap (both apply to 'any')
        if (!source1 && !source2) {
            return true;
        }

        // If one is specific and other is 'any' = overlap
        if (!source1 || !source2) {
            return true;
        }

        // If both are the same specific source = overlap
        if (source1 === source2) {
            return true;
        }

        // Could add more sophisticated CIDR overlap detection here
        return false;
    }

    getConflictType(rule1, rule2) {
        if (rule1.port && rule2.port && rule1.port === rule2.port) {
            return 'port_conflict';
        }
        if (rule1.type === 'icmp' && rule2.type === 'icmp') {
            return 'icmp_conflict';
        }
        if ((rule1.type === 'ip' || rule1.type === 'network') &&
            (rule2.type === 'ip' || rule2.type === 'network')) {
            return 'ip_network_conflict';
        }
        return 'general_conflict';
    }

    async checkUFWInstalled() {
        try {
            const { error } = await this.executeCommand('which ufw', true);
            return !error;
        } catch {
            return false;
        }
    }

    async installUFW() {
        try {
            // Detect package manager and install UFW
            const { error: aptError } = await this.executeCommand('which apt-get', true);
            const { error: yumError } = await this.executeCommand('which yum', true);
            const { error: dnfError } = await this.executeCommand('which dnf', true);
            const { error: pacmanError } = await this.executeCommand('which pacman', true);

            if (!aptError) {
                await this.executeCommand('apt-get update && apt-get install -y ufw');
            } else if (!dnfError) {
                await this.executeCommand('dnf install -y ufw');
            } else if (!yumError) {
                await this.executeCommand('yum install -y ufw');
            } else if (!pacmanError) {
                await this.executeCommand('pacman -S --noconfirm ufw');
            } else {
                throw new Error('No supported package manager found');
            }

            logger.info('UFW installed successfully');
            return true;
        } catch (error) {
            logger.error('Failed to install UFW', error);
            throw error;
        }
    }
}

module.exports = UFWManager;