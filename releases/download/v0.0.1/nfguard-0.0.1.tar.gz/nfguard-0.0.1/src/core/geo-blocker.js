const fs = require('fs-extra');
const path = require('path');
const maxmind = require('maxmind');
const IPCIDR = require('ip-cidr');
const logger = require('./logger');

class GeoBlocker {
    constructor(nftablesManager) {
        this.nftablesManager = nftablesManager;
        this.geoDbPath = '/etc/nfguard/geo-blocks.json';
        this.ipListsPath = '/etc/nfguard/ip-lists/';
        this.mmdbPath = '/opt/nfguard/src/GeoLite/GeoLite2-Country.mmdb';
        this.mmdbReader = null;
        this.ensureDirectories();
        this.initializeGeoDatabase();
    }

    ensureDirectories() {
        fs.ensureDirSync(this.ipListsPath);
    }

    async initializeGeoDatabase() {
        try {
            // Try installed path first
            if (await fs.pathExists(this.mmdbPath)) {
                this.mmdbReader = await maxmind.open(this.mmdbPath);
            } else {
                // Try local development path
                const devPath = path.join(__dirname, '../GeoLite/GeoLite2-Country.mmdb');
                if (await fs.pathExists(devPath)) {
                    this.mmdbReader = await maxmind.open(devPath);
                }
            }
        } catch (error) {
            logger.error('Failed to load GeoLite database', error);
        }
    }

    async blockCountry(countryCode, user = 'system') {
        logger.audit('GEO_BLOCK_COUNTRY', user, {
            countryCode: countryCode,
            timestamp: new Date().toISOString()
        });

        const ipRanges = await this.getCountryIPRanges(countryCode);
        const blockRule = {
            id: `geo-block-${countryCode}-${Date.now()}`,
            country: countryCode,
            ipRanges: ipRanges,
            createdAt: new Date().toISOString()
        };

        if (!ipRanges || ipRanges.length === 0) {
            throw new Error(`No IP ranges found for country: ${countryCode}`);
        }

        try {
            for (const range of ipRanges) {
                await this.nftablesManager.executeCommand(
                    `nft add rule inet nfguard input ip saddr ${range} drop comment "GeoBlock-${countryCode}"`
                );
            }

            await this.saveGeoBlock(blockRule);
            return blockRule;
        } catch (error) {
            logger.error(`Failed to block country ${countryCode}`, error);
            throw error;
        }
    }

    async unblockCountry(countryCode) {
        const blocks = await this.loadGeoBlocks();
        const countryBlocks = blocks.filter(b => b.country === countryCode);

        for (const block of countryBlocks) {
            for (const range of block.ipRanges) {
                try {
                    const { stdout } = await this.nftablesManager.executeCommand(
                        `nft -a list chain inet nfguard input | grep "${range}"`
                    );

                    const match = stdout.match(/handle (\d+)/);
                    if (match) {
                        await this.nftablesManager.executeCommand(
                            `nft delete rule inet nfguard input handle ${match[1]}`
                        );
                    }
                } catch (error) {
                    console.error(`Failed to remove rule for ${range}:`, error);
                }
            }
        }

        const updatedBlocks = blocks.filter(b => b.country !== countryCode);
        await fs.writeJson(this.geoDbPath, updatedBlocks);
        return true;
    }

    async getCountryIPRanges(countryCode) {
        const cachePath = path.join(this.ipListsPath, `${countryCode}.json`);

        // Check cache first
        if (await fs.pathExists(cachePath)) {
            const cache = await fs.readJson(cachePath);
            const cacheAge = Date.now() - new Date(cache.updatedAt).getTime();

            // Use cache if less than 24 hours old
            if (cacheAge < 24 * 60 * 60 * 1000) {
                return cache.ranges;
            }
        }

        // Generate ranges from MaxMind database
        const ranges = await this.generateCountryRanges(countryCode);

        // Cache the ranges
        await fs.writeJson(cachePath, {
            country: countryCode,
            ranges: ranges,
            updatedAt: new Date().toISOString()
        });

        return ranges;
    }

    async generateCountryRanges(countryCode) {
        const ranges = new Set();

        // If MaxMind database is not available, use common ranges
        if (!this.mmdbReader) {
            return this.getFallbackRanges(countryCode);
        }

        try {
            // Common IP ranges to check (simplified for performance)
            const ipPrefixes = [];

            // Generate test IPs across the IPv4 space
            for (let a = 1; a <= 223; a++) {
                // Skip private and reserved ranges
                if (a === 10 || a === 127 || (a >= 224 && a <= 255)) continue;
                if (a === 172) continue; // 172.16.0.0 - 172.31.0.0
                if (a === 192 && a === 168) continue;

                // Sample a few IPs from each /8 block
                for (let b = 0; b < 256; b += 64) {
                    ipPrefixes.push(`${a}.${b}.0.0/16`);
                }
            }

            // Check each IP prefix
            for (const prefix of ipPrefixes) {
                const cidr = new IPCIDR(prefix);
                const testIp = cidr.start();

                const result = this.mmdbReader.get(testIp);
                if (result && result.country && result.country.iso_code === countryCode) {
                    // Found a matching range, add it
                    ranges.add(prefix);
                }
            }

            // If no ranges found, use fallback
            if (ranges.size === 0) {
                return this.getFallbackRanges(countryCode);
            }

            return Array.from(ranges);
        } catch (error) {
            logger.error(`Failed to generate ranges for ${countryCode}`, error);
            return this.getFallbackRanges(countryCode);
        }
    }

    getFallbackRanges(countryCode) {
        // Fallback ranges for common countries
        const fallbackRanges = {
            'CN': ['1.0.1.0/24', '1.0.8.0/21', '1.2.0.0/15', '1.4.0.0/14'],
            'RU': ['2.56.0.0/14', '5.8.0.0/13', '5.136.0.0/13', '31.173.0.0/16'],
            'US': ['3.0.0.0/8', '4.0.0.0/8', '8.0.0.0/8', '15.0.0.0/8'],
            'BR': ['131.0.0.0/11', '177.0.0.0/8', '179.0.0.0/8', '189.0.0.0/8'],
            'IN': ['14.96.0.0/14', '27.0.0.0/8', '49.204.0.0/14', '103.0.0.0/8'],
            'DE': ['5.1.0.0/16', '46.4.0.0/14', '78.46.0.0/15', '85.214.0.0/15'],
            'GB': ['2.16.0.0/12', '5.62.0.0/16', '81.0.0.0/8', '86.0.0.0/7'],
            'FR': ['5.135.0.0/16', '37.59.0.0/16', '51.68.0.0/14', '92.222.0.0/16'],
            'JP': ['1.0.16.0/20', '14.8.0.0/13', '27.133.0.0/16', '61.192.0.0/12'],
            'KR': ['1.11.0.0/16', '14.63.0.0/16', '27.1.0.0/16', '61.72.0.0/13'],
            'AU': ['1.0.0.0/24', '14.0.0.0/13', '27.33.0.0/16', '58.0.0.0/7'],
            'CA': ['24.0.0.0/7', '47.64.0.0/11', '64.0.0.0/10', '70.0.0.0/7'],
            'IT': ['5.152.0.0/14', '31.14.0.0/16', '37.160.0.0/12', '79.0.0.0/10'],
            'ES': ['5.224.0.0/14', '31.4.0.0/16', '37.152.0.0/13', '83.0.0.0/9'],
            'NL': ['5.255.192.0/18', '31.3.0.0/16', '37.0.0.0/14', '85.144.0.0/13'],
            'SE': ['5.242.0.0/16', '31.3.152.0/21', '37.123.0.0/16', '78.64.0.0/11'],
            'NO': ['2.148.0.0/14', '31.45.0.0/17', '37.191.0.0/16', '77.40.0.0/13'],
            'FI': ['37.27.0.0/16', '37.136.0.0/15', '62.236.0.0/15', '81.175.0.0/16'],
            'IR': ['2.144.0.0/14', '5.22.0.0/15', '31.7.64.0/18', '46.209.0.0/16'],
            'KP': ['175.45.176.0/22', '210.52.109.0/24']
        };

        return fallbackRanges[countryCode] || [];
    }

    async listBlockedCountries() {
        const blocks = await this.loadGeoBlocks();
        const countries = {};

        for (const block of blocks) {
            if (!countries[block.country]) {
                countries[block.country] = {
                    code: block.country,
                    name: this.getCountryName(block.country),
                    blockedAt: block.createdAt,
                    ipRanges: []
                };
            }
            countries[block.country].ipRanges.push(...block.ipRanges);
        }

        return Object.values(countries);
    }

    getCountryName(code) {
        const countryNames = {
            'CN': 'China',
            'RU': 'Russia',
            'KP': 'North Korea',
            'IR': 'Iran',
            'US': 'United States',
            'BR': 'Brazil',
            'IN': 'India',
            'DE': 'Germany',
            'GB': 'United Kingdom',
            'FR': 'France',
            'JP': 'Japan',
            'KR': 'South Korea',
            'AU': 'Australia',
            'CA': 'Canada',
            'IT': 'Italy',
            'ES': 'Spain',
            'NL': 'Netherlands',
            'SE': 'Sweden',
            'NO': 'Norway',
            'FI': 'Finland'
        };

        return countryNames[code] || code;
    }

    async checkIP(ip) {
        let countryCode = 'Unknown';
        let countryName = 'Unknown';

        if (this.mmdbReader) {
            try {
                const result = this.mmdbReader.get(ip);
                if (result && result.country) {
                    countryCode = result.country.iso_code || 'Unknown';
                    countryName = result.country.names?.en || countryCode;
                }
            } catch (error) {
                logger.error(`Failed to lookup IP ${ip}`, error);
            }
        }

        const blocks = await this.loadGeoBlocks();
        const isBlocked = blocks.some(b => b.country === countryCode);

        return {
            ip: ip,
            country: countryCode,
            countryName: countryName,
            blocked: isBlocked
        };
    }

    async saveGeoBlock(block) {
        const blocks = await this.loadGeoBlocks();
        blocks.push(block);
        await fs.writeJson(this.geoDbPath, blocks);
        return block;
    }

    async loadGeoBlocks() {
        try {
            if (await fs.pathExists(this.geoDbPath)) {
                return await fs.readJson(this.geoDbPath);
            }
        } catch (error) {
            console.error('Failed to load geo blocks', error);
        }
        return [];
    }

    async updateGeoDatabase() {
        console.log('Updating GeoIP database...');
        return true;
    }
}

module.exports = GeoBlocker;