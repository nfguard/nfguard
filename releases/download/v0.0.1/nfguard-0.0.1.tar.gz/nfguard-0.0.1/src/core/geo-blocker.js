const fs = require('fs-extra');
const path = require('path');
const maxmind = require('maxmind');
const { execSync, exec } = require('child_process');
const { promisify } = require('util');
const logger = require('./logger');
const execAsync = promisify(exec);

class GeoBlocker {
    constructor(firewallManager) {
        this.firewallManager = firewallManager;
        this.geoDbPath = '/etc/nfguard/geo-blocks.json';
        this.ipListsPath = '/etc/nfguard/ip-lists/';
        this.mmdbPaths = [
            '/opt/nfguard/GeoLite2-Country.mmdb',
            '/usr/share/GeoIP/GeoLite2-Country.mmdb',
            '/var/lib/GeoIP/GeoLite2-Country.mmdb',
            path.join(__dirname, '../../GeoLite2-Country.mmdb')
        ];
        this.mmdbReader = null;
        this.countryData = {};
        this.ipsetPrefix = 'nfguard-geo';
        this.ensureDirectories();
        this.initializeGeoDatabase();
        this.ensureIpset();
        this.initializeIpsetIntegration();
    }

    ensureDirectories() {
        fs.ensureDirSync(this.ipListsPath);
        fs.ensureDirSync('/opt/nfguard');
    }

    async ensureIpset() {
        try {
            // Check if ipset is installed
            execSync('which ipset', { stdio: 'ignore' });
            logger.info('ipset is available');
        } catch (error) {
            logger.warn('ipset not found, installing...');
            try {
                // Detect package manager and install ipset
                try {
                    execSync('which apt-get', { stdio: 'ignore' });
                    execSync('apt-get update && apt-get install -y ipset', { stdio: 'inherit' });
                    logger.info('ipset installed via apt-get');
                } catch {
                    try {
                        execSync('which yum', { stdio: 'ignore' });
                        execSync('yum install -y ipset', { stdio: 'inherit' });
                        logger.info('ipset installed via yum');
                    } catch {
                        try {
                            execSync('which dnf', { stdio: 'ignore' });
                            execSync('dnf install -y ipset', { stdio: 'inherit' });
                            logger.info('ipset installed via dnf');
                        } catch {
                            logger.error('Could not install ipset automatically');
                            throw new Error('ipset installation failed');
                        }
                    }
                }
            } catch (installError) {
                logger.error('Failed to install ipset', installError);
                throw installError;
            }
        }
    }

    async initializeIpsetIntegration() {
        try {
            // Ensure UFW supports ipset integration
            const ufwSupportsIpset = await this.checkUfwIpsetSupport();
            if (ufwSupportsIpset) {
                logger.info('UFW supports ipset integration');
            } else {
                logger.warn('UFW does not support ipset, using direct iptables integration');
            }
        } catch (error) {
            logger.error('Failed to initialize ipset integration', error);
        }
    }

    async checkUfwIpsetSupport() {
        try {
            const { stdout } = await execAsync('ufw --version');
            // UFW 0.36+ generally supports ipset
            const versionMatch = stdout.match(/ufw ([0-9]+\.[0-9]+)/);
            if (versionMatch) {
                const version = parseFloat(versionMatch[1]);
                return version >= 0.36;
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    async downloadGeoDatabase() {
        try {
            logger.info('Downloading GeoLite2 database...');

            // Try to download official MaxMind database first
            const mmdbUrl = 'https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-Country&license_key=YOUR_LICENSE_KEY&suffix=tar.gz';

            // Fallback to public IP-to-country database
            const geoDataUrl = 'https://raw.githubusercontent.com/sapics/ip-location-db/main/geo-whois-asn-country/geo-whois-asn-country-ipv4.csv';

            try {
                const response = await fetch(geoDataUrl);
                if (!response.ok) {
                    throw new Error(`Failed to download geo database: ${response.statusText}`);
                }

                const csvData = await response.text();
                await this.parseCountryData(csvData);
                logger.info('Geo database downloaded and parsed successfully');
                return true;
            } catch (csvError) {
                logger.warn('Failed to download CSV data, using fallback ranges');
                return false;
            }
        } catch (error) {
            logger.error('Failed to download geo database', error);
            return false;
        }
    }

    async parseCountryData(csvData) {
        const lines = csvData.split('\n');
        this.countryData = {};
        let processedLines = 0;

        logger.info(`Processing ${lines.length} lines of geo data...`);

        for (const line of lines) {
            if (!line.trim()) continue;

            const parts = line.split(',');
            if (parts.length >= 3) {
                const startIp = parts[0].trim().replace(/"/g, '');
                const endIp = parts[1].trim().replace(/"/g, '');
                const countryCode = parts[2].trim().replace(/"/g, '').toUpperCase();

                if (this.isValidIP(startIp) && countryCode.length === 2) {
                    if (!this.countryData[countryCode]) {
                        this.countryData[countryCode] = [];
                    }

                    // Convert IP range to CIDR if possible
                    const cidr = this.ipRangeToCIDR(startIp, endIp);
                    if (cidr) {
                        this.countryData[countryCode].push(cidr);
                        processedLines++;
                    }
                }
            }
        }

        logger.info(`Processed ${processedLines} IP ranges for ${Object.keys(this.countryData).length} countries`);

        // Save processed data to cache
        const cacheFile = path.join(this.ipListsPath, 'country-data.json');
        await fs.writeJson(cacheFile, {
            data: this.countryData,
            updatedAt: new Date().toISOString(),
            totalRanges: processedLines
        });
    }

    isValidIP(ip) {
        const parts = ip.split('.');
        return parts.length === 4 && parts.every(part => {
            const num = parseInt(part);
            return num >= 0 && num <= 255;
        });
    }

    ipRangeToCIDR(startIp, endIp) {
        try {
            // Simple conversion - for production use proper CIDR calculation
            const start = this.ipToNumber(startIp);
            const end = this.ipToNumber(endIp);
            const range = end - start + 1;

            // Find the appropriate CIDR prefix
            let prefixLength = 32;
            let blockSize = 1;

            while (blockSize < range && prefixLength > 0) {
                prefixLength--;
                blockSize *= 2;
            }

            return `${startIp}/${prefixLength}`;
        } catch (error) {
            return null;
        }
    }

    ipToNumber(ip) {
        return ip.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet), 0) >>> 0;
    }

    async initializeGeoDatabase() {
        try {
            // Try to find existing MMDB file
            let mmdbFound = false;
            for (const mmdbPath of this.mmdbPaths) {
                if (await fs.pathExists(mmdbPath)) {
                    this.mmdbReader = await maxmind.open(mmdbPath);
                    logger.info(`Loaded GeoLite database from ${mmdbPath}`);
                    mmdbFound = true;
                    break;
                }
            }

            if (!mmdbFound) {
                logger.warn('GeoLite MMDB not found, downloading country data...');
                await this.downloadGeoDatabase();
            }
        } catch (error) {
            logger.error('Failed to initialize geo database', error);
            // Try to download as fallback
            await this.downloadGeoDatabase();
        }
    }

    async blockCountry(countryCode, user = 'system') {
        logger.audit('GEO_BLOCK_COUNTRY', user, {
            countryCode: countryCode,
            timestamp: new Date().toISOString()
        });

        const countryUpper = countryCode.toUpperCase();
        const ipRanges = await this.getCountryIPRanges(countryUpper);
        const blockRule = {
            id: `geo-block-${countryUpper}-${Date.now()}`,
            country: countryUpper,
            ipRanges: ipRanges,
            createdAt: new Date().toISOString()
        };

        if (!ipRanges || ipRanges.length === 0) {
            throw new Error(`No IP ranges found for country: ${countryUpper}`);
        }

        try {
            // Create ipset for this country
            const ipsetName = `${this.ipsetPrefix}-${countryUpper.toLowerCase()}`;
            await this.createCountryIpset(ipsetName, ipRanges);

            // Add UFW rule to block the ipset
            await this.addUfwIpsetRule(ipsetName, countryUpper);

            blockRule.ipsetName = ipsetName;
            blockRule.rulesAdded = ipRanges.length;
            await this.saveGeoBlock(blockRule);

            logger.info(`Successfully blocked ${countryUpper} with ${ipRanges.length} IP ranges using ipset`);
            return blockRule;
        } catch (error) {
            logger.error(`Failed to block country ${countryUpper}`, error);
            throw error;
        }
    }

    async createCountryIpset(ipsetName, ipRanges) {
        try {
            // Destroy existing ipset if it exists
            try {
                await execAsync(`ipset destroy ${ipsetName}`);
            } catch (error) {
                // Ignore if it doesn't exist
            }

            // Create new ipset
            await execAsync(`ipset create ${ipsetName} hash:net`);
            logger.info(`Created ipset: ${ipsetName}`);

            // Add IP ranges to ipset in batches
            const batchSize = 100;
            for (let i = 0; i < ipRanges.length; i += batchSize) {
                const batch = ipRanges.slice(i, i + batchSize);
                const commands = batch.map(range => `ipset add ${ipsetName} ${range}`).join('; ');

                try {
                    await execAsync(commands);
                    logger.info(`Added batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(ipRanges.length/batchSize)} to ${ipsetName}`);
                } catch (error) {
                    logger.warn(`Failed to add some ranges in batch ${Math.floor(i/batchSize) + 1}`, error.message);
                }
            }

            logger.info(`Successfully populated ipset ${ipsetName} with ${ipRanges.length} ranges`);
        } catch (error) {
            logger.error(`Failed to create ipset ${ipsetName}`, error);
            throw error;
        }
    }

    async addUfwIpsetRule(ipsetName, countryCode) {
        try {
            // Add UFW rule that references the ipset
            const comment = `Geo-block ${countryCode}`;

            // First try UFW's native ipset support (if available)
            try {
                const ufwCommand = `ufw deny from ipset:${ipsetName} comment "${comment}"`;
                await execAsync(ufwCommand);
                logger.info(`Added UFW ipset rule: ${ufwCommand}`);
            } catch (ufwError) {
                // Fallback to direct iptables rule
                logger.warn('UFW does not support ipset, using direct iptables rule');
                const iptablesCommand = `iptables -I ufw-before-input -m set --match-set ${ipsetName} src -j DROP -m comment --comment "${comment}"`;
                await execAsync(iptablesCommand);
                logger.info(`Added iptables ipset rule: ${iptablesCommand}`);
            }
        } catch (error) {
            logger.error(`Failed to add firewall rule for ipset ${ipsetName}`, error);
            throw error;
        }
    }

    async unblockCountry(countryCode) {
        try {
            const countryUpper = countryCode.toUpperCase();
            const blocks = await this.loadGeoBlocks();
            const countryBlocks = blocks.filter(b => b.country === countryUpper);

            if (countryBlocks.length === 0) {
                throw new Error(`Country ${countryUpper} is not currently blocked`);
            }

            let rulesRemoved = 0;
            for (const block of countryBlocks) {
                if (block.ipsetName) {
                    try {
                        // Remove UFW/iptables rule first
                        await this.removeUfwIpsetRule(block.ipsetName, countryUpper);

                        // Destroy the ipset
                        await execAsync(`ipset destroy ${block.ipsetName}`);
                        logger.info(`Destroyed ipset: ${block.ipsetName}`);
                        rulesRemoved++;
                    } catch (error) {
                        logger.error(`Failed to remove ipset ${block.ipsetName}`, error);
                    }
                } else {
                    // Fallback for old-style rules
                    for (const range of block.ipRanges || []) {
                        try {
                            const command = `iptables -D ufw-before-input -s ${range} -j DROP -m comment --comment "GeoBlock-${countryUpper}"`;
                            await execAsync(command);
                            rulesRemoved++;
                        } catch (error) {
                            // Ignore errors for non-existent rules
                        }
                    }
                }
            }

            // Remove from saved blocks
            const updatedBlocks = blocks.filter(b => b.country !== countryUpper);
            await fs.writeJson(this.geoDbPath, updatedBlocks);

            logger.info(`Successfully unblocked ${countryUpper}, removed ${rulesRemoved} rules/ipsets`);
            return true;
        } catch (error) {
            logger.error(`Failed to unblock country ${countryCode}`, error);
            throw error;
        }
    }

    async removeUfwIpsetRule(ipsetName, countryCode) {
        try {
            // Try to remove UFW rule first
            try {
                const ufwCommand = `ufw delete deny from ipset:${ipsetName}`;
                await execAsync(ufwCommand);
                logger.info(`Removed UFW ipset rule for ${ipsetName}`);
            } catch (ufwError) {
                // Try direct iptables removal
                const comment = `Geo-block ${countryCode}`;
                const iptablesCommand = `iptables -D ufw-before-input -m set --match-set ${ipsetName} src -j DROP -m comment --comment "${comment}"`;
                await execAsync(iptablesCommand);
                logger.info(`Removed iptables ipset rule for ${ipsetName}`);
            }
        } catch (error) {
            logger.warn(`Failed to remove firewall rule for ipset ${ipsetName}:`, error.message);
        }
    }

    async getCountryIPRanges(countryCode) {
        const countryUpper = countryCode.toUpperCase();
        const cachePath = path.join(this.ipListsPath, `${countryUpper}.json`);

        // Check cache first
        if (await fs.pathExists(cachePath)) {
            const cache = await fs.readJson(cachePath);
            const cacheAge = Date.now() - new Date(cache.updatedAt).getTime();

            // Use cache if less than 7 days old
            if (cacheAge < 7 * 24 * 60 * 60 * 1000) {
                logger.info(`Using cached IP ranges for ${countryUpper} (${cache.ranges.length} ranges)`);
                return cache.ranges;
            }
        }

        // Try to get ranges from various sources
        let ranges = [];

        // First try from downloaded country data
        if (this.countryData[countryUpper]) {
            ranges = this.countryData[countryUpper];
            logger.info(`Using downloaded data for ${countryUpper} (${ranges.length} ranges)`);
        } else if (this.mmdbReader) {
            // Generate ranges from MaxMind database
            ranges = await this.generateCountryRanges(countryUpper);
            logger.info(`Generated ranges from MMDB for ${countryUpper} (${ranges.length} ranges)`);
        } else {
            // Use fallback ranges
            ranges = this.getFallbackRanges(countryUpper);
            logger.info(`Using fallback ranges for ${countryUpper} (${ranges.length} ranges)`);
        }

        // Cache the ranges
        if (ranges.length > 0) {
            await fs.writeJson(cachePath, {
                country: countryUpper,
                ranges: ranges,
                updatedAt: new Date().toISOString(),
                source: this.countryData[countryUpper] ? 'downloaded' :
                       this.mmdbReader ? 'mmdb' : 'fallback'
            });
        }

        return ranges;
    }

    async generateCountryRanges(countryCode) {
        const ranges = new Set();
        const countryUpper = countryCode.toUpperCase();

        // If MaxMind database is not available, use fallback ranges
        if (!this.mmdbReader) {
            return this.getFallbackRanges(countryUpper);
        }

        try {
            logger.info(`Generating IP ranges for ${countryUpper} from MMDB...`);
            const ipPrefixes = [];

            // More comprehensive scanning approach
            for (let a = 1; a <= 223; a++) {
                // Skip private and reserved ranges
                if (a === 10 || a === 127 || (a >= 169 && a <= 169) || (a >= 224 && a <= 255)) continue;
                if (a === 172) continue; // 172.16.0.0 - 172.31.0.0 are private
                if (a === 192) continue; // 192.168.0.0 is private

                // Sample different points in each /8 block for better coverage
                const samplePoints = [0, 32, 64, 96, 128, 160, 192, 224];
                for (const b of samplePoints) {
                    if (b > 255) continue;

                    const testIp = `${a}.${b}.1.1`;
                    try {
                        const result = this.mmdbReader.get(testIp);
                        if (result && result.country && result.country.iso_code === countryUpper) {
                            // Create a /16 range for this block
                            ranges.add(`${a}.${b}.0.0/16`);
                        }
                    } catch (lookupError) {
                        // Continue with next IP
                    }
                }

                // Log progress every 50 blocks
                if (a % 50 === 0) {
                    logger.info(`Processed ${a}/223 IP blocks, found ${ranges.size} ranges for ${countryUpper}`);
                }
            }

            logger.info(`MMDB scan complete for ${countryUpper}: found ${ranges.size} ranges`);

            // If no ranges found or very few, supplement with fallback
            if (ranges.size < 5) {
                logger.warn(`Only found ${ranges.size} ranges for ${countryUpper}, supplementing with fallback ranges`);
                const fallbackRanges = this.getFallbackRanges(countryUpper);
                fallbackRanges.forEach(range => ranges.add(range));
            }

            return Array.from(ranges);
        } catch (error) {
            logger.error(`Failed to generate ranges for ${countryUpper}`, error);
            return this.getFallbackRanges(countryUpper);
        }
    }

    getFallbackRanges(countryCode) {
        const countryUpper = countryCode.toUpperCase();

        // Comprehensive fallback ranges for countries based on RIR allocations
        const fallbackRanges = {
            'CN': ['1.0.1.0/24', '1.0.8.0/21', '1.2.0.0/15', '1.4.0.0/14', '14.144.0.0/12', '27.8.0.0/13',
                   '36.0.0.0/8', '39.128.0.0/10', '42.0.0.0/8', '58.14.0.0/15', '59.32.0.0/11', '60.0.0.0/8',
                   '61.128.0.0/10', '101.0.0.0/9', '103.0.0.0/10', '106.0.0.0/8', '110.0.0.0/7', '112.0.0.0/6',
                   '116.0.0.0/6', '120.0.0.0/6', '124.0.0.0/7', '140.75.0.0/16', '159.226.0.0/16', '161.207.0.0/16',
                   '162.105.0.0/16', '166.111.0.0/16', '167.139.0.0/16', '168.160.0.0/16', '202.0.0.0/8',
                   '210.0.0.0/7', '218.0.0.0/8', '219.128.0.0/9', '220.128.0.0/11', '221.0.0.0/11', '222.0.0.0/8'],
            'RU': ['2.56.0.0/14', '5.8.0.0/13', '5.136.0.0/13', '31.173.0.0/16', '37.29.0.0/16', '46.17.0.0/16',
                   '46.48.0.0/12', '77.88.0.0/13', '78.24.0.0/13', '79.104.0.0/13', '80.64.0.0/13', '81.16.0.0/12',
                   '81.176.0.0/13', '82.96.0.0/12', '83.96.0.0/12', '84.16.0.0/12', '85.112.0.0/12', '86.96.0.0/13',
                   '87.224.0.0/12', '88.80.0.0/12', '89.144.0.0/13', '91.184.0.0/13', '92.48.0.0/13', '93.176.0.0/13',
                   '94.16.0.0/12', '95.32.0.0/13', '176.96.0.0/11', '178.128.0.0/12', '185.0.0.0/13', '188.128.0.0/12',
                   '193.0.0.0/8', '194.0.0.0/8', '195.0.0.0/8', '212.0.0.0/8', '213.128.0.0/12', '217.0.0.0/13'],
            'US': ['3.0.0.0/8', '4.0.0.0/8', '6.0.0.0/8', '7.0.0.0/8', '8.0.0.0/8', '9.0.0.0/8', '11.0.0.0/8',
                   '12.0.0.0/8', '13.0.0.0/8', '15.0.0.0/8', '16.0.0.0/8', '17.0.0.0/8', '18.0.0.0/8', '19.0.0.0/8',
                   '20.0.0.0/8', '21.0.0.0/8', '22.0.0.0/8', '23.0.0.0/8', '24.0.0.0/8', '32.0.0.0/8', '34.0.0.0/8',
                   '35.0.0.0/8', '40.0.0.0/8', '44.0.0.0/8', '45.0.0.0/8', '47.0.0.0/8', '50.0.0.0/8', '52.0.0.0/8',
                   '54.0.0.0/8', '63.0.0.0/8', '64.0.0.0/8', '65.0.0.0/8', '66.0.0.0/8', '67.0.0.0/8', '68.0.0.0/8',
                   '69.0.0.0/8', '70.0.0.0/8', '71.0.0.0/8', '72.0.0.0/8', '73.0.0.0/8', '74.0.0.0/8', '75.0.0.0/8',
                   '76.0.0.0/8', '96.0.0.0/8', '97.0.0.0/8', '98.0.0.0/8', '99.0.0.0/8', '100.0.0.0/8', '104.0.0.0/8',
                   '107.0.0.0/8', '108.0.0.0/8', '173.0.0.0/8', '174.0.0.0/8', '184.0.0.0/8', '199.0.0.0/8',
                   '204.0.0.0/8', '205.0.0.0/8', '206.0.0.0/8', '207.0.0.0/8', '208.0.0.0/8', '209.0.0.0/8'],
            'BR': ['131.0.0.0/11', '143.106.0.0/16', '150.161.0.0/16', '152.84.0.0/14', '177.0.0.0/8', '179.0.0.0/8',
                   '186.192.0.0/10', '189.0.0.0/8', '191.0.0.0/9', '200.128.0.0/9', '201.0.0.0/8'],
            'IN': ['14.96.0.0/11', '27.0.0.0/8', '49.204.0.0/14', '103.0.0.0/8', '106.192.0.0/10', '110.224.0.0/11',
                   '117.192.0.0/10', '118.67.0.0/16', '121.240.0.0/12', '122.160.0.0/11', '125.16.0.0/12',
                   '150.129.0.0/16', '157.34.0.0/15', '163.47.0.0/16', '180.179.0.0/16', '182.72.0.0/13',
                   '183.82.0.0/15', '202.0.0.0/11', '203.88.0.0/13', '210.212.0.0/14'],
            'DE': ['5.1.0.0/16', '46.4.0.0/14', '78.46.0.0/15', '85.214.0.0/15', '134.76.0.0/16', '141.76.0.0/16',
                   '176.0.0.0/8', '193.0.0.0/11', '194.0.0.0/12', '212.0.0.0/12', '217.0.0.0/13'],
            'GB': ['2.16.0.0/12', '5.62.0.0/16', '81.0.0.0/8', '82.0.0.0/9', '86.0.0.0/7', '88.96.0.0/11',
                   '90.192.0.0/11', '151.224.0.0/11', '158.152.0.0/13', '193.0.0.0/12', '194.0.0.0/13',
                   '195.0.0.0/13', '212.0.0.0/13', '213.0.0.0/13'],
            'FR': ['5.135.0.0/16', '37.59.0.0/16', '46.105.0.0/16', '51.68.0.0/14', '78.192.0.0/10', '80.64.0.0/12',
                   '81.48.0.0/12', '82.224.0.0/11', '85.16.0.0/12', '88.160.0.0/11', '90.0.0.0/11', '92.222.0.0/16',
                   '141.94.0.0/16', '151.80.0.0/12', '176.31.0.0/16', '193.0.0.0/12', '194.0.0.0/13'],
            'JP': ['1.0.16.0/20', '14.8.0.0/13', '27.133.0.0/16', '58.88.0.0/13', '61.112.0.0/12', '118.0.0.0/8',
                   '119.224.0.0/11', '121.0.0.0/8', '122.0.0.0/7', '124.0.0.0/8', '125.0.0.0/8', '126.0.0.0/8',
                   '133.0.0.0/8', '153.0.0.0/8', '160.0.0.0/8', '163.0.0.0/8', '202.0.0.0/8', '210.0.0.0/8'],
            'KR': ['1.11.0.0/16', '14.63.0.0/16', '27.1.0.0/16', '58.120.0.0/13', '59.16.0.0/12', '61.72.0.0/13',
                   '110.70.0.0/15', '112.160.0.0/11', '115.68.0.0/14', '117.16.0.0/12', '118.219.0.0/16',
                   '119.192.0.0/10', '121.128.0.0/10', '175.192.0.0/10', '183.96.0.0/11', '203.224.0.0/11']
        };

        const ranges = fallbackRanges[countryUpper];
        if (!ranges) {
            logger.warn(`No fallback ranges available for country: ${countryUpper}`);
            return [];
        }

        logger.info(`Using fallback ranges for ${countryUpper}: ${ranges.length} ranges`);
        return ranges;
    }

    async listBlockedCountries() {
        const blocks = await this.loadGeoBlocks();
        const countries = {};

        for (const block of blocks) {
            if (!countries[block.country]) {
                countries[block.country] = {
                    code: block.country,
                    name: this.getCountryName(block.country),
                    blockedAt: block.createdAt,
                    ipRanges: []
                };
            }
            countries[block.country].ipRanges.push(...block.ipRanges);
        }

        return Object.values(countries);
    }

    getCountryName(code) {
        const countryNames = {
            'CN': 'China',
            'RU': 'Russia',
            'KP': 'North Korea',
            'IR': 'Iran',
            'US': 'United States',
            'BR': 'Brazil',
            'IN': 'India',
            'DE': 'Germany',
            'GB': 'United Kingdom',
            'FR': 'France',
            'JP': 'Japan',
            'KR': 'South Korea',
            'AU': 'Australia',
            'CA': 'Canada',
            'IT': 'Italy',
            'ES': 'Spain',
            'NL': 'Netherlands',
            'SE': 'Sweden',
            'NO': 'Norway',
            'FI': 'Finland'
        };

        return countryNames[code] || code;
    }

    async checkIP(ip) {
        let countryCode = 'Unknown';
        let countryName = 'Unknown';

        if (this.mmdbReader) {
            try {
                const result = this.mmdbReader.get(ip);
                if (result && result.country) {
                    countryCode = result.country.iso_code || 'Unknown';
                    countryName = result.country.names?.en || countryCode;
                }
            } catch (error) {
                logger.error(`Failed to lookup IP ${ip}`, error);
            }
        }

        const blocks = await this.loadGeoBlocks();
        const isBlocked = blocks.some(b => b.country === countryCode);

        return {
            ip: ip,
            country: countryCode,
            countryName: countryName,
            blocked: isBlocked
        };
    }

    async saveGeoBlock(block) {
        const blocks = await this.loadGeoBlocks();
        blocks.push(block);
        await fs.writeJson(this.geoDbPath, blocks);
        return block;
    }

    async loadGeoBlocks() {
        try {
            if (await fs.pathExists(this.geoDbPath)) {
                return await fs.readJson(this.geoDbPath);
            }
        } catch (error) {
            console.error('Failed to load geo blocks', error);
        }
        return [];
    }

    async updateGeoDatabase() {
        logger.info('Updating GeoIP database...');
        try {
            // Clear existing country data cache
            this.countryData = {};

            // Download fresh data
            const success = await this.downloadGeoDatabase();

            if (success) {
                // Clear all cached country files to force refresh
                const cacheFiles = await fs.readdir(this.ipListsPath);
                for (const file of cacheFiles) {
                    if (file.endsWith('.json') && file.length === 7) { // Country code files
                        await fs.remove(path.join(this.ipListsPath, file));
                    }
                }

                logger.info('GeoIP database updated successfully');
                return true;
            } else {
                logger.error('Failed to update GeoIP database');
                return false;
            }
        } catch (error) {
            logger.error('Error updating GeoIP database', error);
            return false;
        }
    }

    async getGeoStats() {
        try {
            const blocks = await this.loadGeoBlocks();
            const ipsets = [];

            // Get ipset information
            try {
                const { stdout } = await execAsync('ipset list -n');
                const allIpsets = stdout.split('\n').filter(name => name.startsWith(this.ipsetPrefix));

                for (const ipsetName of allIpsets) {
                    try {
                        const { stdout: info } = await execAsync(`ipset list ${ipsetName} | head -10`);
                        const lines = info.split('\n');
                        const sizeMatch = lines.find(line => line.includes('Number of entries:'));
                        const size = sizeMatch ? parseInt(sizeMatch.split(':')[1].trim()) : 0;

                        ipsets.push({
                            name: ipsetName,
                            country: ipsetName.replace(`${this.ipsetPrefix}-`, '').toUpperCase(),
                            entries: size
                        });
                    } catch (error) {
                        // Skip this ipset if we can't get info
                    }
                }
            } catch (error) {
                logger.warn('Could not get ipset information');
            }

            return {
                blockedCountries: blocks.length,
                totalBlocks: blocks.reduce((sum, block) => sum + (block.rulesAdded || 0), 0),
                ipsets: ipsets,
                mmdbAvailable: !!this.mmdbReader,
                countryDataLoaded: Object.keys(this.countryData).length > 0
            };
        } catch (error) {
            logger.error('Failed to get geo stats', error);
            return {
                blockedCountries: 0,
                totalBlocks: 0,
                ipsets: [],
                mmdbAvailable: false,
                countryDataLoaded: false
            };
        }
    }
}

module.exports = GeoBlocker;