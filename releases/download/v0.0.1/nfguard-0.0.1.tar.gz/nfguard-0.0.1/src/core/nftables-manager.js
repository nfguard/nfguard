const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class NFTablesManager {
    constructor() {
        this.rulesPath = process.env.NFGUARD_RULES_PATH || '/etc/nfguard/rules.json';
        this.nftablesConfig = process.env.NFGUARD_CONFIG_PATH || '/etc/nfguard/nftables.conf';
        this.validDirections = new Set(['input', 'output', 'forward']);
        this.validActions = new Set(['accept', 'drop', 'reject']);
        this.validPortProtocols = new Set(['tcp', 'udp']);
        this.ensureDirectories();
    }

    ensureDirectories() {
        const rulesDir = path.dirname(this.rulesPath);
        fs.ensureDirSync(rulesDir);
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    logger.error(`NFTables command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    logger.info(`NFTables command executed: ${command}`, { stdout: stdout.trim() });
                    resolve({ stdout, stderr });
                }
            });
        });
    }

    normalizeRuleInput(rule) {
        if (!rule || typeof rule !== 'object') {
            throw new Error('Invalid rule payload');
        }

        const normalized = {
            type: (rule.type || '').toLowerCase(),
            direction: (rule.direction || 'input').toLowerCase(),
            protocol: rule.protocol ? String(rule.protocol).toLowerCase() : undefined,
            port: rule.port !== undefined && rule.port !== null && rule.port !== '' ? String(rule.port).trim() : undefined,
            source: rule.source ? String(rule.source).trim() : undefined,
            destination: rule.destination ? String(rule.destination).trim() : undefined,
            action: (rule.action || '').toLowerCase()
        };

        if (!this.validDirections.has(normalized.direction)) {
            throw new Error(`Invalid direction: ${rule.direction || 'undefined'}`);
        }

        if (!this.validActions.has(normalized.action)) {
            throw new Error(`Unsupported action: ${rule.action || 'undefined'}`);
        }

        switch (normalized.type) {
            case 'port':
                if (!normalized.protocol || normalized.protocol === 'icmp') {
                    normalized.protocol = 'tcp';
                }

                if (!this.validPortProtocols.has(normalized.protocol)) {
                    throw new Error(`Invalid protocol for port rule: ${normalized.protocol}`);
                }

                if (!normalized.port) {
                    throw new Error('Port is required for port rules');
                }

                if (!this.isValidPort(normalized.port)) {
                    throw new Error(`Invalid port value: ${normalized.port}`);
                }
                break;

            case 'ip':
            case 'network':
                if (!normalized.source && !normalized.destination) {
                    throw new Error('Source or destination is required for IP and network rules');
                }
                normalized.protocol = undefined;
                normalized.port = undefined;
                break;

            case 'icmp':
                normalized.protocol = 'icmp';
                normalized.port = undefined;
                break;

            default:
                throw new Error(`Unsupported rule type: ${normalized.type || 'undefined'}`);
        }

        return normalized;
    }

    isValidPort(value) {
        if (/^\d+$/.test(value)) {
            const port = parseInt(value, 10);
            return port >= 1 && port <= 65535;
        }

        const rangeMatch = value.match(/^(\d+)-(\d+)$/);
        if (rangeMatch) {
            const start = parseInt(rangeMatch[1], 10);
            const end = parseInt(rangeMatch[2], 10);
            return start >= 1 && end <= 65535 && start <= end;
        }

        return false;
    }

    buildRuleCommand(rule) {
        const parts = ['nft', 'add', 'rule', 'inet', 'nfguard', rule.direction];

        if (rule.type === 'port') {
            parts.push(rule.protocol, 'dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('ip', 'saddr', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('icmp', 'type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('ip', 'saddr', rule.source);
        }

        if (rule.type === 'icmp' && rule.source) {
            parts.push('ip', 'saddr', rule.source);
        }

        if (rule.destination) {
            parts.push('ip', 'daddr', rule.destination);
        }

        parts.push('counter', rule.action);
        return parts.join(' ');
    }

    async initializeNFTables() {
        try {
            await this.executeCommand('nft flush ruleset');
            await this.executeCommand('nft add table inet nfguard');
            await this.executeCommand('nft add chain inet nfguard input { type filter hook input priority 0\\; policy accept\\; }');
            await this.executeCommand('nft add chain inet nfguard forward { type filter hook forward priority 0\\; policy drop\\; }');
            await this.executeCommand('nft add chain inet nfguard output { type filter hook output priority 0\\; policy accept\\; }');

            await this.executeCommand('nft add rule inet nfguard input iif lo accept');
            await this.executeCommand('nft add rule inet nfguard input ct state established,related accept');
            await this.executeCommand('nft add rule inet nfguard input tcp dport 22 accept');
            await this.executeCommand('nft add rule inet nfguard input tcp dport 8443 accept');
            await this.executeCommand('nft add rule inet nfguard input ct state invalid drop');

            logger.info('NFTables initialized successfully');
            return true;
        } catch (error) {
            logger.error('Failed to initialize NFTables', error);
            throw error;
        }
    }

    async addRule(rule, user = 'system') {
        const normalizedRule = this.normalizeRuleInput(rule);
        const command = this.buildRuleCommand(normalizedRule);

        logger.audit('ADD_RULE', user, {
            rule: normalizedRule,
            timestamp: new Date().toISOString()
        });

        try {
            logger.info(`Executing NFTables command: ${command}`);
            await this.executeCommand(command);
            const storedRule = await this.saveRule(normalizedRule);
            logger.info(`Rule added successfully: ${storedRule.type} ${storedRule.protocol || ''} ${storedRule.port || ''}`);
            return storedRule;
        } catch (error) {
            logger.error(`Failed to add rule: ${command}`, error);
            throw new Error(`Failed to add firewall rule: ${error.message}`);
        }
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        const handle = await this.getRuleHandle(rule);
        if (handle) {
            await this.executeCommand(`nft delete rule inet nfguard ${rule.direction} handle ${handle}`);
        }

        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules, { spaces: 2 });

        return true;
    }

    async getRuleHandle(rule) {
        try {
            const { stdout } = await this.executeCommand(`nft -a list chain inet nfguard ${rule.direction}`);
            const lines = stdout.split('\n');

            for (const line of lines) {
                if (!this.lineMatchesRule(line, rule)) {
                    continue;
                }

                const match = line.match(/handle (\d+)/);
                if (match) {
                    return match[1];
                }
            }
        } catch (error) {
            logger.error('Failed to get rule handle', error);
        }
        return null;
    }

    lineMatchesRule(line, rule) {
        if (!line.includes(rule.action)) {
            return false;
        }

        if (rule.type === 'icmp' && !line.includes('icmp type echo-request')) {
            return false;
        }

        if (rule.port && !line.includes(`dport ${rule.port}`)) {
            return false;
        }

        if (rule.source && !line.includes(`saddr ${rule.source}`)) {
            return false;
        }

        if (rule.destination && !line.includes(`daddr ${rule.destination}`)) {
            return false;
        }

        if (rule.protocol && !line.includes(rule.protocol)) {
            return false;
        }

        return true;
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];

        try {
            const { stdout } = await this.executeCommand('nft list ruleset');
            activeRules.push(...this.parseNFTablesOutput(stdout));
        } catch (error) {
            logger.error('Failed to list NFTables rules', error);
        }

        return {
            saved: rules,
            active: activeRules
        };
    }

    parseNFTablesOutput(output) {
        const rules = [];
        const lines = output.split('\n');

        for (const line of lines) {
            if (line.includes('accept') || line.includes('drop') || line.includes('reject')) {
                rules.push(line.trim());
            }
        }

        return rules;
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        const storedRule = {
            ...rule,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        rules.push(storedRule);
        await fs.writeJson(this.rulesPath, rules, { spaces: 2 });
        return storedRule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        const { stdout } = await this.executeCommand('nft list ruleset');
        return stdout;
    }

    async importRules(config) {
        const tempFile = '/tmp/nfguard-import.conf';
        await fs.writeFile(tempFile, config);
        await this.executeCommand(`nft -f ${tempFile}`);
        await fs.remove(tempFile);
        return true;
    }

    async flushRules() {
        await this.executeCommand('nft flush ruleset');
        await this.initializeNFTables();
        return true;
    }

    async getStatistics() {
        try {
            const { stdout } = await this.executeCommand('nft list counters');
            return this.parseStatistics(stdout);
        } catch (error) {
            logger.error('Failed to get statistics', error);
            return {};
        }
    }

    parseStatistics(output) {
        const stats = {
            packets: 0,
            bytes: 0,
            rules: 0
        };

        const lines = output.split('\n');
        for (const line of lines) {
            if (line.includes('packets')) {
                const match = line.match(/packets (\d+) bytes (\d+)/);
                if (match) {
                    stats.packets += parseInt(match[1], 10);
                    stats.bytes += parseInt(match[2], 10);
                }
            }
        }

        return stats;
    }
}

module.exports = NFTablesManager;