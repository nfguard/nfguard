const { exec, execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class NFTablesManager {
    constructor() {
        this.rulesPath = '/etc/nfguard/rules.json';
        this.nftablesConfig = '/etc/nfguard/nftables.conf';
        this.ensureDirectories();
    }

    ensureDirectories() {
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    logger.error(`NFTables command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    logger.info(`NFTables command executed: ${command}`, { stdout: stdout.trim() });
                    resolve({ stdout, stderr });
                }
            });
        });
    }

    async initializeNFTables() {
        const baseConfig = `#!/usr/sbin/nft -f
flush ruleset

table inet nfguard {
    chain input {
        type filter hook input priority 0; policy drop;

        # Allow loopback
        iif lo accept

        # Allow established connections
        ct state established,related accept

        # Allow SSH (default)
        tcp dport 22 accept

        # Allow WebGUI
        tcp dport 8443 accept

        # Drop invalid connections
        ct state invalid drop
    }

    chain forward {
        type filter hook forward priority 0; policy drop;
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }

    chain prerouting {
        type nat hook prerouting priority -100;
    }

    chain postrouting {
        type nat hook postrouting priority 100;
    }
}`;

        await fs.writeFile(this.nftablesConfig, baseConfig);
        await this.executeCommand('nft -f ' + this.nftablesConfig);
        return true;
    }

    async addRule(rule, user = 'system') {
        const { type, direction, protocol, port, source, destination, action } = rule;
        let nftCommand = '';

        logger.audit('ADD_RULE', user, {
            rule: rule,
            timestamp: new Date().toISOString()
        });

        switch(type) {
            case 'port':
                if (direction === 'input') {
                    nftCommand = `nft add rule inet nfguard input ${protocol} dport ${port}`;
                    if (source) nftCommand += ` ip saddr ${source}`;
                    nftCommand += ` ${action}`;
                } else if (direction === 'output') {
                    nftCommand = `nft add rule inet nfguard output ${protocol} dport ${port}`;
                    if (destination) nftCommand += ` ip daddr ${destination}`;
                    nftCommand += ` ${action}`;
                }
                break;

            case 'ip':
                if (direction === 'input') {
                    nftCommand = `nft add rule inet nfguard input ip saddr ${source} ${action}`;
                } else if (direction === 'output') {
                    nftCommand = `nft add rule inet nfguard output ip daddr ${destination} ${action}`;
                }
                break;

            case 'network':
                if (direction === 'input') {
                    nftCommand = `nft add rule inet nfguard input ip saddr ${source} ${action}`;
                } else if (direction === 'output') {
                    nftCommand = `nft add rule inet nfguard output ip daddr ${destination} ${action}`;
                }
                break;
        }

        if (nftCommand) {
            await this.executeCommand(nftCommand);
            await this.saveRule(rule);
            return true;
        }

        return false;
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        const handle = await this.getRuleHandle(rule);
        if (handle) {
            await this.executeCommand(`nft delete rule inet nfguard ${rule.direction} handle ${handle}`);
        }

        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules);

        return true;
    }

    async getRuleHandle(rule) {
        try {
            const { stdout } = await this.executeCommand(`nft -a list chain inet nfguard ${rule.direction}`);
            const lines = stdout.split('\n');

            for (const line of lines) {
                if (line.includes(rule.port) || line.includes(rule.source) || line.includes(rule.destination)) {
                    const match = line.match(/handle (\d+)/);
                    if (match) {
                        return match[1];
                    }
                }
            }
        } catch (error) {
            logger.error('Failed to get rule handle', error);
        }
        return null;
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];

        try {
            const { stdout } = await this.executeCommand('nft list ruleset');
            activeRules.push(...this.parseNFTablesOutput(stdout));
        } catch (error) {
            logger.error('Failed to list NFTables rules', error);
        }

        return {
            saved: rules,
            active: activeRules
        };
    }

    parseNFTablesOutput(output) {
        const rules = [];
        const lines = output.split('\n');

        for (const line of lines) {
            if (line.includes('accept') || line.includes('drop') || line.includes('reject')) {
                rules.push(line.trim());
            }
        }

        return rules;
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        rule.id = Date.now().toString();
        rule.createdAt = new Date().toISOString();
        rules.push(rule);
        await fs.writeJson(this.rulesPath, rules);
        return rule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        const { stdout } = await this.executeCommand('nft list ruleset');
        return stdout;
    }

    async importRules(config) {
        const tempFile = '/tmp/nfguard-import.conf';
        await fs.writeFile(tempFile, config);
        await this.executeCommand(`nft -f ${tempFile}`);
        await fs.remove(tempFile);
        return true;
    }

    async flushRules() {
        await this.executeCommand('nft flush ruleset');
        await this.initializeNFTables();
        return true;
    }

    async getStatistics() {
        try {
            const { stdout } = await this.executeCommand('nft list counters');
            return this.parseStatistics(stdout);
        } catch (error) {
            logger.error('Failed to get statistics', error);
            return {};
        }
    }

    parseStatistics(output) {
        const stats = {
            packets: 0,
            bytes: 0,
            rules: 0
        };

        const lines = output.split('\n');
        for (const line of lines) {
            if (line.includes('packets')) {
                const match = line.match(/packets (\d+) bytes (\d+)/);
                if (match) {
                    stats.packets += parseInt(match[1]);
                    stats.bytes += parseInt(match[2]);
                }
            }
        }

        return stats;
    }
}

module.exports = NFTablesManager;