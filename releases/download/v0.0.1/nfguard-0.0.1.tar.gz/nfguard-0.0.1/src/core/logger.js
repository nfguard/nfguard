const winston = require('winston');
const fs = require('fs-extra');

class Logger {
    constructor() {
        this.ensureLogDirectory();
        this.logger = this.createLogger();
        this.auditLogger = this.createAuditLogger();
    }

    ensureLogDirectory() {
        fs.ensureDirSync('/var/log/nfguard');
    }

    createLogger() {
        return winston.createLogger({
            level: 'info',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.errors({ stack: true }),
                winston.format.json()
            ),
            transports: [
                new winston.transports.File({
                    filename: '/var/log/nfguard/error.log',
                    level: 'error',
                    maxsize: 5242880, // 5MB
                    maxFiles: 5
                }),
                new winston.transports.File({
                    filename: '/var/log/nfguard/combined.log',
                    maxsize: 5242880, // 5MB
                    maxFiles: 5
                }),
                new winston.transports.Console({
                    format: winston.format.combine(
                        winston.format.colorize(),
                        winston.format.simple()
                    )
                })
            ]
        });
    }

    createAuditLogger() {
        return winston.createLogger({
            level: 'info',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.json()
            ),
            transports: [
                new winston.transports.File({
                    filename: '/var/log/nfguard/audit.log',
                    maxsize: 5242880, // 5MB
                    maxFiles: 5
                })
            ]
        });
    }

    info(message, meta = {}) {
        this.logger.info(message, meta);
    }

    error(message, meta = {}) {
        this.logger.error(message, meta);
    }

    warn(message, meta = {}) {
        this.logger.warn(message, meta);
    }

    debug(message, meta = {}) {
        this.logger.debug(message, meta);
    }

    audit(action, user, details = {}) {
        this.auditLogger.info('AUDIT', {
            action,
            user,
            timestamp: new Date().toISOString(),
            details
        });
    }

    async getRecentLogs(lines = 100) {
        try {
            const logFile = '/var/log/nfguard/combined.log';
            if (await fs.pathExists(logFile)) {
                const content = await fs.readFile(logFile, 'utf8');
                return content.split('\n').slice(-lines).filter(line => line.trim());
            }
            return [];
        } catch (error) {
            this.error('Failed to read logs', { error: error.message });
            return [];
        }
    }

    async getAuditLogs(lines = 100) {
        try {
            const auditFile = '/var/log/nfguard/audit.log';
            if (await fs.pathExists(auditFile)) {
                const content = await fs.readFile(auditFile, 'utf8');
                return content.split('\n').slice(-lines).filter(line => line.trim()).map(line => {
                    try {
                        return JSON.parse(line);
                    } catch {
                        return { message: line };
                    }
                });
            }
            return [];
        } catch (error) {
            this.error('Failed to read audit logs', { error: error.message });
            return [];
        }
    }
}

module.exports = new Logger();