const fs = require('fs-extra');
const path = require('path');
const { execSync, exec } = require('child_process');
const { promisify } = require('util');
const logger = require('./logger');
const execAsync = promisify(exec);

class Updater {
    constructor() {
        this.currentVersion = '0.0.1';
        this.versionUrl = 'https://raw.githubusercontent.com/nfguard/nfguard/refs/heads/main/releases/download/version.txt';
        this.updateDir = '/tmp/nfguard-update';
        this.backupDir = '/etc/nfguard/backups';
        this.installDir = process.cwd();
    }

    async checkForUpdate() {
        try {
            logger.info('Checking for updates...');

            // Fetch version information using https module
            const https = require('https');
            const versionText = await new Promise((resolve, reject) => {
                https.get(this.versionUrl, (res) => {
                    let data = '';
                    res.on('data', chunk => data += chunk);
                    res.on('end', () => resolve(data));
                }).on('error', reject);
            });
            const lines = versionText.trim().split('\n');

            if (lines.length < 2) {
                throw new Error('Invalid version file format');
            }

            const versionLine = lines[0];
            const downloadUrl = lines[1];

            const versionMatch = versionLine.match(/version=(.+)/);
            if (!versionMatch) {
                throw new Error('Cannot parse version from version file');
            }

            const latestVersion = versionMatch[1];

            logger.info(`Current version: ${this.currentVersion}`);
            logger.info(`Latest version: ${latestVersion}`);

            const updateAvailable = this.compareVersions(this.currentVersion, latestVersion) < 0;

            return {
                updateAvailable,
                currentVersion: this.currentVersion,
                latestVersion,
                downloadUrl: updateAvailable ? downloadUrl : null
            };
        } catch (error) {
            logger.error('Failed to check for updates', error);
            throw error;
        }
    }

    compareVersions(version1, version2) {
        const v1Parts = version1.split('.').map(Number);
        const v2Parts = version2.split('.').map(Number);

        for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
            const v1Part = v1Parts[i] || 0;
            const v2Part = v2Parts[i] || 0;

            if (v1Part < v2Part) return -1;
            if (v1Part > v2Part) return 1;
        }

        return 0;
    }

    async downloadUpdate(downloadUrl) {
        try {
            logger.info(`Downloading update from: ${downloadUrl}`);

            // Clean update directory
            await fs.remove(this.updateDir);
            await fs.ensureDir(this.updateDir);

            const fileName = path.basename(downloadUrl);
            const filePath = path.join(this.updateDir, fileName);

            // Download the file using https module
            const https = require('https');
            const fileStream = fs.createWriteStream(filePath);

            await new Promise((resolve, reject) => {
                https.get(downloadUrl, (response) => {
                    if (response.statusCode === 302 || response.statusCode === 301) {
                        // Handle redirect
                        https.get(response.headers.location, (redirectResponse) => {
                            redirectResponse.pipe(fileStream);
                            fileStream.on('finish', () => {
                                fileStream.close();
                                resolve();
                            });
                        }).on('error', reject);
                    } else {
                        response.pipe(fileStream);
                        fileStream.on('finish', () => {
                            fileStream.close();
                            resolve();
                        });
                    }
                }).on('error', reject);
            });

            logger.info(`Downloaded update to: ${filePath}`);
            return filePath;
        } catch (error) {
            logger.error('Failed to download update', error);
            throw error;
        }
    }

    async createBackup() {
        try {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupName = `pre-update-${timestamp}`;
            const backupPath = path.join(this.backupDir, backupName);

            logger.info(`Creating backup: ${backupName}`);

            await fs.ensureDir(this.backupDir);
            await fs.ensureDir(backupPath);

            // Backup configuration files
            const configFiles = [
                '/etc/nfguard/config.json',
                '/etc/nfguard/users.json',
                '/etc/nfguard/geo-blocks.json'
            ];

            for (const configFile of configFiles) {
                if (await fs.pathExists(configFile)) {
                    const fileName = path.basename(configFile);
                    await fs.copy(configFile, path.join(backupPath, fileName));
                }
            }

            // Backup current application
            const excludeDirs = ['node_modules', '.git', 'logs'];
            const tarCommand = `tar --exclude='${excludeDirs.join("' --exclude='")}' -czf ${backupPath}/nfguard-app.tar.gz -C ${path.dirname(this.installDir)} ${path.basename(this.installDir)}`;

            await execAsync(tarCommand);

            logger.info(`Backup created successfully: ${backupPath}`);
            return backupPath;
        } catch (error) {
            logger.error('Failed to create backup', error);
            throw error;
        }
    }

    async extractUpdate(updateFilePath) {
        try {
            logger.info(`Extracting update: ${updateFilePath}`);

            const extractDir = path.join(this.updateDir, 'extracted');
            await fs.ensureDir(extractDir);

            // Extract the tar.gz file
            await execAsync(`tar -xzf "${updateFilePath}" -C "${extractDir}"`);

            // Find the extracted directory
            const contents = await fs.readdir(extractDir);
            const extractedDir = contents.find(item => item.startsWith('nfguard-'));

            if (!extractedDir) {
                throw new Error('Could not find extracted NFGuard directory');
            }

            const fullExtractedPath = path.join(extractDir, extractedDir);
            logger.info(`Update extracted to: ${fullExtractedPath}`);

            return fullExtractedPath;
        } catch (error) {
            logger.error('Failed to extract update', error);
            throw error;
        }
    }

    async applyUpdate(extractedPath) {
        try {
            logger.info('Applying update...');

            // Stop the service
            logger.info('Stopping NFGuard service...');
            try {
                await execAsync('systemctl stop nfguard');
            } catch (error) {
                logger.warn('Could not stop service via systemctl, continuing...');
            }

            // Install dependencies
            logger.info('Installing dependencies...');
            await execAsync(`cd "${extractedPath}" && npm install --production`);

            // Backup current files and replace with new ones
            const filesToUpdate = [
                'src/',
                'web/',
                'package.json',
                'nfguard.service',
                'DOCUMENTATION.md'
            ];

            for (const file of filesToUpdate) {
                const sourcePath = path.join(extractedPath, file);
                const destPath = path.join(this.installDir, file);

                if (await fs.pathExists(sourcePath)) {
                    // Remove old file/directory
                    if (await fs.pathExists(destPath)) {
                        await fs.remove(destPath);
                    }

                    // Copy new file/directory
                    await fs.copy(sourcePath, destPath);
                    logger.info(`Updated: ${file}`);
                }
            }

            // Update systemd service if needed
            const serviceSource = path.join(extractedPath, 'nfguard.service');
            if (await fs.pathExists(serviceSource)) {
                await fs.copy(serviceSource, '/etc/systemd/system/nfguard.service');
                await execAsync('systemctl daemon-reload');
                logger.info('Updated systemd service');
            }

            // Update CLI link
            try {
                await execAsync(`cd "${this.installDir}" && npm link`);
                logger.info('Updated CLI link');
            } catch (error) {
                logger.warn('Could not update CLI link:', error.message);
            }

            // Start the service
            logger.info('Starting NFGuard service...');
            await execAsync('systemctl start nfguard');

            logger.info('Update applied successfully!');
            return true;
        } catch (error) {
            logger.error('Failed to apply update', error);
            throw error;
        }
    }

    async rollback(backupPath) {
        try {
            logger.info(`Rolling back to backup: ${backupPath}`);

            // Stop service
            try {
                await execAsync('systemctl stop nfguard');
            } catch (error) {
                logger.warn('Could not stop service');
            }

            // Restore application
            const appBackup = path.join(backupPath, 'nfguard-app.tar.gz');
            if (await fs.pathExists(appBackup)) {
                await execAsync(`tar -xzf "${appBackup}" -C "${path.dirname(this.installDir)}"`);
            }

            // Restore configuration files
            const configFiles = ['config.json', 'users.json', 'geo-blocks.json'];
            for (const configFile of configFiles) {
                const backupFile = path.join(backupPath, configFile);
                if (await fs.pathExists(backupFile)) {
                    await fs.copy(backupFile, path.join('/etc/nfguard', configFile));
                }
            }

            // Start service
            await execAsync('systemctl start nfguard');

            logger.info('Rollback completed successfully');
            return true;
        } catch (error) {
            logger.error('Failed to rollback', error);
            throw error;
        }
    }

    async performUpdate() {
        let backupPath = null;

        try {
            // Check for updates
            const updateInfo = await this.checkForUpdate();

            if (!updateInfo.updateAvailable) {
                logger.info('No updates available');
                return {
                    success: true,
                    message: 'No updates available',
                    currentVersion: updateInfo.currentVersion,
                    latestVersion: updateInfo.latestVersion
                };
            }

            logger.info(`Update available: ${updateInfo.latestVersion}`);

            // Create backup
            backupPath = await this.createBackup();

            // Download update
            const updateFilePath = await this.downloadUpdate(updateInfo.downloadUrl);

            // Extract update
            const extractedPath = await this.extractUpdate(updateFilePath);

            // Apply update
            await this.applyUpdate(extractedPath);

            // Cleanup
            await fs.remove(this.updateDir);

            logger.info(`Successfully updated to version ${updateInfo.latestVersion}`);

            return {
                success: true,
                message: `Successfully updated to version ${updateInfo.latestVersion}`,
                previousVersion: updateInfo.currentVersion,
                newVersion: updateInfo.latestVersion,
                backupPath
            };

        } catch (error) {
            logger.error('Update failed', error);

            // Attempt rollback if we have a backup
            if (backupPath) {
                try {
                    await this.rollback(backupPath);
                    logger.info('Rollback completed after failed update');
                } catch (rollbackError) {
                    logger.error('Rollback also failed', rollbackError);
                }
            }

            throw error;
        }
    }

    async getUpdateStatus() {
        try {
            const updateInfo = await this.checkForUpdate();
            return {
                currentVersion: updateInfo.currentVersion,
                latestVersion: updateInfo.latestVersion,
                updateAvailable: updateInfo.updateAvailable,
                downloadUrl: updateInfo.downloadUrl
            };
        } catch (error) {
            return {
                currentVersion: this.currentVersion,
                latestVersion: 'Unknown',
                updateAvailable: false,
                error: error.message
            };
        }
    }
}

module.exports = Updater;