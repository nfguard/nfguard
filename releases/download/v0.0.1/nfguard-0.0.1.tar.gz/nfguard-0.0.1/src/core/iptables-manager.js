const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class IPTablesManager {
    constructor() {
        this.rulesPath = process.env.NFGUARD_RULES_PATH || '/etc/nfguard/rules.json';
        this.validDirections = new Set(['input', 'output', 'forward']);
        this.validActions = new Set(['accept', 'drop', 'reject']);
        this.validPortProtocols = new Set(['tcp', 'udp']);
        this.ensureDirectories();
    }

    ensureDirectories() {
        const rulesDir = path.dirname(this.rulesPath);
        fs.ensureDirSync(rulesDir);
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    logger.error(`IPTables command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    logger.info(`IPTables command executed: ${command}`, { stdout: stdout.trim() });
                    resolve({ stdout, stderr });
                }
            });
        });
    }

    normalizeRuleInput(rule) {
        if (!rule || typeof rule !== 'object') {
            throw new Error('Invalid rule payload');
        }

        const normalized = {
            type: (rule.type || '').toLowerCase(),
            direction: (rule.direction || 'input').toLowerCase(),
            protocol: rule.protocol ? String(rule.protocol).toLowerCase() : undefined,
            port: rule.port !== undefined && rule.port !== null && rule.port !== '' ? String(rule.port).trim() : undefined,
            source: rule.source ? String(rule.source).trim() : undefined,
            destination: rule.destination ? String(rule.destination).trim() : undefined,
            action: (rule.action || '').toLowerCase()
        };

        if (!this.validDirections.has(normalized.direction)) {
            throw new Error(`Invalid direction: ${rule.direction || 'undefined'}`);
        }

        if (!this.validActions.has(normalized.action)) {
            throw new Error(`Unsupported action: ${rule.action || 'undefined'}`);
        }

        // Convert action to iptables format
        if (normalized.action === 'accept') {
            normalized.action = 'ACCEPT';
        } else if (normalized.action === 'drop') {
            normalized.action = 'DROP';
        } else if (normalized.action === 'reject') {
            normalized.action = 'REJECT';
        }

        switch (normalized.type) {
            case 'port':
                if (!normalized.protocol || normalized.protocol === 'icmp') {
                    normalized.protocol = 'tcp';
                }

                if (!this.validPortProtocols.has(normalized.protocol)) {
                    throw new Error(`Invalid protocol for port rule: ${normalized.protocol}`);
                }

                if (!normalized.port) {
                    throw new Error('Port is required for port rules');
                }

                if (!this.isValidPort(normalized.port)) {
                    throw new Error(`Invalid port value: ${normalized.port}`);
                }
                break;

            case 'ip':
            case 'network':
                if (!normalized.source && !normalized.destination) {
                    throw new Error('Source or destination is required for IP and network rules');
                }
                normalized.protocol = undefined;
                normalized.port = undefined;
                break;

            case 'icmp':
                normalized.protocol = 'icmp';
                normalized.port = undefined;
                break;

            default:
                throw new Error(`Unsupported rule type: ${normalized.type || 'undefined'}`);
        }

        return normalized;
    }

    isValidPort(value) {
        if (/^\d+$/.test(value)) {
            const port = parseInt(value, 10);
            return port >= 1 && port <= 65535;
        }

        const rangeMatch = value.match(/^(\d+)-(\d+)$/);
        if (rangeMatch) {
            const start = parseInt(rangeMatch[1], 10);
            const end = parseInt(rangeMatch[2], 10);
            return start >= 1 && end <= 65535 && start <= end;
        }

        return false;
    }

    buildRuleCommand(rule) {
        // Use custom NFGUARD chains instead of default chains
        const chain = `NFGUARD-${rule.direction.toUpperCase()}`;
        const parts = ['iptables', '-A', chain];

        if (rule.type === 'port') {
            parts.push('-p', rule.protocol);
            parts.push('--dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('-s', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('-p', 'icmp');
            parts.push('--icmp-type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.type === 'icmp' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.destination) {
            parts.push('-d', rule.destination);
        }

        parts.push('-j', rule.action);
        return parts.join(' ');
    }

    async initializeIPTables() {
        try {
            // Create basic chains if they don't exist
            await this.executeCommand('iptables -t filter -N NFGUARD-INPUT 2>/dev/null || true');
            await this.executeCommand('iptables -t filter -N NFGUARD-OUTPUT 2>/dev/null || true');
            await this.executeCommand('iptables -t filter -N NFGUARD-FORWARD 2>/dev/null || true');

            // IMPORTANT: Insert jump rules at the beginning of chains (position 1)
            // This ensures our rules are evaluated before any other rules
            await this.executeCommand('iptables -C INPUT -j NFGUARD-INPUT 2>/dev/null || iptables -I INPUT 1 -j NFGUARD-INPUT');
            await this.executeCommand('iptables -C OUTPUT -j NFGUARD-OUTPUT 2>/dev/null || iptables -I OUTPUT 1 -j NFGUARD-OUTPUT');
            await this.executeCommand('iptables -C FORWARD -j NFGUARD-FORWARD 2>/dev/null || iptables -I FORWARD 1 -j NFGUARD-FORWARD');

            // Add essential rules to INPUT chain - order matters!
            // 1. Allow loopback (most important)
            await this.executeCommand('iptables -C NFGUARD-INPUT -i lo -j ACCEPT 2>/dev/null || iptables -I NFGUARD-INPUT 1 -i lo -j ACCEPT');

            // 2. Allow established connections (second most important)
            await this.executeCommand('iptables -C NFGUARD-INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || iptables -I NFGUARD-INPUT 2 -m state --state ESTABLISHED,RELATED -j ACCEPT');

            // 3. Allow SSH (management access)
            await this.executeCommand('iptables -C NFGUARD-INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null || iptables -A NFGUARD-INPUT -p tcp --dport 22 -j ACCEPT');

            // 4. Allow NFGuard WebGUI
            await this.executeCommand('iptables -C NFGUARD-INPUT -p tcp --dport 8443 -j ACCEPT 2>/dev/null || iptables -A NFGUARD-INPUT -p tcp --dport 8443 -j ACCEPT');

            logger.info('IPTables initialized successfully with proper rule ordering');
            return true;
        } catch (error) {
            logger.error('Failed to initialize IPTables', error);
            throw error;
        }
    }

    async addRule(rule, user = 'system') {
        const normalizedRule = this.normalizeRuleInput(rule);

        // Ensure chains exist before adding rules
        await this.initializeIPTables();

        const command = this.buildRuleCommand(normalizedRule);

        logger.audit('ADD_RULE', user, {
            rule: normalizedRule,
            command: command,
            timestamp: new Date().toISOString()
        });

        try {
            logger.info(`Executing IPTables command: ${command}`);
            await this.executeCommand(command);
            const storedRule = await this.saveRule(normalizedRule);
            logger.info(`Rule added successfully to NFGUARD chain: ${storedRule.type} ${storedRule.protocol || ''} ${storedRule.port || ''}`);
            return storedRule;
        } catch (error) {
            logger.error(`Failed to add rule: ${command}`, error);
            throw new Error(`Failed to add firewall rule: ${error.message}`);
        }
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        try {
            const deleteCommand = this.buildDeleteCommand(rule);
            await this.executeCommand(deleteCommand);
        } catch (error) {
            logger.error(`Failed to delete rule from iptables`, error);
        }

        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules, { spaces: 2 });

        return true;
    }

    buildDeleteCommand(rule) {
        // Use custom NFGUARD chains instead of default chains
        const chain = `NFGUARD-${rule.direction.toUpperCase()}`;
        const parts = ['iptables', '-D', chain];

        if (rule.type === 'port') {
            parts.push('-p', rule.protocol);
            parts.push('--dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('-s', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('-p', 'icmp');
            parts.push('--icmp-type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.type === 'icmp' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.destination) {
            parts.push('-d', rule.destination);
        }

        parts.push('-j', rule.action);
        return parts.join(' ');
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];
        const systemRules = [];

        try {
            // Get all iptables rules including system rules
            const { stdout } = await this.executeCommand('iptables -L -n -v --line-numbers');
            const allRules = this.parseIPTablesOutput(stdout);

            // Separate NFGUARD rules from system rules
            allRules.forEach(rule => {
                if (rule.includes('NFGUARD')) {
                    activeRules.push(rule);
                } else {
                    systemRules.push(rule);
                }
            });

            // Also get NFGUARD chain rules specifically
            try {
                const { stdout: nfInput } = await this.executeCommand('iptables -L NFGUARD-INPUT -n -v --line-numbers 2>/dev/null || true');
                const { stdout: nfOutput } = await this.executeCommand('iptables -L NFGUARD-OUTPUT -n -v --line-numbers 2>/dev/null || true');
                const { stdout: nfForward } = await this.executeCommand('iptables -L NFGUARD-FORWARD -n -v --line-numbers 2>/dev/null || true');

                if (nfInput) activeRules.push(...this.parseIPTablesOutput(nfInput));
                if (nfOutput) activeRules.push(...this.parseIPTablesOutput(nfOutput));
                if (nfForward) activeRules.push(...this.parseIPTablesOutput(nfForward));
            } catch (e) {
                // Ignore errors for missing chains
            }
        } catch (error) {
            logger.error('Failed to list IPTables rules', error);
        }

        return {
            saved: rules,
            active: activeRules,
            system: systemRules
        };
    }

    parseIPTablesOutput(output) {
        const rules = [];
        const lines = output.split('\n');
        let inChain = false;
        let currentChain = '';

        for (const line of lines) {
            // Detect chain headers
            if (line.startsWith('Chain')) {
                const match = line.match(/Chain\s+(\S+)/);
                if (match) {
                    currentChain = match[1];
                    inChain = true;
                }
                continue;
            }

            // Skip header lines
            if (line.includes('pkts bytes') || line.trim() === '') {
                continue;
            }

            // Parse rule lines
            if (inChain && (line.includes('ACCEPT') || line.includes('DROP') || line.includes('REJECT') || line.includes('NFGUARD'))) {
                const trimmed = line.trim();
                if (trimmed && trimmed.length > 0) {
                    // Add chain name to rule for clarity
                    rules.push(`[${currentChain}] ${trimmed}`);
                }
            }
        }

        return rules;
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        const storedRule = {
            ...rule,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        rules.push(storedRule);
        await fs.writeJson(this.rulesPath, rules, { spaces: 2 });
        return storedRule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        const { stdout } = await this.executeCommand('iptables-save');
        return stdout;
    }

    async importRules(config) {
        const tempFile = '/tmp/nfguard-import.rules';
        await fs.writeFile(tempFile, config);
        await this.executeCommand(`iptables-restore < ${tempFile}`);
        await fs.remove(tempFile);
        return true;
    }

    async flushRules() {
        // Flush only NFGUARD chains, preserve system rules
        await this.executeCommand('iptables -F NFGUARD-INPUT 2>/dev/null || true');
        await this.executeCommand('iptables -F NFGUARD-OUTPUT 2>/dev/null || true');
        await this.executeCommand('iptables -F NFGUARD-FORWARD 2>/dev/null || true');

        // Clear saved rules
        await fs.writeJson(this.rulesPath, [], { spaces: 2 });

        // Re-initialize with base rules
        await this.initializeIPTables();

        logger.info('All NFGUARD rules flushed, base rules restored');
        return true;
    }

    async getStatistics() {
        try {
            // Get statistics from all chains including NFGUARD chains
            const { stdout: mainStats } = await this.executeCommand('iptables -L -n -v -x');
            const { stdout: nfStats } = await this.executeCommand('iptables -L NFGUARD-INPUT -n -v -x 2>/dev/null || echo ""');

            const combined = mainStats + '\n' + nfStats;
            return this.parseStatistics(combined);
        } catch (error) {
            logger.error('Failed to get statistics', error);
            return {};
        }
    }

    parseStatistics(output) {
        const stats = {
            packets: 0,
            bytes: 0,
            rules: 0
        };

        const lines = output.split('\n');
        for (const line of lines) {
            const match = line.match(/^\s*(\d+)\s+(\d+)/);
            if (match) {
                stats.packets += parseInt(match[1], 10);
                stats.bytes += parseInt(match[2], 10);
                stats.rules++;
            }
        }

        return stats;
    }
}

module.exports = IPTablesManager;