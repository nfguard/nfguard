const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const logger = require('./logger');

class IPTablesManager {
    constructor() {
        this.rulesPath = process.env.NFGUARD_RULES_PATH || '/etc/nfguard/rules.json';
        this.validDirections = new Set(['input', 'output', 'forward']);
        this.validActions = new Set(['accept', 'drop', 'reject']);
        this.validPortProtocols = new Set(['tcp', 'udp']);
        this.ensureDirectories();
    }

    ensureDirectories() {
        const rulesDir = path.dirname(this.rulesPath);
        fs.ensureDirSync(rulesDir);
        fs.ensureDirSync('/etc/nfguard');
        fs.ensureDirSync('/var/log/nfguard');
    }

    async executeCommand(command) {
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    logger.error(`IPTables command failed: ${command}`, { error: error.message, stderr });
                    reject(error);
                } else {
                    logger.info(`IPTables command executed: ${command}`, { stdout: stdout.trim() });
                    resolve({ stdout, stderr });
                }
            });
        });
    }

    normalizeRuleInput(rule) {
        if (!rule || typeof rule !== 'object') {
            throw new Error('Invalid rule payload');
        }

        const normalized = {
            type: (rule.type || '').toLowerCase(),
            direction: (rule.direction || 'input').toLowerCase(),
            protocol: rule.protocol ? String(rule.protocol).toLowerCase() : undefined,
            port: rule.port !== undefined && rule.port !== null && rule.port !== '' ? String(rule.port).trim() : undefined,
            source: rule.source ? String(rule.source).trim() : undefined,
            destination: rule.destination ? String(rule.destination).trim() : undefined,
            action: (rule.action || '').toLowerCase()
        };

        if (!this.validDirections.has(normalized.direction)) {
            throw new Error(`Invalid direction: ${rule.direction || 'undefined'}`);
        }

        if (!this.validActions.has(normalized.action)) {
            throw new Error(`Unsupported action: ${rule.action || 'undefined'}`);
        }

        // Convert action to iptables format
        if (normalized.action === 'accept') {
            normalized.action = 'ACCEPT';
        } else if (normalized.action === 'drop') {
            normalized.action = 'DROP';
        } else if (normalized.action === 'reject') {
            normalized.action = 'REJECT';
        }

        switch (normalized.type) {
            case 'port':
                if (!normalized.protocol || normalized.protocol === 'icmp') {
                    normalized.protocol = 'tcp';
                }

                if (!this.validPortProtocols.has(normalized.protocol)) {
                    throw new Error(`Invalid protocol for port rule: ${normalized.protocol}`);
                }

                if (!normalized.port) {
                    throw new Error('Port is required for port rules');
                }

                if (!this.isValidPort(normalized.port)) {
                    throw new Error(`Invalid port value: ${normalized.port}`);
                }
                break;

            case 'ip':
            case 'network':
                if (!normalized.source && !normalized.destination) {
                    throw new Error('Source or destination is required for IP and network rules');
                }
                normalized.protocol = undefined;
                normalized.port = undefined;
                break;

            case 'icmp':
                normalized.protocol = 'icmp';
                normalized.port = undefined;
                break;

            default:
                throw new Error(`Unsupported rule type: ${normalized.type || 'undefined'}`);
        }

        return normalized;
    }

    isValidPort(value) {
        if (/^\d+$/.test(value)) {
            const port = parseInt(value, 10);
            return port >= 1 && port <= 65535;
        }

        const rangeMatch = value.match(/^(\d+)-(\d+)$/);
        if (rangeMatch) {
            const start = parseInt(rangeMatch[1], 10);
            const end = parseInt(rangeMatch[2], 10);
            return start >= 1 && end <= 65535 && start <= end;
        }

        return false;
    }

    buildRuleCommand(rule) {
        const chain = `NFGUARD-${rule.direction.toUpperCase()}`;
        // Insert rule before the RETURN statement (second to last position)
        const parts = ['iptables', '-I', chain];

        if (rule.type === 'port') {
            parts.push('-p', rule.protocol);
            parts.push('--dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('-s', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('-p', 'icmp');
            parts.push('--icmp-type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.type === 'icmp' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.destination) {
            parts.push('-d', rule.destination);
        }

        parts.push('-j', rule.action);

        // Calculate position to insert before RETURN rule
        const insertPosition = this.getInsertPosition(chain);
        if (insertPosition > 0) {
            parts.splice(2, 0, insertPosition.toString());
        }

        return parts.join(' ');
    }

    async getInsertPosition(chain) {
        try {
            const { stdout } = await this.executeCommand(`iptables -L ${chain} -n --line-numbers`);
            const lines = stdout.split('\n');
            let lastRuleNumber = 0;

            for (const line of lines) {
                if (line.includes('RETURN')) {
                    const match = line.match(/^(\d+)/);
                    if (match) {
                        return parseInt(match[1]);
                    }
                }
                const match = line.match(/^(\d+)/);
                if (match) {
                    lastRuleNumber = parseInt(match[1]);
                }
            }

            // If no RETURN rule found, insert at the end
            return lastRuleNumber + 1;
        } catch (error) {
            logger.error('Failed to get insert position', error);
            return 0; // Default to append
        }
    }

    async initializeIPTables() {
        try {
            // Create basic chains if they don't exist
            await this.executeCommand('iptables -t filter -N NFGUARD-INPUT 2>/dev/null || true');
            await this.executeCommand('iptables -t filter -N NFGUARD-OUTPUT 2>/dev/null || true');
            await this.executeCommand('iptables -t filter -N NFGUARD-FORWARD 2>/dev/null || true');

            // Remove existing jump rules and re-add them at the beginning
            await this.executeCommand('iptables -D INPUT -j NFGUARD-INPUT 2>/dev/null || true');
            await this.executeCommand('iptables -D OUTPUT -j NFGUARD-OUTPUT 2>/dev/null || true');
            await this.executeCommand('iptables -D FORWARD -j NFGUARD-FORWARD 2>/dev/null || true');

            // Add jump rules to our custom chains at the beginning
            await this.executeCommand('iptables -I INPUT 1 -j NFGUARD-INPUT');
            await this.executeCommand('iptables -I OUTPUT 1 -j NFGUARD-OUTPUT');
            await this.executeCommand('iptables -I FORWARD 1 -j NFGUARD-FORWARD');

            // Clear existing rules in our chains
            await this.executeCommand('iptables -F NFGUARD-INPUT');
            await this.executeCommand('iptables -F NFGUARD-OUTPUT');
            await this.executeCommand('iptables -F NFGUARD-FORWARD');

            // Add essential rules to INPUT chain in correct order
            await this.executeCommand('iptables -A NFGUARD-INPUT -i lo -j ACCEPT');
            await this.executeCommand('iptables -A NFGUARD-INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT');

            // Get current SSH port from environment or default to 22
            const sshPort = process.env.SSH_PORT || '22';
            await this.executeCommand(`iptables -A NFGUARD-INPUT -p tcp --dport ${sshPort} -j ACCEPT`);
            await this.executeCommand('iptables -A NFGUARD-INPUT -p tcp --dport 8443 -j ACCEPT');

            // Add return rule at the end to go back to main chain
            await this.executeCommand('iptables -A NFGUARD-INPUT -j RETURN');
            await this.executeCommand('iptables -A NFGUARD-OUTPUT -j RETURN');
            await this.executeCommand('iptables -A NFGUARD-FORWARD -j RETURN');

            logger.info('IPTables initialized successfully with correct rule order');
            return true;
        } catch (error) {
            logger.error('Failed to initialize IPTables', error);
            throw error;
        }
    }

    async addRule(rule, user = 'system') {
        const normalizedRule = this.normalizeRuleInput(rule);

        logger.audit('ADD_RULE', user, {
            rule: normalizedRule,
            timestamp: new Date().toISOString()
        });

        try {
            // Get the insert position first
            const chain = `NFGUARD-${normalizedRule.direction.toUpperCase()}`;
            const insertPosition = await this.getInsertPosition(chain);

            // Build command with correct position
            const parts = ['iptables', '-I', chain];
            if (insertPosition > 0) {
                parts.push(insertPosition.toString());
            }

            if (normalizedRule.type === 'port') {
                parts.push('-p', normalizedRule.protocol);
                parts.push('--dport', normalizedRule.port);
            } else if (normalizedRule.type === 'ip' || normalizedRule.type === 'network') {
                if (normalizedRule.source) {
                    parts.push('-s', normalizedRule.source);
                }
            } else if (normalizedRule.type === 'icmp') {
                parts.push('-p', 'icmp');
                parts.push('--icmp-type', 'echo-request');
            }

            if (normalizedRule.type === 'port' && normalizedRule.source) {
                parts.push('-s', normalizedRule.source);
            }

            if (normalizedRule.type === 'icmp' && normalizedRule.source) {
                parts.push('-s', normalizedRule.source);
            }

            if (normalizedRule.destination) {
                parts.push('-d', normalizedRule.destination);
            }

            parts.push('-j', normalizedRule.action);

            const command = parts.join(' ');
            logger.info(`Executing IPTables command: ${command}`);
            await this.executeCommand(command);

            const storedRule = await this.saveRule(normalizedRule);
            logger.info(`Rule added successfully: ${storedRule.type} ${storedRule.protocol || ''} ${storedRule.port || ''}`);
            return storedRule;
        } catch (error) {
            logger.error(`Failed to add rule`, error);
            throw new Error(`Failed to add firewall rule: ${error.message}`);
        }
    }

    async deleteRule(ruleId, user = 'system') {
        const rules = await this.loadRules();
        const rule = rules.find(r => r.id === ruleId);

        if (!rule) {
            throw new Error('Rule not found');
        }

        logger.audit('DELETE_RULE', user, {
            ruleId: ruleId,
            rule: rule,
            timestamp: new Date().toISOString()
        });

        try {
            const deleteCommand = this.buildDeleteCommand(rule);
            await this.executeCommand(deleteCommand);
        } catch (error) {
            logger.error(`Failed to delete rule from iptables`, error);
        }

        const updatedRules = rules.filter(r => r.id !== ruleId);
        await fs.writeJson(this.rulesPath, updatedRules, { spaces: 2 });

        return true;
    }

    buildDeleteCommand(rule) {
        const chain = rule.direction.toUpperCase();
        const parts = ['iptables', '-D', chain];

        if (rule.type === 'port') {
            parts.push('-p', rule.protocol);
            parts.push('--dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('-s', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('-p', 'icmp');
            parts.push('--icmp-type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.type === 'icmp' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.destination) {
            parts.push('-d', rule.destination);
        }

        parts.push('-j', rule.action);
        return parts.join(' ');
    }

    async listRules() {
        const rules = await this.loadRules();
        const activeRules = [];

        try {
            const { stdout } = await this.executeCommand('iptables -L -n -v --line-numbers');
            activeRules.push(...this.parseIPTablesOutput(stdout));
        } catch (error) {
            logger.error('Failed to list IPTables rules', error);
        }

        return {
            saved: rules,
            active: activeRules
        };
    }

    parseIPTablesOutput(output) {
        const rules = [];
        const lines = output.split('\n');

        for (const line of lines) {
            if (line.includes('ACCEPT') || line.includes('DROP') || line.includes('REJECT')) {
                rules.push(line.trim());
            }
        }

        return rules;
    }

    async saveRule(rule) {
        const rules = await this.loadRules();
        const storedRule = {
            ...rule,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        rules.push(storedRule);
        await fs.writeJson(this.rulesPath, rules, { spaces: 2 });
        return storedRule;
    }

    async loadRules() {
        try {
            if (await fs.pathExists(this.rulesPath)) {
                return await fs.readJson(this.rulesPath);
            }
        } catch (error) {
            logger.error('Failed to load rules', error);
        }
        return [];
    }

    async exportRules() {
        const { stdout } = await this.executeCommand('iptables-save');
        return stdout;
    }

    async importRules(config) {
        const tempFile = '/tmp/nfguard-import.rules';
        await fs.writeFile(tempFile, config);
        await this.executeCommand(`iptables-restore < ${tempFile}`);
        await fs.remove(tempFile);
        return true;
    }

    async flushRules() {
        await this.executeCommand('iptables -F NFGUARD-INPUT');
        await this.executeCommand('iptables -F NFGUARD-OUTPUT');
        await this.executeCommand('iptables -F NFGUARD-FORWARD');

        // Clear saved rules
        await fs.writeJson(this.rulesPath, []);

        await this.initializeIPTables();
        logger.info('All firewall rules flushed and reinitialized');
        return true;
    }

    async loadDefaultRules() {
        try {
            // Clear current rules first
            await this.flushRules();

            // Load only essential default rules
            logger.info('Default firewall rules loaded');
            return true;
        } catch (error) {
            logger.error('Failed to load default rules', error);
            throw error;
        }
    }

    async enableFirewall() {
        try {
            // Ensure chains exist and are properly linked
            await this.initializeIPTables();
            logger.info('Firewall enabled');
            return true;
        } catch (error) {
            logger.error('Failed to enable firewall', error);
            throw error;
        }
    }

    async disableFirewall() {
        try {
            // Remove jump rules to effectively disable our firewall
            await this.executeCommand('iptables -D INPUT -j NFGUARD-INPUT 2>/dev/null || true');
            await this.executeCommand('iptables -D OUTPUT -j NFGUARD-OUTPUT 2>/dev/null || true');
            await this.executeCommand('iptables -D FORWARD -j NFGUARD-FORWARD 2>/dev/null || true');

            logger.info('Firewall disabled');
            return true;
        } catch (error) {
            logger.error('Failed to disable firewall', error);
            throw error;
        }
    }

    async restartFirewall() {
        try {
            await this.disableFirewall();
            await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
            await this.enableFirewall();

            // Reload saved rules
            const savedRules = await this.loadRules();
            for (const rule of savedRules) {
                try {
                    await this.addRuleToIPTables(rule);
                } catch (error) {
                    logger.error(`Failed to restore rule ${rule.id}`, error);
                }
            }

            logger.info('Firewall restarted successfully');
            return true;
        } catch (error) {
            logger.error('Failed to restart firewall', error);
            throw error;
        }
    }

    async addRuleToIPTables(rule) {
        const chain = `NFGUARD-${rule.direction.toUpperCase()}`;
        const insertPosition = await this.getInsertPosition(chain);

        const parts = ['iptables', '-I', chain];
        if (insertPosition > 0) {
            parts.push(insertPosition.toString());
        }

        if (rule.type === 'port') {
            parts.push('-p', rule.protocol);
            parts.push('--dport', rule.port);
        } else if (rule.type === 'ip' || rule.type === 'network') {
            if (rule.source) {
                parts.push('-s', rule.source);
            }
        } else if (rule.type === 'icmp') {
            parts.push('-p', 'icmp');
            parts.push('--icmp-type', 'echo-request');
        }

        if (rule.type === 'port' && rule.source) {
            parts.push('-s', rule.source);
        }

        if (rule.destination) {
            parts.push('-d', rule.destination);
        }

        parts.push('-j', rule.action);

        const command = parts.join(' ');
        await this.executeCommand(command);
    }

    async restrictWebGUIAccess(allowedIP) {
        try {
            // Remove existing WebGUI rules
            await this.executeCommand('iptables -D NFGUARD-INPUT -p tcp --dport 8443 -j ACCEPT 2>/dev/null || true');

            if (allowedIP && allowedIP !== 'any') {
                // Add specific IP restriction
                const insertPos = await this.getInsertPosition('NFGUARD-INPUT');
                await this.executeCommand(`iptables -I NFGUARD-INPUT ${insertPos} -p tcp --dport 8443 -s ${allowedIP} -j ACCEPT`);
                await this.executeCommand(`iptables -I NFGUARD-INPUT ${insertPos + 1} -p tcp --dport 8443 -j DROP`);
                logger.info(`WebGUI access restricted to IP: ${allowedIP}`);
            } else {
                // Allow from any IP
                const insertPos = await this.getInsertPosition('NFGUARD-INPUT');
                await this.executeCommand(`iptables -I NFGUARD-INPUT ${insertPos} -p tcp --dport 8443 -j ACCEPT`);
                logger.info('WebGUI access allowed from any IP');
            }

            return true;
        } catch (error) {
            logger.error('Failed to restrict WebGUI access', error);
            throw error;
        }
    }

    async getStatistics() {
        try {
            const { stdout } = await this.executeCommand('iptables -L -n -v');
            return this.parseStatistics(stdout);
        } catch (error) {
            logger.error('Failed to get statistics', error);
            return {};
        }
    }

    parseStatistics(output) {
        const stats = {
            packets: 0,
            bytes: 0,
            rules: 0
        };

        const lines = output.split('\n');
        for (const line of lines) {
            const match = line.match(/^\s*(\d+)\s+(\d+)/);
            if (match) {
                stats.packets += parseInt(match[1], 10);
                stats.bytes += parseInt(match[2], 10);
                stats.rules++;
            }
        }

        return stats;
    }
}

module.exports = IPTablesManager;