const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs-extra');
const crypto = require('crypto');

class AuthManager {
    constructor() {
        this.usersFile = '/etc/nfguard/users.json';
        this.secretFile = '/etc/nfguard/.secret';
        this.saltRounds = 10;
        this.ensureDirectories();
        this.initializeSecret();
        this.initializeDefaultUser();
    }

    ensureDirectories() {
        fs.ensureDirSync('/etc/nfguard');
    }

    async initializeSecret() {
        try {
            if (!await fs.pathExists(this.secretFile)) {
                const secret = crypto.randomBytes(64).toString('hex');
                await fs.writeFile(this.secretFile, secret, { mode: 0o600 });
            }
            this.jwtSecret = await fs.readFile(this.secretFile, 'utf8');
        } catch (error) {
            this.jwtSecret = process.env.JWT_SECRET || 'nfguard-secret-key-change-in-production';
        }
    }

    async initializeDefaultUser() {
        try {
            if (!await fs.pathExists(this.usersFile)) {
                const defaultUser = {
                    id: '1',
                    username: 'nfguard',
                    password: await bcrypt.hash('nfguard', this.saltRounds),
                    role: 'admin',
                    createdAt: new Date().toISOString(),
                    lastLogin: null,
                    isDefault: true
                };

                await fs.writeJson(this.usersFile, { users: [defaultUser] }, { mode: 0o600 });
            }
        } catch (error) {
            console.error('Failed to initialize default user:', error);
        }
    }

    async authenticate(username, password) {
        try {
            const data = await fs.readJson(this.usersFile);
            const user = data.users.find(u => u.username === username);

            if (!user) {
                return { success: false, message: 'Invalid credentials' };
            }

            const isValid = await bcrypt.compare(password, user.password);

            if (!isValid) {
                return { success: false, message: 'Invalid credentials' };
            }

            user.lastLogin = new Date().toISOString();
            await fs.writeJson(this.usersFile, data);

            const token = jwt.sign(
                {
                    id: user.id,
                    username: user.username,
                    role: user.role
                },
                this.jwtSecret,
                { expiresIn: '24h' }
            );

            return {
                success: true,
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    role: user.role,
                    isDefault: user.isDefault
                }
            };
        } catch (error) {
            console.error('Authentication error:', error);
            return { success: false, message: 'Authentication failed' };
        }
    }

    async verifyToken(token) {
        try {
            const decoded = jwt.verify(token, this.jwtSecret);
            return { valid: true, user: decoded };
        } catch (error) {
            return { valid: false, message: 'Invalid or expired token' };
        }
    }

    async changePassword(userId, currentPassword, newPassword) {
        try {
            const data = await fs.readJson(this.usersFile);
            const user = data.users.find(u => u.id === userId);

            if (!user) {
                return { success: false, message: 'User not found' };
            }

            const isValid = await bcrypt.compare(currentPassword, user.password);

            if (!isValid) {
                return { success: false, message: 'Current password is incorrect' };
            }

            user.password = await bcrypt.hash(newPassword, this.saltRounds);
            user.isDefault = false;
            user.updatedAt = new Date().toISOString();

            await fs.writeJson(this.usersFile, data);

            return { success: true, message: 'Password changed successfully' };
        } catch (error) {
            console.error('Password change error:', error);
            return { success: false, message: 'Failed to change password' };
        }
    }

    async changeUsername(userId, newUsername, password) {
        try {
            const data = await fs.readJson(this.usersFile);
            const user = data.users.find(u => u.id === userId);

            if (!user) {
                return { success: false, message: 'User not found' };
            }

            const isValid = await bcrypt.compare(password, user.password);

            if (!isValid) {
                return { success: false, message: 'Password is incorrect' };
            }

            const usernameExists = data.users.some(u => u.username === newUsername && u.id !== userId);

            if (usernameExists) {
                return { success: false, message: 'Username already exists' };
            }

            user.username = newUsername;
            user.isDefault = false;
            user.updatedAt = new Date().toISOString();

            await fs.writeJson(this.usersFile, data);

            return { success: true, message: 'Username changed successfully' };
        } catch (error) {
            console.error('Username change error:', error);
            return { success: false, message: 'Failed to change username' };
        }
    }

    async createUser(username, password, role = 'viewer') {
        try {
            const data = await fs.readJson(this.usersFile);

            const userExists = data.users.some(u => u.username === username);

            if (userExists) {
                return { success: false, message: 'Username already exists' };
            }

            const newUser = {
                id: Date.now().toString(),
                username,
                password: await bcrypt.hash(password, this.saltRounds),
                role,
                createdAt: new Date().toISOString(),
                lastLogin: null,
                isDefault: false
            };

            data.users.push(newUser);
            await fs.writeJson(this.usersFile, data);

            return { success: true, user: { id: newUser.id, username: newUser.username, role: newUser.role } };
        } catch (error) {
            console.error('User creation error:', error);
            return { success: false, message: 'Failed to create user' };
        }
    }

    async deleteUser(userId) {
        try {
            const data = await fs.readJson(this.usersFile);
            const userIndex = data.users.findIndex(u => u.id === userId);

            if (userIndex === -1) {
                return { success: false, message: 'User not found' };
            }

            if (data.users[userIndex].username === 'nfguard' && data.users.length === 1) {
                return { success: false, message: 'Cannot delete the last admin user' };
            }

            data.users.splice(userIndex, 1);
            await fs.writeJson(this.usersFile, data);

            return { success: true, message: 'User deleted successfully' };
        } catch (error) {
            console.error('User deletion error:', error);
            return { success: false, message: 'Failed to delete user' };
        }
    }

    async listUsers() {
        try {
            const data = await fs.readJson(this.usersFile);
            return data.users.map(u => ({
                id: u.id,
                username: u.username,
                role: u.role,
                createdAt: u.createdAt,
                lastLogin: u.lastLogin,
                isDefault: u.isDefault
            }));
        } catch (error) {
            console.error('Failed to list users:', error);
            return [];
        }
    }

    async refreshToken(token) {
        try {
            const decoded = jwt.verify(token, this.jwtSecret, { ignoreExpiration: true });

            const newToken = jwt.sign(
                {
                    id: decoded.id,
                    username: decoded.username,
                    role: decoded.role
                },
                this.jwtSecret,
                { expiresIn: '24h' }
            );

            return { success: true, token: newToken };
        } catch (error) {
            return { success: false, message: 'Failed to refresh token' };
        }
    }
}

module.exports = AuthManager;