const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs-extra');
const crypto = require('crypto');

class AuthManager {
    constructor() {
        this.usersFile = '/etc/nfguard/users.json';
        this.secretFile = '/etc/nfguard/.secret';
        this.saltRounds = 10;
        this.initializeSync();
    }

    initializeSync() {
        // Ensure directories exist
        fs.ensureDirSync('/etc/nfguard', { mode: 0o755 });
        fs.ensureDirSync('/var/log/nfguard', { mode: 0o755 });

        // Initialize JWT secret synchronously
        this.initializeSecretSync();

        // Initialize default user synchronously
        this.initializeDefaultUserSync();
    }

    initializeSecretSync() {
        try {
            if (!fs.pathExistsSync(this.secretFile)) {
                const secret = crypto.randomBytes(64).toString('hex');
                fs.writeFileSync(this.secretFile, secret, { mode: 0o600 });
                this.jwtSecret = secret;
            } else {
                this.jwtSecret = fs.readFileSync(this.secretFile, 'utf8');
            }
        } catch (error) {
            console.error('Failed to initialize JWT secret:', error);
            this.jwtSecret = 'nfguard-fallback-secret-' + Date.now();
        }
    }

    initializeDefaultUserSync() {
        try {
            if (!fs.pathExistsSync(this.usersFile)) {
                const hashedPassword = bcrypt.hashSync('nfguard', this.saltRounds);
                const defaultUser = {
                    id: '1',
                    username: 'nfguard',
                    password: hashedPassword,
                    role: 'admin',
                    createdAt: new Date().toISOString(),
                    lastLogin: null,
                    isDefault: true
                };

                fs.writeJsonSync(this.usersFile, { users: [defaultUser] }, {
                    spaces: 2,
                    mode: 0o600
                });

                console.log('✓ Default user created: nfguard/nfguard');
                console.log('  Login with username: nfguard');
                console.log('  Login with password: nfguard');
            }
        } catch (error) {
            console.error('Failed to initialize default user:', error);
        }
    }

    async authenticate(username, password) {
        try {
            console.log(`AuthManager: Attempting authentication for user: ${username}`);

            if (!fs.pathExistsSync(this.usersFile)) {
                console.error('AuthManager: Users file does not exist');
                return { success: false, message: 'Authentication system not initialized' };
            }

            const data = await fs.readJson(this.usersFile);
            console.log(`AuthManager: Found ${data.users?.length || 0} users in system`);

            const user = data.users.find(u => u.username === username);

            if (!user) {
                console.log(`AuthManager: User ${username} not found`);
                return { success: false, message: 'Invalid credentials' };
            }

            console.log(`AuthManager: User ${username} found, checking password`);
            const isValid = await bcrypt.compare(password, user.password);

            if (!isValid) {
                console.log(`AuthManager: Invalid password for user ${username}`);
                return { success: false, message: 'Invalid credentials' };
            }

            console.log(`AuthManager: Authentication successful for user ${username}`);

            // Update last login
            user.lastLogin = new Date().toISOString();
            const userIndex = data.users.findIndex(u => u.username === username);
            if (userIndex >= 0) {
                data.users[userIndex] = user;
                await fs.writeJson(this.usersFile, data, { spaces: 2 });
            }

            const token = jwt.sign(
                {
                    id: user.id,
                    username: user.username,
                    role: user.role
                },
                this.jwtSecret,
                { expiresIn: '24h' }
            );

            return {
                success: true,
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    role: user.role,
                    isDefault: user.isDefault
                }
            };
        } catch (error) {
            console.error('AuthManager: Authentication error:', error);
            return { success: false, message: 'Authentication failed' };
        }
    }

    async verifyToken(token) {
        try {
            const decoded = jwt.verify(token, this.jwtSecret);
            return { valid: true, user: decoded };
        } catch (error) {
            return { valid: false, message: 'Invalid or expired token' };
        }
    }

    async changePassword(userId, currentPassword, newPassword) {
        try {
            const data = await fs.readJson(this.usersFile);
            const user = data.users.find(u => u.id === userId);

            if (!user) {
                return { success: false, message: 'User not found' };
            }

            const isValid = await bcrypt.compare(currentPassword, user.password);

            if (!isValid) {
                return { success: false, message: 'Current password is incorrect' };
            }

            user.password = await bcrypt.hash(newPassword, this.saltRounds);
            user.isDefault = false;
            user.updatedAt = new Date().toISOString();

            await fs.writeJson(this.usersFile, data, { spaces: 2 });

            return { success: true, message: 'Password changed successfully' };
        } catch (error) {
            console.error('Password change error:', error);
            return { success: false, message: 'Failed to change password' };
        }
    }

    async changeUsername(userId, newUsername, password) {
        try {
            const data = await fs.readJson(this.usersFile);
            const user = data.users.find(u => u.id === userId);

            if (!user) {
                return { success: false, message: 'User not found' };
            }

            const isValid = await bcrypt.compare(password, user.password);

            if (!isValid) {
                return { success: false, message: 'Password is incorrect' };
            }

            const usernameExists = data.users.some(u => u.username === newUsername && u.id !== userId);

            if (usernameExists) {
                return { success: false, message: 'Username already exists' };
            }

            user.username = newUsername;
            user.isDefault = false;
            user.updatedAt = new Date().toISOString();

            await fs.writeJson(this.usersFile, data, { spaces: 2 });

            return { success: true, message: 'Username changed successfully' };
        } catch (error) {
            console.error('Username change error:', error);
            return { success: false, message: 'Failed to change username' };
        }
    }

    async createUser(username, password, role = 'viewer') {
        try {
            const data = await fs.readJson(this.usersFile);

            const userExists = data.users.some(u => u.username === username);

            if (userExists) {
                return { success: false, message: 'Username already exists' };
            }

            const newUser = {
                id: Date.now().toString(),
                username,
                password: await bcrypt.hash(password, this.saltRounds),
                role,
                createdAt: new Date().toISOString(),
                lastLogin: null,
                isDefault: false
            };

            data.users.push(newUser);
            await fs.writeJson(this.usersFile, data, { spaces: 2 });

            return { success: true, user: { id: newUser.id, username: newUser.username, role: newUser.role } };
        } catch (error) {
            console.error('User creation error:', error);
            return { success: false, message: 'Failed to create user' };
        }
    }

    async deleteUser(userId) {
        try {
            const data = await fs.readJson(this.usersFile);
            const userIndex = data.users.findIndex(u => u.id === userId);

            if (userIndex === -1) {
                return { success: false, message: 'User not found' };
            }

            if (data.users[userIndex].username === 'nfguard' && data.users.length === 1) {
                return { success: false, message: 'Cannot delete the last admin user' };
            }

            data.users.splice(userIndex, 1);
            await fs.writeJson(this.usersFile, data, { spaces: 2 });

            return { success: true, message: 'User deleted successfully' };
        } catch (error) {
            console.error('User deletion error:', error);
            return { success: false, message: 'Failed to delete user' };
        }
    }

    async listUsers() {
        try {
            const data = await fs.readJson(this.usersFile);
            return data.users.map(u => ({
                id: u.id,
                username: u.username,
                role: u.role,
                createdAt: u.createdAt,
                lastLogin: u.lastLogin,
                isDefault: u.isDefault
            }));
        } catch (error) {
            console.error('Failed to list users:', error);
            return [];
        }
    }

    async refreshToken(token) {
        try {
            const decoded = jwt.verify(token, this.jwtSecret, { ignoreExpiration: true });

            const newToken = jwt.sign(
                {
                    id: decoded.id,
                    username: decoded.username,
                    role: decoded.role
                },
                this.jwtSecret,
                { expiresIn: '24h' }
            );

            return { success: true, token: newToken };
        } catch (error) {
            return { success: false, message: 'Failed to refresh token' };
        }
    }
}

module.exports = AuthManager;