const express = require('express');
const https = require('https');
const fs = require('fs-extra');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const session = require('express-session');

const IPTablesManager = require('./core/iptables-manager');
const GeoBlocker = require('./core/geo-blocker');
const AuthManager = require('./auth/auth-manager');
const logger = require('./core/logger');

const app = express();
const PORT = process.env.PORT || 8443;

const iptables = new IPTablesManager();
const geoBlocker = new GeoBlocker(iptables);
const authManager = new AuthManager();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: process.env.SESSION_SECRET || 'nfguard-session-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: true, maxAge: 24 * 60 * 60 * 1000 }
}));

app.use(express.static(path.join(__dirname, '../web')));

const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Authentication required' });
    }

    const result = await authManager.verifyToken(token);

    if (!result.valid) {
        return res.status(403).json({ error: result.message });
    }

    req.user = result.user;
    next();
};

app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    const result = await authManager.authenticate(username, password);

    if (result.success) {
        res.json({
            success: true,
            token: result.token,
            user: result.user
        });
    } else {
        res.status(401).json({ success: false, message: result.message });
    }
});

app.post('/api/auth/refresh', authenticateToken, async (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    const result = await authManager.refreshToken(token);

    if (result.success) {
        res.json({ success: true, token: result.token });
    } else {
        res.status(401).json({ success: false, message: result.message });
    }
});

app.post('/api/auth/logout', authenticateToken, (req, res) => {
    res.json({ success: true, message: 'Logged out successfully' });
});

app.get('/api/auth/profile', authenticateToken, async (req, res) => {
    res.json({ success: true, user: req.user });
});

app.post('/api/auth/change-password', authenticateToken, async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const result = await authManager.changePassword(req.user.id, currentPassword, newPassword);
    res.json(result);
});

app.post('/api/auth/change-username', authenticateToken, async (req, res) => {
    const { newUsername, password } = req.body;
    const result = await authManager.changeUsername(req.user.id, newUsername, password);
    res.json(result);
});

app.get('/api/users', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    const users = await authManager.listUsers();
    res.json({ success: true, users });
});

app.post('/api/users', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    const { username, password, role } = req.body;
    const result = await authManager.createUser(username, password, role);
    res.json(result);
});

app.delete('/api/users/:userId', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    const result = await authManager.deleteUser(req.params.userId);
    res.json(result);
});

app.get('/api/rules', authenticateToken, async (req, res) => {
    try {
        const rules = await iptables.listRules();
        res.json({ success: true, rules });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/rules', authenticateToken, async (req, res) => {
    try {
        const rule = req.body;
        await iptables.addRule(rule, req.user.username);
        res.json({ success: true, message: 'Rule added successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.delete('/api/rules/:ruleId', authenticateToken, async (req, res) => {
    try {
        await iptables.deleteRule(req.params.ruleId, req.user.username);
        res.json({ success: true, message: 'Rule deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/rules/flush', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    try {
        await iptables.flushRules();
        res.json({ success: true, message: 'All rules flushed successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/rules/export', authenticateToken, async (req, res) => {
    try {
        const config = await iptables.exportRules();
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', 'attachment; filename="nfguard-rules.conf"');
        res.send(config);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/rules/import', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    try {
        const { config } = req.body;
        await iptables.importRules(config);
        res.json({ success: true, message: 'Rules imported successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/api/geo/block', authenticateToken, async (req, res) => {
    try {
        const { countryCode } = req.body;
        const result = await geoBlocker.blockCountry(countryCode, req.user.username);
        res.json({ success: true, result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.delete('/api/geo/block/:countryCode', authenticateToken, async (req, res) => {
    try {
        await geoBlocker.unblockCountry(req.params.countryCode);
        res.json({ success: true, message: 'Country unblocked successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/geo/blocked', authenticateToken, async (req, res) => {
    try {
        const countries = await geoBlocker.listBlockedCountries();
        res.json({ success: true, countries });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/geo/check/:ip', authenticateToken, async (req, res) => {
    try {
        const info = await geoBlocker.checkIP(req.params.ip);
        res.json({ success: true, info });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/stats', authenticateToken, async (req, res) => {
    try {
        const stats = await iptables.getStatistics();
        res.json({ success: true, stats });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/logs', authenticateToken, async (req, res) => {
    try {
        const lines = parseInt(req.query.lines) || 100;
        const logs = await logger.getRecentLogs(lines);
        res.json({ success: true, logs });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/logs/audit', authenticateToken, async (req, res) => {
    try {
        const lines = parseInt(req.query.lines) || 100;
        const logs = await logger.getAuditLogs(lines);
        res.json({ success: true, logs });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        version: '1.0.0',
        uptime: process.uptime()
    });
});

async function createSSLCertificates() {
    const certPath = '/etc/nfguard/ssl/';
    await fs.ensureDir(certPath);

    const keyPath = path.join(certPath, 'key.pem');
    const certFilePath = path.join(certPath, 'cert.pem');

    if (!await fs.pathExists(keyPath) || !await fs.pathExists(certFilePath)) {
        const { execSync } = require('child_process');

        try {
            execSync(`openssl req -x509 -newkey rsa:2048 -nodes -keyout ${keyPath} -out ${certFilePath} -days 365 -subj "/C=US/ST=State/L=City/O=NFGuard/CN=localhost"`, {
                stdio: 'ignore'
            });
        } catch (error) {
            console.error('Failed to generate SSL certificates:', error);

            const fallbackKey = `-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDZ1+Kz1XF9L6Ux
l7wLy0lN2SmyM3kGfVHafKbSNhXZ7fKCUiW4ZGDS0z8F5hECTvhQzNPBzL5qCnnN
V7wXX6IuQ6XqXSg5KUZqwqLHUgH+zn7ThHNF7zHjz1m3tT4bQvkBEcscmpL0MPp6
P8UvQL6w5QJ3DVXJ5kHdvUnmMp5UQ3eKBq3X7YOCcxHvFGBvO5q9uqR9D7lc8qwU
VGfNv/yvGqUqNyp9TjQwJiL7xNXc5TAMwGXCUNH7Hq3VKFx5Q7uxvPQ9L6r8KnVI
PGQkm+HRKPl8cJQOX1dKpB8QJ8M6ZB5lUKj5/RB5kF8YQ3fLB6q4P6Tm9BQ3F5QJ
2+YP5HjVAgMBAAECggEAGPQvJBz5t5HQN3Vn6HQ7h8VL3GQX7YJQ8KnX8D1Q0VDJ
0xX9VQJ3Q7xQx5VQX8DQXnVQX+VQJsP8G8Q7xHQ3NVQ9lFQ8X5QJ3BQX8VQX9VQJ
7GQX8VQJ8PQX7YQJ5HQXnVQX8VQJ9PQX7YQJ5HQXnVQX8VQJ9PQX7YQJ5HQXnVQ=
-----END PRIVATE KEY-----`;

            const fallbackCert = `-----BEGIN CERTIFICATE-----
MIIDXTCCAkWgAwIBAgIJAKl7GZH0VvZRMA0GCSqGSIb3DQEBCwUAMEUxCzAJBgNV
BAYTAlVTMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBX
aWRnaXRzIFB0eSBMdGQwHhcNMjQwMTAxMDAwMDAwWhcNMjUwMTAxMDAwMDAwWjBF
MQswCQYDVQQGEwJVUzETMBEGA1UECAwKU29tZS1TdGF0ZTEhMB8GA1UECgwYSW50
ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
CgKCAQEA2dfis9VxfS+lMZe8C8tJTdkpsjN5Bn1R2nym0jYV2e3yglIluGRg0tM/
BeYRAk74UMzTwcy+agp5zVe8F1+iLkOl6l0oOSlGasKix1IB/s5+04RzRe8x489Z
t7U+G0L5ARHLHJQS9DD6ej/FL0C+sOUCdw1VyeZB3b1J5jKeVEN3igat1+2DgnMR
7xRgbzuavbqkfQ+5XPKsFFRnzb/8rxqlKjcqfU40MCYi+8TV3OUwDMBlwlDR+x6t
1ShceUO7sbz0PS+q/Cp1SDxkJJvh0Sj5fHCUDl9XSqQfECfDOmQeZVCo+f0QeZBf
GEN3yweqeD+k5vQUNxeUCdvmD+R41QIDAQABo1AwTjAdBgNVHQ4EFgQUQ8J5HQ7x
VQJ9PQX7YQJ5HQXnVQX8VQJ9PQX7YQMBAfMB8GA1UdIwEB/wQFMAMBAf8wDQYJKoZ
IhvcNAQELBQADggEBAKQUQ8J5HQ7xVQJ9PQX7YQJ5HQXnVQX8VQJ9PQX7YQJ5HQXn
VQX8VQJ9PQX7YQJ5HQXnVQX8VQJ9PQX7YQJ5HQXnVQX8VQJ9PQX7YQJ5HQ=
-----END CERTIFICATE-----`;

            await fs.writeFile(keyPath, fallbackKey);
            await fs.writeFile(certFilePath, fallbackCert);
        }
    }

    return {
        key: await fs.readFile(keyPath),
        cert: await fs.readFile(certFilePath)
    };
}

async function startServer() {
    try {
        await iptables.initializeIPTables();
        console.log('✓ IPTables initialized');

        const sslOptions = await createSSLCertificates();

        const server = https.createServer(sslOptions, app);

        server.listen(PORT, '0.0.0.0', () => {
            console.log(`
╔═══════════════════════════════════════════╗
║            NFGuard Server v1.0.0          ║
╠═══════════════════════════════════════════╣
║  WebGUI: https://localhost:${PORT}         ║
║  Default Login: nfguard / nfguard         ║
║                                           ║
║  CLI Usage: nfguard --help                ║
╚═══════════════════════════════════════════╝
            `);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

if (require.main === module) {
    startServer();
}

module.exports = app;