# NFGuard v1.0.0 - Complete Documentation

## Table of Contents
1. [Overview](#overview)
2. [Installation](#installation)
3. [CLI Commands Reference](#cli-commands-reference)
4. [WebGUI Features](#webgui-features)
5. [System Architecture](#system-architecture)
6. [Configuration](#configuration)
7. [Troubleshooting](#troubleshooting)

---

## Overview

NFGuard is an advanced UFW (Uncomplicated Firewall) management tool that provides both command-line interface and web-based GUI for comprehensive firewall management. Built with security and usability in mind, NFGuard offers automatic conflict resolution, geo-blocking capabilities, and real-time monitoring.

### Key Features

✅ **Complete UFW Management** - Full control over UFW firewall settings
✅ **Automatic Conflict Resolution** - Intelligently resolves rule conflicts
✅ **Geo-blocking Support** - Block traffic by country
✅ **Real-time Monitoring** - Live log streaming and conflict detection
✅ **Web Interface** - Modern, responsive web GUI
✅ **CLI Interface** - Comprehensive command-line tools
✅ **Backup & Restore** - Configuration management
✅ **Auto-detection** - SSH and WebGUI port detection
✅ **Multi-user Support** - Role-based access control
✅ **Audit Logging** - Complete action tracking

---

## Installation

### Prerequisites
- Linux system with root access
- UFW installed (auto-installed if missing)
- Node.js 14+ (for WebGUI)
- Ports 22 (SSH) and 8443 (WebGUI) available

### Installation Steps

1. **Extract the package:**
   ```bash
   sudo tar -xzf nfguard-0.0.1.tar.gz
   cd nfguard-0.0.1
   ```

2. **Run the installation script:**
   ```bash
   sudo ./install.sh
   ```

3. **Start the service:**
   ```bash
   sudo systemctl start nfguard
   sudo systemctl enable nfguard
   ```

4. **Access the WebGUI:**
   - URL: `https://localhost:8443`
   - Default Login: `nfguard` / `nfguard`
   - **Important:** Change default credentials immediately

---

## CLI Commands Reference

### Basic Commands

#### Status and Information
```bash
# Show firewall status
sudo nfguard status

# Show detailed status with rules
sudo nfguard status --verbose

# Show firewall statistics
sudo nfguard stats

# Get help
sudo nfguard --help
```

#### Firewall Control
```bash
# Enable firewall
sudo nfguard enable

# Disable firewall
sudo nfguard disable

# Reload firewall
sudo nfguard reload

# Reset firewall (requires --force)
sudo nfguard reset --force
```

### Rule Management

#### Allow Rules
```bash
# Allow port (TCP by default)
sudo nfguard allow -p 80

# Allow port with specific protocol
sudo nfguard allow -p 53 -P udp

# Allow from specific source
sudo nfguard allow -p 22 -s 192.168.1.0/24

# Allow with comment
sudo nfguard allow -p 443 -c "HTTPS Web Server"

# Allow outgoing connections
sudo nfguard allow -p 25 -D out
```

#### Block/Deny Rules
```bash
# Block port
sudo nfguard block -p 8080

# Block IP address
sudo nfguard block -s 192.168.1.100

# Block network range
sudo nfguard block -s 10.0.0.0/8

# Block with custom comment
sudo nfguard block -p 3389 -c "Block RDP"
```

#### Reject Rules
```bash
# Reject connection (sends rejection response)
sudo nfguard reject -p 23 -c "Reject Telnet"
```

#### Rule Operations
```bash
# List all rules
sudo nfguard list

# List rules with details
sudo nfguard list --verbose

# Delete rule by ID
sudo nfguard delete abc12345

# Preview rule before deletion
sudo nfguard delete abc12345 --preview
```

### Default Policies
```bash
# Set default incoming policy
sudo nfguard default incoming deny

# Set default outgoing policy
sudo nfguard default outgoing allow

# Set default forward policy
sudo nfguard default forward deny
```

### Logging
```bash
# Set logging level
sudo nfguard logging low
sudo nfguard logging medium
sudo nfguard logging high
sudo nfguard logging full
sudo nfguard logging off

# View recent logs
sudo nfguard logs

# Follow logs in real-time
sudo nfguard logs --follow

# Show specific number of lines
sudo nfguard logs --lines 100
```

### Geo-blocking

#### Block Countries
```bash
# Block traffic from a country
sudo nfguard geo-block CN

# Unblock country
sudo nfguard geo-unblock CN

# List blocked countries
sudo nfguard geo-list

# Check IP location
sudo nfguard geo-check 8.8.8.8
```

### Advanced Commands

#### Conflict Management
```bash
# Check for rule conflicts
sudo nfguard conflicts
```

#### Backup and Restore
```bash
# Backup configuration
sudo nfguard backup /path/to/backup.json

# Restore configuration (requires --force)
sudo nfguard restore /path/to/backup.json --force
```

#### Service Management
```bash
# UFW service control
sudo nfguard service start
sudo nfguard service stop
sudo nfguard service restart
sudo nfguard service status
```

### Command Options Reference

#### Global Options
- `-v, --verbose` - Enable verbose output
- `--no-color` - Disable colored output
- `-h, --help` - Show help

#### Rule Options
- `-p, --port <port>` - Port number or range (e.g., 80, 1000:2000)
- `-P, --protocol <proto>` - Protocol (tcp/udp/icmp)
- `-s, --source <ip>` - Source IP or network
- `-d, --destination <ip>` - Destination IP or network
- `-D, --direction <dir>` - Direction (in/out)
- `-c, --comment <text>` - Rule comment

---

## WebGUI Features

### Dashboard
- **Real-time Statistics** - Active rules, blocked countries, system status
- **Quick Actions** - Add rules, enable/disable firewall
- **System Overview** - UFW status, default policies, logging level

### Firewall Rules
- **Rule Management** - Add, edit, delete firewall rules
- **Rule Types** - Port access, IP blocking, network blocking, ICMP control
- **Advanced Options** - Custom protocols, directions, sources, destinations
- **Bulk Operations** - Import/export rules, flush all rules
- **Conflict Detection** - Automatic detection and resolution

### Geo Blocking
- **Country Blocking** - Block traffic by country code
- **IP Lookup** - Check IP geolocation information
- **Bulk Operations** - Mass country blocking/unblocking

### Live Monitor
- **Real-time Logs** - Live UFW log streaming
- **Conflict Detection** - Real-time rule conflict monitoring
- **System Events** - Firewall state changes and rule modifications

### Backup & Restore
- **Configuration Backup** - Download complete firewall configuration
- **Configuration Restore** - Upload and restore from backup files
- **Automated Backups** - Schedule regular configuration backups

### Network Info
- **Network Interfaces** - View all network interfaces and IP addresses
- **UFW Settings** - Manage default policies, logging, firewall state
- **Interface Monitoring** - Monitor interface status and traffic

### System Info
- **System Details** - Hostname, distribution, kernel, uptime
- **NFGuard Status** - Version, SSH port, WebGUI port
- **Service Status** - UFW version and service state

### Settings
- **Account Management** - Change username and password
- **User Management** - Add/remove users (admin only)
- **System Configuration** - UFW settings and preferences

---

## System Architecture

### Directory Structure

```
nfguard-0.0.1/
├── src/
│   ├── index.js              # Servidor principal (API REST + HTTPS)
│   ├── cli/
│   │   └── index.js          # Interface de linha de comando
│   ├── core/
│   │   ├── iptables-manager.js  # Gerenciador de regras IPTables
│   │   ├── nftables-manager.js  # Gerenciador NFTables (futuro)
│   │   ├── geo-blocker.js       # Sistema de bloqueio geográfico
│   │   └── logger.js            # Sistema de logs
│   └── auth/
│       └── auth-manager.js      # Gerenciamento de autenticação
├── web/
│   ├── index.html            # Interface WebGUI
│   └── app.js                # Aplicação frontend
├── install.sh                # Script de instalação
├── package.json              # Dependências Node.js
└── README.md                 # Documentação básica
```

## Componentes Principais

### 1. IPTables Manager (`src/core/iptables-manager.js`)

**Responsabilidades:**
- Gerenciar chains customizadas NFGUARD-INPUT, NFGUARD-OUTPUT, NFGUARD-FORWARD
- Adicionar, remover e listar regras de firewall
- Manter sincronização entre regras salvas e ativas
- Garantir ordem correta de aplicação das regras

**Métodos Principais:**
- `initializeIPTables()` - Inicializa chains e regras base
- `addRule(rule, user)` - Adiciona nova regra ao firewall
- `deleteRule(ruleId, user)` - Remove regra específica
- `listRules()` - Lista regras salvas, ativas e do sistema
- `flushRules()` - Remove todas as regras NFGUARD
- `exportRules()` / `importRules()` - Backup e restore

**Ordem de Aplicação das Regras:**
1. Loopback (sempre permitido)
2. Conexões estabelecidas (ESTABLISHED, RELATED)
3. SSH (porta 22)
4. WebGUI (porta 8443)
5. Regras customizadas do usuário

### 2. CLI Interface (`src/cli/index.js`)

**Comandos Disponíveis:**

```bash
# Inicialização
nfguard init                    # Inicializa IPTables com configuração base

# Gerenciamento de Regras
nfguard allow -p 80             # Permite porta TCP 80
nfguard block -s 192.168.1.100  # Bloqueia IP específico
nfguard block -P icmp           # Bloqueia ICMP (ping)
nfguard list                    # Lista todas as regras
nfguard list --all             # Inclui regras do sistema
nfguard delete <ruleId>        # Remove regra por ID
nfguard flush --force          # Remove todas as regras NFGUARD

# Bloqueio Geográfico
nfguard geo-block CN           # Bloqueia país (código ISO)
nfguard geo-unblock CN         # Desbloqueia país
nfguard geo-list               # Lista países bloqueados
nfguard geo-update             # Atualiza base GeoIP
nfguard check-ip <ip>          # Verifica informações de IP

# Estatísticas e Backup
nfguard stats                  # Mostra estatísticas
nfguard stats --detailed       # Estatísticas detalhadas
nfguard export <file>          # Exporta configuração
nfguard import <file>          # Importa configuração
```

### 3. Web Server (`src/index.js`)

**Endpoints da API:**

```javascript
// Autenticação
POST /api/auth/login           // Login de usuário
POST /api/auth/logout          // Logout
GET  /api/auth/profile         // Perfil do usuário
POST /api/auth/change-password // Alterar senha
POST /api/auth/change-username // Alterar username

// Regras de Firewall
GET    /api/rules              // Lista todas as regras
POST   /api/rules              // Adiciona nova regra
DELETE /api/rules/:id          // Remove regra
POST   /api/rules/flush        // Remove todas as regras
GET    /api/rules/export       // Exporta configuração
POST   /api/rules/import       // Importa configuração

// Bloqueio Geográfico
POST   /api/geo/block          // Bloqueia país
DELETE /api/geo/block/:code    // Desbloqueia país
GET    /api/geo/blocked        // Lista países bloqueados
GET    /api/geo/check/:ip      // Verifica IP

// Sistema
GET  /api/stats                // Estatísticas do firewall
GET  /api/logs                 // Logs do sistema
GET  /api/logs/audit           // Logs de auditoria
GET  /api/health               // Status do serviço
```

### 4. WebGUI (`web/app.js` + `web/index.html`)

**Funcionalidades:**
- Dashboard com métricas em tempo real
- Gerenciamento visual de regras
- Sistema de tabs para visualização:
  - Regras Salvas
  - Regras Ativas (IPTables)
  - Regras do Sistema
- Bloqueio geográfico interativo
- Visualização de logs
- Configurações de conta

### 5. Sistema de Autenticação (`src/auth/auth-manager.js`)

**Recursos:**
- Autenticação JWT
- Usuário padrão: nfguard/nfguard
- Suporte a múltiplos usuários
- Roles: admin, user
- Hash de senha com bcrypt

### 6. Logger (`src/core/logger.js`)

**Níveis de Log:**
- info - Operações normais
- warning - Avisos
- error - Erros
- audit - Ações de auditoria

**Arquivos de Log:**
- `/var/log/nfguard/service.log` - Log principal
- `/var/log/nfguard/error.log` - Erros
- `/var/log/nfguard/audit.log` - Auditoria

## Correções Implementadas

### 1. Problema de Ordem das Regras IPTables

**Problema Original:**
- Regras eram adicionadas às chains padrão (INPUT, OUTPUT, FORWARD)
- Conflito com outras regras do sistema
- ICMP não era bloqueado corretamente

**Solução:**
- Uso de chains customizadas NFGUARD-*
- Inserção de jump rules na posição 1
- Ordem garantida de aplicação

### 2. Visualização Completa de Regras

**Melhorias no CLI:**
- Comando `list --all` mostra regras do sistema
- Formatação em tabelas organizadas
- Separação clara entre regras NFGUARD e sistema

**Melhorias no WebGUI:**
- Sistema de tabs para diferentes visualizações
- Exibição de regras ativas do IPTables
- Contador de regras salvas vs ativas

### 3. Gestão de Chains

**Implementação:**
```bash
# Criação de chains customizadas
iptables -N NFGUARD-INPUT
iptables -N NFGUARD-OUTPUT
iptables -N NFGUARD-FORWARD

# Jump rules na posição 1 (máxima prioridade)
iptables -I INPUT 1 -j NFGUARD-INPUT
iptables -I OUTPUT 1 -j NFGUARD-OUTPUT
iptables -I FORWARD 1 -j NFGUARD-FORWARD
```

## Instalação

### Requisitos
- Linux (Ubuntu, Debian, CentOS, Arch, etc.)
- Node.js 22.19.0 LTS ou superior
- IPTables
- OpenSSL

### Processo de Instalação

```bash
# Como root
sudo ./install.sh

# O instalador:
1. Detecta a distribuição
2. Instala dependências
3. Copia arquivos para /opt/nfguard
4. Cria serviço systemd/openrc
5. Inicializa IPTables
6. Gera certificados SSL
7. Inicia o serviço
```

### Diretórios Criados
- `/opt/nfguard` - Aplicação
- `/etc/nfguard` - Configurações
- `/etc/nfguard/ssl` - Certificados SSL
- `/var/log/nfguard` - Logs

## Configuração

### Variáveis de Ambiente
```bash
PORT=8443                    # Porta do WebGUI
NODE_ENV=production         # Ambiente
SESSION_SECRET=<secret>     # Secret para sessões
NFGUARD_RULES_PATH=/etc/nfguard/rules.json  # Arquivo de regras
```

### Arquivo de Regras
Local: `/etc/nfguard/rules.json`

Formato:
```json
[
  {
    "id": "1234567890",
    "type": "port",
    "direction": "input",
    "protocol": "tcp",
    "port": "80",
    "action": "ACCEPT",
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

## Segurança

### Regras Base (Sempre Ativas)
1. Loopback sempre permitido
2. Conexões estabelecidas permitidas
3. SSH (porta 22) permitido
4. WebGUI (porta 8443) permitido

### Boas Práticas
- Alterar senha padrão imediatamente
- Usar HTTPS para WebGUI
- Fazer backup regular das regras
- Monitorar logs regularmente
- Testar regras antes de aplicar em produção

## Troubleshooting

### Regras não funcionam
```bash
# Verificar chains NFGUARD
iptables -L NFGUARD-INPUT -n -v

# Verificar jump rules
iptables -L INPUT -n -v | head

# Re-inicializar
nfguard init
```

### WebGUI não acessível
```bash
# Verificar serviço
systemctl status nfguard

# Verificar porta
netstat -tlnp | grep 8443

# Verificar regra de firewall
iptables -L NFGUARD-INPUT -n | grep 8443
```

### Logs
```bash
# Logs do serviço
tail -f /var/log/nfguard/service.log

# Erros
tail -f /var/log/nfguard/error.log

# Auditoria
tail -f /var/log/nfguard/audit.log
```

## Desenvolvimento Futuro

### Melhorias Planejadas
- [ ] Suporte completo a NFTables
- [ ] Interface de monitoramento em tempo real
- [ ] Integração com fail2ban
- [ ] Detecção de intrusão (IDS)
- [ ] Backup automático
- [ ] Clusters de firewall
- [ ] API GraphQL
- [ ] Aplicativo mobile

### Contribuindo
1. Fork do projeto
2. Criar branch para feature
3. Commit das mudanças
4. Push para o branch
5. Criar Pull Request

## Suporte

### Comandos Úteis
```bash
# Status do serviço
systemctl status nfguard

# Reiniciar serviço
systemctl restart nfguard

# Ver logs em tempo real
journalctl -u nfguard -f

# Testar regra antes de aplicar
iptables -A NFGUARD-INPUT -p tcp --dport 3000 -j ACCEPT --dry-run
```

### Contato
- GitHub: https://github.com/nfguard/nfguard
- Issues: https://github.com/nfguard/nfguard/issues

## Licença

MIT License - Veja arquivo LICENSE para detalhes.

---

Documento gerado em: 2024-09-20
Versão: 1.0.0