# NFGuard - Documentação Completa do Projeto

## Visão Geral

NFGuard é uma ferramenta de gerenciamento de firewall baseada em IPTables, oferecendo interface CLI e WebGUI para configuração simplificada de regras de firewall, bloqueio geográfico e monitoramento de tráfego.

## Arquitetura do Sistema

### Estrutura de Diretórios

```
nfguard-0.0.1/
├── src/
│   ├── index.js              # Servidor principal (API REST + HTTPS)
│   ├── cli/
│   │   └── index.js          # Interface de linha de comando
│   ├── core/
│   │   ├── iptables-manager.js  # Gerenciador de regras IPTables
│   │   ├── nftables-manager.js  # Gerenciador NFTables (futuro)
│   │   ├── geo-blocker.js       # Sistema de bloqueio geográfico
│   │   └── logger.js            # Sistema de logs
│   └── auth/
│       └── auth-manager.js      # Gerenciamento de autenticação
├── web/
│   ├── index.html            # Interface WebGUI
│   └── app.js                # Aplicação frontend
├── install.sh                # Script de instalação
├── package.json              # Dependências Node.js
└── README.md                 # Documentação básica
```

## Componentes Principais

### 1. IPTables Manager (`src/core/iptables-manager.js`)

**Responsabilidades:**
- Gerenciar chains customizadas NFGUARD-INPUT, NFGUARD-OUTPUT, NFGUARD-FORWARD
- Adicionar, remover e listar regras de firewall
- Manter sincronização entre regras salvas e ativas
- Garantir ordem correta de aplicação das regras

**Métodos Principais:**
- `initializeIPTables()` - Inicializa chains e regras base
- `addRule(rule, user)` - Adiciona nova regra ao firewall
- `deleteRule(ruleId, user)` - Remove regra específica
- `listRules()` - Lista regras salvas, ativas e do sistema
- `flushRules()` - Remove todas as regras NFGUARD
- `exportRules()` / `importRules()` - Backup e restore

**Ordem de Aplicação das Regras:**
1. Loopback (sempre permitido)
2. Conexões estabelecidas (ESTABLISHED, RELATED)
3. SSH (porta 22)
4. WebGUI (porta 8443)
5. Regras customizadas do usuário

### 2. CLI Interface (`src/cli/index.js`)

**Comandos Disponíveis:**

```bash
# Inicialização
nfguard init                    # Inicializa IPTables com configuração base

# Gerenciamento de Regras
nfguard allow -p 80             # Permite porta TCP 80
nfguard block -s 192.168.1.100  # Bloqueia IP específico
nfguard block -P icmp           # Bloqueia ICMP (ping)
nfguard list                    # Lista todas as regras
nfguard list --all             # Inclui regras do sistema
nfguard delete <ruleId>        # Remove regra por ID
nfguard flush --force          # Remove todas as regras NFGUARD

# Bloqueio Geográfico
nfguard geo-block CN           # Bloqueia país (código ISO)
nfguard geo-unblock CN         # Desbloqueia país
nfguard geo-list               # Lista países bloqueados
nfguard geo-update             # Atualiza base GeoIP
nfguard check-ip <ip>          # Verifica informações de IP

# Estatísticas e Backup
nfguard stats                  # Mostra estatísticas
nfguard stats --detailed       # Estatísticas detalhadas
nfguard export <file>          # Exporta configuração
nfguard import <file>          # Importa configuração
```

### 3. Web Server (`src/index.js`)

**Endpoints da API:**

```javascript
// Autenticação
POST /api/auth/login           // Login de usuário
POST /api/auth/logout          // Logout
GET  /api/auth/profile         // Perfil do usuário
POST /api/auth/change-password // Alterar senha
POST /api/auth/change-username // Alterar username

// Regras de Firewall
GET    /api/rules              // Lista todas as regras
POST   /api/rules              // Adiciona nova regra
DELETE /api/rules/:id          // Remove regra
POST   /api/rules/flush        // Remove todas as regras
GET    /api/rules/export       // Exporta configuração
POST   /api/rules/import       // Importa configuração

// Bloqueio Geográfico
POST   /api/geo/block          // Bloqueia país
DELETE /api/geo/block/:code    // Desbloqueia país
GET    /api/geo/blocked        // Lista países bloqueados
GET    /api/geo/check/:ip      // Verifica IP

// Sistema
GET  /api/stats                // Estatísticas do firewall
GET  /api/logs                 // Logs do sistema
GET  /api/logs/audit           // Logs de auditoria
GET  /api/health               // Status do serviço
```

### 4. WebGUI (`web/app.js` + `web/index.html`)

**Funcionalidades:**
- Dashboard com métricas em tempo real
- Gerenciamento visual de regras
- Sistema de tabs para visualização:
  - Regras Salvas
  - Regras Ativas (IPTables)
  - Regras do Sistema
- Bloqueio geográfico interativo
- Visualização de logs
- Configurações de conta

### 5. Sistema de Autenticação (`src/auth/auth-manager.js`)

**Recursos:**
- Autenticação JWT
- Usuário padrão: nfguard/nfguard
- Suporte a múltiplos usuários
- Roles: admin, user
- Hash de senha com bcrypt

### 6. Logger (`src/core/logger.js`)

**Níveis de Log:**
- info - Operações normais
- warning - Avisos
- error - Erros
- audit - Ações de auditoria

**Arquivos de Log:**
- `/var/log/nfguard/service.log` - Log principal
- `/var/log/nfguard/error.log` - Erros
- `/var/log/nfguard/audit.log` - Auditoria

## Correções Implementadas

### 1. Problema de Ordem das Regras IPTables

**Problema Original:**
- Regras eram adicionadas às chains padrão (INPUT, OUTPUT, FORWARD)
- Conflito com outras regras do sistema
- ICMP não era bloqueado corretamente

**Solução:**
- Uso de chains customizadas NFGUARD-*
- Inserção de jump rules na posição 1
- Ordem garantida de aplicação

### 2. Visualização Completa de Regras

**Melhorias no CLI:**
- Comando `list --all` mostra regras do sistema
- Formatação em tabelas organizadas
- Separação clara entre regras NFGUARD e sistema

**Melhorias no WebGUI:**
- Sistema de tabs para diferentes visualizações
- Exibição de regras ativas do IPTables
- Contador de regras salvas vs ativas

### 3. Gestão de Chains

**Implementação:**
```bash
# Criação de chains customizadas
iptables -N NFGUARD-INPUT
iptables -N NFGUARD-OUTPUT
iptables -N NFGUARD-FORWARD

# Jump rules na posição 1 (máxima prioridade)
iptables -I INPUT 1 -j NFGUARD-INPUT
iptables -I OUTPUT 1 -j NFGUARD-OUTPUT
iptables -I FORWARD 1 -j NFGUARD-FORWARD
```

## Instalação

### Requisitos
- Linux (Ubuntu, Debian, CentOS, Arch, etc.)
- Node.js 22.19.0 LTS ou superior
- IPTables
- OpenSSL

### Processo de Instalação

```bash
# Como root
sudo ./install.sh

# O instalador:
1. Detecta a distribuição
2. Instala dependências
3. Copia arquivos para /opt/nfguard
4. Cria serviço systemd/openrc
5. Inicializa IPTables
6. Gera certificados SSL
7. Inicia o serviço
```

### Diretórios Criados
- `/opt/nfguard` - Aplicação
- `/etc/nfguard` - Configurações
- `/etc/nfguard/ssl` - Certificados SSL
- `/var/log/nfguard` - Logs

## Configuração

### Variáveis de Ambiente
```bash
PORT=8443                    # Porta do WebGUI
NODE_ENV=production         # Ambiente
SESSION_SECRET=<secret>     # Secret para sessões
NFGUARD_RULES_PATH=/etc/nfguard/rules.json  # Arquivo de regras
```

### Arquivo de Regras
Local: `/etc/nfguard/rules.json`

Formato:
```json
[
  {
    "id": "1234567890",
    "type": "port",
    "direction": "input",
    "protocol": "tcp",
    "port": "80",
    "action": "ACCEPT",
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

## Segurança

### Regras Base (Sempre Ativas)
1. Loopback sempre permitido
2. Conexões estabelecidas permitidas
3. SSH (porta 22) permitido
4. WebGUI (porta 8443) permitido

### Boas Práticas
- Alterar senha padrão imediatamente
- Usar HTTPS para WebGUI
- Fazer backup regular das regras
- Monitorar logs regularmente
- Testar regras antes de aplicar em produção

## Troubleshooting

### Regras não funcionam
```bash
# Verificar chains NFGUARD
iptables -L NFGUARD-INPUT -n -v

# Verificar jump rules
iptables -L INPUT -n -v | head

# Re-inicializar
nfguard init
```

### WebGUI não acessível
```bash
# Verificar serviço
systemctl status nfguard

# Verificar porta
netstat -tlnp | grep 8443

# Verificar regra de firewall
iptables -L NFGUARD-INPUT -n | grep 8443
```

### Logs
```bash
# Logs do serviço
tail -f /var/log/nfguard/service.log

# Erros
tail -f /var/log/nfguard/error.log

# Auditoria
tail -f /var/log/nfguard/audit.log
```

## Desenvolvimento Futuro

### Melhorias Planejadas
- [ ] Suporte completo a NFTables
- [ ] Interface de monitoramento em tempo real
- [ ] Integração com fail2ban
- [ ] Detecção de intrusão (IDS)
- [ ] Backup automático
- [ ] Clusters de firewall
- [ ] API GraphQL
- [ ] Aplicativo mobile

### Contribuindo
1. Fork do projeto
2. Criar branch para feature
3. Commit das mudanças
4. Push para o branch
5. Criar Pull Request

## Suporte

### Comandos Úteis
```bash
# Status do serviço
systemctl status nfguard

# Reiniciar serviço
systemctl restart nfguard

# Ver logs em tempo real
journalctl -u nfguard -f

# Testar regra antes de aplicar
iptables -A NFGUARD-INPUT -p tcp --dport 3000 -j ACCEPT --dry-run
```

### Contato
- GitHub: https://github.com/nfguard/nfguard
- Issues: https://github.com/nfguard/nfguard/issues

## Licença

MIT License - Veja arquivo LICENSE para detalhes.

---

Documento gerado em: 2024-09-20
Versão: 1.0.0