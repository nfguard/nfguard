# NFGuard v0.0.1 - Complete Documentation

## Table of Contents
1. [Overview](#overview)
2. [Installation](#installation)
3. [CLI Commands Reference](#cli-commands-reference)
4. [WebGUI Features](#webgui-features)
5. [System Architecture](#system-architecture)
6. [Configuration](#configuration)
7. [Troubleshooting](#troubleshooting)

---

## Overview

NFGuard is an advanced UFW (Uncomplicated Firewall) management tool that provides both command-line interface and web-based GUI for comprehensive firewall management. Built with security and usability in mind, NFGuard offers automatic conflict resolution, geo-blocking capabilities with ipset integration, and real-time monitoring.

### Key Features

✅ **Complete UFW Management** - Full control over UFW firewall settings
✅ **Automatic Conflict Resolution** - Intelligently resolves rule conflicts
✅ **Real Geo-blocking with ipset** - Block traffic by country using efficient ipset technology
✅ **MaxMind Database Integration** - Real .mmdb database support for accurate geo-location
✅ **Real-time Monitoring** - Live log streaming and conflict detection
✅ **Modern Web Interface** - Responsive web GUI with statistics dashboard
✅ **Professional CLI Interface** - 30+ comprehensive command-line tools
✅ **Backup & Restore** - Configuration management with versioning
✅ **Auto-detection** - SSH and WebGUI port detection from system configuration
✅ **Multi-user Support** - Role-based access control with JWT authentication
✅ **Complete Audit Logging** - Full action tracking and security monitoring
✅ **Production Ready** - Enterprise-grade security and performance

---

## Installation

### Prerequisites
- Linux system with root access
- UFW (auto-installed if missing)
- Node.js 22+ (for WebGUI)
- ipset (auto-installed if missing)
- Ports 22 (SSH) and 8443 (WebGUI) available

### Installation Steps

1. **Extract the package:**
   ```bash
   sudo tar -xzf nfguard-0.0.1.tar.gz
   cd nfguard-0.0.1
   ```

2. **Run the installation script:**
   ```bash
   sudo bash install.sh
   ```

3. **Start the service:**
   ```bash
   sudo systemctl start nfguard
   sudo systemctl enable nfguard
   ```

4. **Access the WebGUI:**
   ```
   https://your-server-ip:8443
   Default credentials: nfguard / nfguard
   ```

### Manual Installation (if needed)

```bash
# Install dependencies
sudo npm install

# Create system user and directories
sudo useradd -r -s /bin/false nfguard
sudo mkdir -p /etc/nfguard /var/log/nfguard
sudo chown nfguard:nfguard /etc/nfguard /var/log/nfguard

# Install CLI globally
sudo npm link

# Configure systemd service
sudo cp nfguard.service /etc/systemd/system/
sudo systemctl daemon-reload
```

---

## CLI Commands Reference

### System Commands

```bash
# Service Management
nfguard start                    # Start NFGuard service
nfguard stop                     # Stop NFGuard service
nfguard restart                  # Restart NFGuard service
nfguard status                   # Show service status
nfguard version                  # Show version information

# UFW Management
nfguard enable                   # Enable UFW firewall
nfguard disable                  # Disable UFW firewall
nfguard reset                    # Reset UFW to defaults
nfguard reload                   # Reload UFW rules
```

### Rule Management

```bash
# Basic Rule Operations
nfguard allow <port>[/<protocol>]              # Allow port/protocol
nfguard deny <port>[/<protocol>]               # Deny port/protocol
nfguard block <ip>                             # Block IP address
nfguard unblock <ip>                           # Unblock IP address

# Advanced Rule Management
nfguard rules add <action> <target> [options]  # Add custom rule
nfguard rules remove <rule-id>                 # Remove rule by ID
nfguard rules show <rule-id>                   # Show specific rule
nfguard rules count                            # Count active rules

# Rule Listing
nfguard list                     # List all active rules
nfguard list --verbose          # Detailed rule information
nfguard list --all              # Include disabled rules
nfguard list --format=json      # JSON output format
```

### Geo-blocking Commands

```bash
# Country Blocking
nfguard geo-block <COUNTRY_CODE>               # Block country by code (e.g., CN, RU)
nfguard geo-block <COUNTRY_CODE> -c "comment"  # Block with comment
nfguard geo-unblock <COUNTRY_CODE>             # Unblock country

# Geo Information
nfguard geo-list                 # List blocked countries
nfguard geo-list --verbose       # Detailed geo-blocking info
nfguard geo-stats                # Show geo-blocking statistics
nfguard geo-check <ip>           # Check IP geolocation
```

### Configuration Management

```bash
# Backup & Restore
nfguard backup create [name]     # Create configuration backup
nfguard backup list              # List available backups
nfguard backup restore <name>    # Restore from backup
nfguard backup delete <name>     # Delete backup

# Configuration
nfguard config show             # Show current configuration
nfguard config set <key> <value> # Set configuration value
nfguard config reset            # Reset to defaults
```

### Monitoring Commands

```bash
# System Monitoring
nfguard logs                    # View recent logs
nfguard logs --follow           # Follow logs in real-time
nfguard logs --lines=100        # Show specific number of lines
nfguard logs --audit            # Show audit logs only

# Statistics
nfguard stats                   # Show firewall statistics
nfguard stats --detailed        # Detailed statistics
nfguard connections             # Show active connections
```

### Utility Commands

```bash
# Conflict Management
nfguard conflicts check         # Check for rule conflicts
nfguard conflicts resolve       # Auto-resolve conflicts
nfguard conflicts list          # List detected conflicts

# System Health
nfguard health                  # System health check
nfguard validate                # Validate configuration
nfguard cleanup                 # Clean temporary files

# Help & Information
nfguard help                    # Show help information
nfguard help <command>          # Show command-specific help
nfguard examples                # Show usage examples
```

---

## WebGUI Features

### Dashboard Overview
- **Real-time Statistics**: Live firewall statistics and geo-blocking metrics
- **Service Status**: NFGuard service health monitoring
- **Quick Actions**: Fast access to common operations
- **System Information**: Server details and resource usage

### Firewall Rules Management
- **Visual Rule Editor**: Add/edit rules with intuitive interface
- **Rule Validation**: Real-time rule validation and conflict detection
- **Bulk Operations**: Import/export rules, bulk enable/disable
- **Search & Filter**: Advanced rule search and filtering
- **Rule Templates**: Pre-configured rule templates

### Geo-blocking Interface
- **Interactive Country Map**: Visual country selection for blocking
- **Statistics Dashboard**: Real-time geo-blocking statistics with ipset information
- **Country Management**: Easy block/unblock with detailed information
- **IP Lookup Tool**: Check IP geolocation and blocking status
- **MMDB Database Status**: Monitor MaxMind database availability

### Log Monitoring
- **Real-time Logs**: Live log streaming with auto-refresh
- **Log Filtering**: Filter by type, date, severity
- **Audit Trail**: Complete audit log with user actions
- **Export Functionality**: Download logs in various formats

### User Management
- **Multi-user Support**: Create and manage multiple users
- **Role-based Access**: Admin and user roles with different permissions
- **Session Management**: Active session monitoring and control
- **Password Security**: Secure password policies and enforcement

### System Configuration
- **UFW Settings**: Complete UFW configuration management
- **Service Controls**: Start/stop/restart NFGuard service
- **Backup Management**: Create, restore, and manage backups
- **Certificate Management**: SSL certificate generation and renewal

---

## System Architecture

### Core Components

#### 1. UFW Manager (`src/core/ufw-manager.js`)
- **Real UFW Integration**: Direct integration with UFW firewall
- **Auto SSH Detection**: Reads SSH port from /etc/ssh/sshd_config
- **Conflict Resolution**: Automatically removes conflicting rules
- **Rule Validation**: Ensures rule integrity and prevents conflicts

#### 2. Geo-blocker (`src/core/geo-blocker.js`)
- **ipset Integration**: Uses Linux ipset for efficient IP blocking
- **MaxMind Database**: Real .mmdb database support for accurate geolocation
- **Fallback Ranges**: Comprehensive IP ranges for major countries
- **Performance Optimized**: Handles millions of IP addresses efficiently

#### 3. Authentication Manager (`src/auth/auth-manager.js`)
- **JWT Security**: JSON Web Token authentication
- **bcrypt Encryption**: Secure password hashing
- **Session Management**: Secure session handling
- **Root Validation**: Ensures proper root permissions

#### 4. Web Server (`src/index.js`)
- **HTTPS Only**: Forced HTTPS with auto-generated certificates
- **Express Framework**: Modern web framework with security middleware
- **Real-time APIs**: WebSocket support for live updates
- **Error Handling**: Comprehensive error handling and logging

#### 5. CLI Interface (`src/cli/index.js`)
- **30+ Commands**: Comprehensive command-line interface
- **Colored Output**: Professional CLI with colors and formatting
- **Table Display**: Formatted tables for data display
- **Help System**: Built-in help and examples

### File Structure
```
nfguard-0.0.1/
├── src/
│   ├── core/
│   │   ├── ufw-manager.js      # UFW firewall management
│   │   ├── geo-blocker.js      # Geo-blocking with ipset
│   │   └── logger.js           # Winston logging system
│   ├── auth/
│   │   └── auth-manager.js     # Authentication & authorization
│   ├── cli/
│   │   └── index.js            # CLI interface
│   └── index.js                # Main web server
├── web/
│   ├── app.js                  # WebGUI JavaScript
│   └── index.html              # WebGUI interface
├── install.sh                  # Installation script
├── nfguard.service            # Systemd service file
├── package.json               # Node.js dependencies
└── DOCUMENTATION.md           # This documentation
```

---

## API Reference

### Authentication
All API endpoints require JWT authentication via Authorization header or session cookie.

### Endpoint Categories

#### Authentication
```
POST   /api/login              // User authentication
POST   /api/logout             // User logout
GET    /api/user               // Get current user info
```

#### Firewall Management
```
GET    /api/rules              // List all firewall rules
POST   /api/rules              // Add new firewall rule
PUT    /api/rules/:id          // Update existing rule
DELETE /api/rules/:id          // Delete firewall rule
POST   /api/rules/validate     // Validate rule configuration
```

#### UFW Control
```
GET    /api/ufw/status         // Get UFW status
POST   /api/ufw/enable         // Enable UFW
POST   /api/ufw/disable        // Disable UFW
POST   /api/ufw/reset          // Reset UFW to defaults
POST   /api/ufw/reload         // Reload UFW rules
```

#### Geo-blocking
```
POST   /api/geo/block          // Block country
DELETE /api/geo/block/:code    // Unblock country
GET    /api/geo/blocked        // List blocked countries
GET    /api/geo/check/:ip      // Check IP geolocation
GET    /api/geo/stats          // Get geo-blocking statistics
```

#### System Management
```
GET    /api/stats              // Firewall statistics
GET    /api/logs               // System logs
GET    /api/logs/audit         // Audit logs
GET    /api/health             // System health check
POST   /api/backup             // Create backup
GET    /api/backup             // List backups
```

---

## Configuration

### Environment Variables
```bash
NFGUARD_PORT=8443              # WebGUI port (default: 8443)
NFGUARD_HOST=0.0.0.0           # WebGUI host (default: 0.0.0.0)
NFGUARD_LOG_LEVEL=info         # Log level (debug, info, warn, error)
NFGUARD_JWT_SECRET=auto        # JWT secret (auto-generated if not set)
NFGUARD_SESSION_TIMEOUT=24h    # Session timeout (default: 24 hours)
```

### Configuration Files
- **Main Config**: `/etc/nfguard/config.json`
- **User Database**: `/etc/nfguard/users.json`
- **Backup Directory**: `/etc/nfguard/backups/`
- **Log Directory**: `/var/log/nfguard/`
- **SSL Certificates**: `/etc/nfguard/ssl/`

### Default Configuration
```json
{
  "server": {
    "port": 8443,
    "host": "0.0.0.0",
    "ssl": true
  },
  "firewall": {
    "auto_enable": true,
    "conflict_resolution": true,
    "backup_on_change": true
  },
  "geo_blocking": {
    "enabled": true,
    "auto_update": true,
    "fallback_ranges": true
  },
  "logging": {
    "level": "info",
    "max_files": 10,
    "max_size": "10MB"
  }
}
```

---

## Security Features

### Network Security
- **HTTPS Only**: All communications encrypted with TLS
- **Auto-generated Certificates**: Self-signed certificates for immediate security
- **Port Protection**: Automatic SSH port detection and protection
- **IP Whitelisting**: Support for IP-based access control

### Authentication & Authorization
- **JWT Tokens**: Secure JSON Web Token authentication
- **Password Hashing**: bcrypt encryption for password storage
- **Session Management**: Secure session handling with expiration
- **Role-based Access**: Admin and user roles with different permissions

### Audit & Monitoring
- **Complete Audit Trail**: All actions logged with user attribution
- **Real-time Monitoring**: Live log streaming and alerting
- **Failed Login Detection**: Automatic detection of brute force attempts
- **Configuration Changes**: All configuration changes tracked

### System Hardening
- **Root Permission Validation**: Ensures proper system permissions
- **Input Validation**: Comprehensive input validation and sanitization
- **Error Handling**: Secure error handling without information disclosure
- **Resource Limits**: Protection against resource exhaustion attacks

---

## Performance & Scalability

### Geo-blocking Performance
- **ipset Technology**: O(1) lookup time for IP addresses
- **Efficient Memory Usage**: Optimized for large IP ranges
- **Batch Processing**: Handles thousands of IP ranges efficiently
- **Cache Management**: Smart caching with automatic expiration

### System Performance
- **Async Operations**: Non-blocking I/O for better performance
- **Memory Management**: Efficient memory usage with garbage collection
- **Connection Pooling**: Optimized database and network connections
- **Resource Monitoring**: Built-in resource usage monitoring

### Scalability Features
- **Horizontal Scaling**: Support for load balancer deployment
- **Database Independence**: File-based storage for simplicity
- **API Rate Limiting**: Protection against API abuse
- **Concurrent Operations**: Multi-threaded operation support

---

## Troubleshooting

### Common Issues

#### Installation Problems
**Issue**: Permission denied during installation
```bash
# Solution: Ensure running as root
sudo bash install.sh
```

**Issue**: Node.js not found
```bash
# Solution: Install Node.js 22+
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**Issue**: UFW not installed
```bash
# Solution: Install UFW (auto-handled by install script)
sudo apt-get update
sudo apt-get install ufw
```

#### Service Issues
**Issue**: NFGuard service won't start
```bash
# Check service status
sudo systemctl status nfguard

# Check logs
sudo journalctl -u nfguard -f

# Restart service
sudo systemctl restart nfguard
```

**Issue**: WebGUI not accessible
```bash
# Check if port 8443 is open
sudo ufw status
sudo netstat -tlnp | grep 8443

# Check SSL certificates
ls -la /etc/nfguard/ssl/
```

#### Geo-blocking Issues
**Issue**: ipset not working
```bash
# Check if ipset is installed
which ipset

# Install ipset manually
sudo apt-get install ipset

# Check ipset status
sudo ipset list
```

**Issue**: Countries not blocking
```bash
# Check geo-blocking status
sudo nfguard geo-stats

# Verify UFW rules
sudo ufw status numbered

# Check ipset entries
sudo ipset list nfguard-geo-cn
```

#### CLI Issues
**Issue**: Command not found
```bash
# Link CLI globally
cd /path/to/nfguard-0.0.1
sudo npm link

# Or use direct path
sudo node src/cli/index.js status
```

### Diagnostic Commands

```bash
# System health check
sudo nfguard health

# Validate configuration
sudo nfguard validate

# Check UFW status
sudo ufw status verbose

# View detailed logs
sudo nfguard logs --lines=100

# Check service status
sudo systemctl status nfguard
```

### Log Locations
- **System Logs**: `/var/log/nfguard/system.log`
- **Audit Logs**: `/var/log/nfguard/audit.log`
- **Error Logs**: `/var/log/nfguard/error.log`
- **Service Logs**: `sudo journalctl -u nfguard`

### Getting Help
- **Built-in Help**: `nfguard help`
- **Command Help**: `nfguard help <command>`
- **Examples**: `nfguard examples`
- **Health Check**: `nfguard health`

---

## Advanced Configuration

### Custom Geo-blocking
```bash
# Add custom country IP ranges
sudo nano /etc/nfguard/custom-ranges.json

# Update geo database
sudo nfguard geo-update

# Verify custom ranges
sudo nfguard geo-stats
```

### SSL Certificate Configuration
```bash
# Generate custom SSL certificate
sudo openssl req -x509 -newkey rsa:4096 -keyout /etc/nfguard/ssl/server.key -out /etc/nfguard/ssl/server.crt -days 365 -nodes

# Restart service to use new certificate
sudo systemctl restart nfguard
```

### Performance Tuning
```bash
# Increase log rotation
sudo nano /etc/nfguard/config.json
# Set "max_files": 20, "max_size": "50MB"

# Optimize ipset hash size
sudo ipset create test-set hash:net hashsize 2048

# Monitor resource usage
sudo nfguard stats --detailed
```

---

## Version Information

**NFGuard Version**: 0.0.1
**Release Date**: September 2024
**Compatibility**: Linux (Ubuntu 18.04+, CentOS 7+, Debian 9+)
**Node.js Requirement**: 22.0.0+
**License**: MIT

### Changelog v0.0.1
- ✅ Initial release with complete UFW management
- ✅ Real geo-blocking with ipset integration
- ✅ MaxMind database support
- ✅ Professional WebGUI with statistics
- ✅ Comprehensive CLI with 30+ commands
- ✅ Enterprise security features
- ✅ Production-ready deployment
- ✅ Complete documentation and troubleshooting guides

---

## Support & Contributing

### Documentation
- Complete CLI reference with examples
- WebGUI user guide with screenshots
- API documentation for developers
- Security best practices guide

### Community
- GitHub repository for issues and feature requests
- Community forums for user support
- Developer documentation for contributors
- Security disclosure guidelines

**End of Documentation**